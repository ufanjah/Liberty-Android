package com.example

import com.example.data.Candle
import com.example.data.Timeframe
import com.example.service.market.*
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Test

class DerivMarketDataTest {

    @Test
    fun testDerivMarketDataConfig() {
        val config = MarketDataConfig()
        assertEquals("Deriv", config.MARKET_DATA_PROVIDER)
        assertEquals("wss://api.derivws.com/trading/v1/options/ws/public", config.MARKET_DATA_WEBSOCKET_URL)
        assertEquals("wss://ws.derivws.com/websockets/v3?app_id=1089", config.FALLBACK_WEBSOCKET_URL)
        assertTrue(config.hasValidLiveCredentials())

        // Test symbol mappings
        assertEquals("frxEURUSD", config.toProviderSymbol("EUR/USD"))
        assertEquals("frxGBPUSD", config.toProviderSymbol("GBP/USD"))
        assertEquals("frxXAUUSD", config.toProviderSymbol("XAU/USD"))
        assertEquals("R_100", config.toProviderSymbol("VOL_100"))

        assertEquals("EUR/USD", config.toCanonicalSymbol("frxEURUSD"))
        assertEquals("VOL_100", config.toCanonicalSymbol("R_100"))
    }

    @Test
    fun testCandleBuilder30SecondAggregation() {
        val candleBuilder = CandleBuilder()
        val symbol = "EUR/USD"

        // Ingest ticks within the same 30s bucket (00:00:00 to 00:00:29)
        val baseTime = 1710000000000L // aligned
        val bucketMs = 30000L
        val t0 = (baseTime / bucketMs) * bucketMs

        // Tick 1: open = 1.0850
        candleBuilder.processTick(MarketTick(symbol, 1.0849, 1.0851, 1.0850, t0 + 1000))
        // Tick 2: high = 1.0860
        candleBuilder.processTick(MarketTick(symbol, 1.0859, 1.0861, 1.0860, t0 + 5000))
        // Tick 3: low = 1.0840
        candleBuilder.processTick(MarketTick(symbol, 1.0839, 1.0841, 1.0840, t0 + 10000))
        // Tick 4: close = 1.0855
        candleBuilder.processTick(MarketTick(symbol, 1.0854, 1.0856, 1.0855, t0 + 20000))

        val candles30s = candleBuilder.getCandles(symbol, Timeframe.SEC_30)
        assertEquals(1, candles30s.size)
        val c1 = candles30s.first()
        assertEquals(1.0850, c1.open, 0.0001)
        assertEquals(1.0860, c1.high, 0.0001)
        assertEquals(1.0840, c1.low, 0.0001)
        assertEquals(1.0855, c1.close, 0.0001)
        assertEquals(4L, c1.tickVolume)

        // Tick 5 in next 30s bucket (rollover)
        val tNext = t0 + bucketMs + 1000
        candleBuilder.processTick(MarketTick(symbol, 1.0857, 1.0859, 1.0858, tNext))

        val updatedCandles = candleBuilder.getCandles(symbol, Timeframe.SEC_30)
        assertEquals(2, updatedCandles.size)
        val c2 = updatedCandles.last()
        assertEquals(c1.close, c2.open, 0.0001) // continuous price history
        assertEquals(1.0858, c2.close, 0.0001)
    }

    @Test
    fun testIndicatorAndSignalEngineIntegration() {
        val candles = mutableListOf<Candle>()
        var price = 1.0800
        val now = System.currentTimeMillis()

        for (i in 50 downTo 1) {
            price += 0.0002 // bullish trend
            candles.add(
                Candle(
                    timestamp = now - (i * 30000L),
                    open = price - 0.0001,
                    high = price + 0.0003,
                    low = price - 0.0002,
                    close = price,
                    tickVolume = 5L
                )
            )
        }

        val indicators = listOf(
            IndicatorInstance("sma_10", "SMA", "SMA", IndicatorCategory.TREND, mapOf("length" to 10.0)),
            IndicatorInstance("rsi_14", "RSI", "RSI", IndicatorCategory.MOMENTUM, mapOf("length" to 14.0))
        )

        val calc = IndicatorEngine.calculateIndicators(candles, indicators)
        assertNotNull(calc.smaValues)
        assertTrue(calc.smaValues.isNotEmpty())
        assertNotNull(calc.rsiLatest)

        val settings = SignalSettings(minConfirmationsRequired = 2)
        val eval = SignalEngine.evaluate(candles, calc, settings)
        assertNotNull(eval.state)
        assertTrue(eval.confirmations >= 0)
        assertTrue(eval.totalConditionsChecked > 0)
    }

    @Test
    fun testConnectionStates() {
        assertEquals("LIVE", DataConnectionState.LIVE.label)
        assertTrue(DataConnectionState.LIVE.isGenuineLive)

        assertEquals("DEMO DATA", DataConnectionState.DEMO_DATA.label)
        assertFalse(DataConnectionState.DEMO_DATA.isGenuineLive)

        assertEquals("CONNECTING", DataConnectionState.CONNECTING.label)
        assertEquals("RECONNECTING", DataConnectionState.RECONNECTING.label)
        assertEquals("DATA CONNECTION LOST", DataConnectionState.DATA_CONNECTION_LOST.label)
        assertEquals("LIVE DATA UNAVAILABLE", DataConnectionState.LIVE_DATA_UNAVAILABLE.label)
    }

    @Test
    fun testCandleRemainingSecondsAndClockFormat() {
        val baseMs = 1710000000000L // 0s boundary
        // At 12 seconds into a 30s candle, 18 seconds should remain
        val now12s = baseMs + 12000L
        val rem30s = com.example.ui.screens.calculateCandleRemainingSeconds(Timeframe.SEC_30, now12s)
        assertEquals(18, rem30s)
        val formatted30s = com.example.ui.screens.formatSecondsToClock(rem30s)
        assertEquals("00:18", formatted30s)

        // At 55 seconds into a 1m candle, 5 seconds should remain
        val now55s = baseMs + 55000L
        val rem1m = com.example.ui.screens.calculateCandleRemainingSeconds(Timeframe.MIN_1, now55s)
        assertEquals(5, rem1m)
        assertEquals("00:05", com.example.ui.screens.formatSecondsToClock(rem1m))

        // Multi-minute format: 2m 15s remaining
        assertEquals("02:15", com.example.ui.screens.formatSecondsToClock(135))

        // Hours format: 1h 05m 10s
        assertEquals("01:05:10", com.example.ui.screens.formatSecondsToClock(3910))
    }
}
