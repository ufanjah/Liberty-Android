package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trades")
data class TradeEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val assetSymbol: String,
    val assetName: String,
    val direction: String, // "UP" or "DOWN"
    val amount: Double,
    val entryPrice: Double,
    val expiryPrice: Double,
    val durationSeconds: Int,
    val placedAt: Long,
    val expiresAt: Long,
    val payoutPercent: Int,
    val result: String, // "WON", "LOST", "TIE"
    val profitOrLoss: Double
)
