package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_bank_accounts")
data class SavedBankAccountEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val bankName: String,
    val bankCode: String,
    val accountNumber: String,
    val accountName: String,
    val accountType: String = "Savings",
    val phoneNumber: String = "",
    val isDefault: Boolean = false,
    val isVerified: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
) {
    val maskedAccountNumber: String
        get() = if (accountNumber.length >= 4) {
            "****" + accountNumber.takeLast(4)
        } else {
            "****"
        }
}
