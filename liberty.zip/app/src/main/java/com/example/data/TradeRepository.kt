package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID
import kotlin.random.Random

class TradeRepository(private val tradeDao: TradeDao) {

    val allTrades: Flow<List<TradeEntity>> = tradeDao.getAllTrades()

    val account: Flow<UserAccountEntity> = tradeDao.getAccount().map { account ->
        account ?: UserAccountEntity(id = 1, demoBalance = 10000.0, availableBalance = 10000.0)
    }

    val userProfile: Flow<UserProfileEntity> = tradeDao.getProfile().map { profile ->
        profile ?: UserProfileEntity()
    }

    val allTransactions: Flow<List<TransactionEntity>> = tradeDao.getAllTransactions()

    val savedBankAccounts: Flow<List<SavedBankAccountEntity>> = tradeDao.getAllBankAccounts()

    suspend fun recordCompletedTrade(trade: TradeEntity) {
        tradeDao.insertTrade(trade)
        val currentAccount = tradeDao.getAccountDirect() ?: UserAccountEntity(id = 1, demoBalance = 10000.0, availableBalance = 10000.0)
        
        val isWin = trade.result == "WIN" || trade.result == "WON"
        val isLoss = trade.result == "LOSS" || trade.result == "LOST"
        val isDraw = trade.result == "DRAW" || trade.result == "TIE"

        val newBalance = when {
            isWin -> currentAccount.demoBalance + trade.amount + trade.profitOrLoss
            isDraw -> currentAccount.demoBalance + trade.amount
            else -> currentAccount.demoBalance // Lost: investment was already deducted at trade placement
        }
        val roundedBalance = (newBalance * 100).toLong() / 100.0

        val updated = currentAccount.copy(
            demoBalance = roundedBalance,
            availableBalance = roundedBalance,
            totalTrades = currentAccount.totalTrades + 1,
            wonTrades = if (isWin) currentAccount.wonTrades + 1 else currentAccount.wonTrades,
            lostTrades = if (isLoss) currentAccount.lostTrades + 1 else currentAccount.lostTrades,
            drawTrades = if (isDraw) currentAccount.drawTrades + 1 else currentAccount.drawTrades,
            totalProfit = if (isWin) currentAccount.totalProfit + trade.profitOrLoss else currentAccount.totalProfit,
            totalLoss = if (isLoss) currentAccount.totalLoss + trade.amount else currentAccount.totalLoss
        )
        tradeDao.insertOrUpdateAccount(updated)
    }

    suspend fun deductTradePlacement(amount: Double): Boolean {
        val currentAccount = tradeDao.getAccountDirect() ?: UserAccountEntity(id = 1, demoBalance = 10000.0, availableBalance = 10000.0)
        if (currentAccount.availableBalance < amount) {
            return false
        }
        val newBal = ((currentAccount.availableBalance - amount) * 100).toLong() / 100.0
        val updated = currentAccount.copy(
            demoBalance = newBal,
            availableBalance = newBal
        )
        tradeDao.insertOrUpdateAccount(updated)
        return true
    }

    suspend fun refundTrade(amount: Double) {
        val currentAccount = tradeDao.getAccountDirect() ?: UserAccountEntity(id = 1, demoBalance = 10000.0, availableBalance = 10000.0)
        val newBal = ((currentAccount.demoBalance + amount) * 100).toLong() / 100.0
        val updated = currentAccount.copy(
            demoBalance = newBal,
            availableBalance = newBal
        )
        tradeDao.insertOrUpdateAccount(updated)
    }

    suspend fun resetDemoBalance() {
        val currentAccount = tradeDao.getAccountDirect() ?: UserAccountEntity(id = 1)
        val reset = currentAccount.copy(
            demoBalance = 10000.0,
            availableBalance = 10000.0,
            pendingDeposits = 0.0,
            pendingWithdrawals = 0.0
        )
        tradeDao.insertOrUpdateAccount(reset)
    }

    suspend fun topUpDemoBalance(amount: Double) {
        val currentAccount = tradeDao.getAccountDirect() ?: UserAccountEntity(id = 1, demoBalance = 10000.0, availableBalance = 10000.0)
        val newBal = currentAccount.demoBalance + amount
        val updated = currentAccount.copy(
            demoBalance = newBal,
            availableBalance = newBal,
            totalDeposits = currentAccount.totalDeposits + amount
        )
        tradeDao.insertOrUpdateAccount(updated)
    }

    suspend fun recordDeposit(amount: Double, paymentMethod: String, reference: String? = null): TransactionEntity {
        val refNumber = reference ?: "LIB-DEP-${Random.nextInt(100000, 999999)}"
        val tx = TransactionEntity(
            type = "DEPOSIT",
            amount = amount,
            method = paymentMethod,
            status = "DEMO / COMPLETED",
            reference = refNumber,
            timestamp = System.currentTimeMillis(),
            details = "Method: $paymentMethod • Simulated Demo Credit"
        )
        tradeDao.insertTransaction(tx)

        val currentAccount = tradeDao.getAccountDirect() ?: UserAccountEntity(id = 1, demoBalance = 10000.0, availableBalance = 10000.0)
        val newBal = currentAccount.demoBalance + amount
        val updated = currentAccount.copy(
            demoBalance = newBal,
            availableBalance = newBal,
            totalDeposits = currentAccount.totalDeposits + amount
        )
        tradeDao.insertOrUpdateAccount(updated)

        return tx
    }

    suspend fun recordWithdrawal(
        amount: Double,
        bankName: String,
        accountName: String,
        accountNumber: String,
        reference: String? = null
    ): TransactionEntity? {
        val currentAccount = tradeDao.getAccountDirect() ?: UserAccountEntity(id = 1, demoBalance = 10000.0, availableBalance = 10000.0)
        if (currentAccount.availableBalance < amount) {
            return null
        }

        val refNumber = reference ?: "LIB-WTH-${Random.nextInt(100000, 999999)}"
        val maskedAcc = if (accountNumber.length >= 4) {
            "******" + accountNumber.takeLast(4)
        } else {
            "******"
        }
        val tx = TransactionEntity(
            type = "WITHDRAWAL",
            amount = amount,
            method = bankName,
            status = "DEMO / PENDING",
            reference = refNumber,
            timestamp = System.currentTimeMillis(),
            details = "$accountName • $maskedAcc"
        )
        tradeDao.insertTransaction(tx)

        val newBal = currentAccount.availableBalance - amount
        val updated = currentAccount.copy(
            demoBalance = newBal,
            availableBalance = newBal,
            pendingWithdrawals = currentAccount.pendingWithdrawals + amount,
            totalWithdrawals = currentAccount.totalWithdrawals + amount
        )
        tradeDao.insertOrUpdateAccount(updated)

        return tx
    }

    suspend fun saveBankAccount(account: SavedBankAccountEntity): Long {
        if (account.isDefault) {
            tradeDao.clearDefaultBankAccounts()
        }
        return tradeDao.insertBankAccount(account)
    }

    suspend fun updateBankAccount(account: SavedBankAccountEntity) {
        if (account.isDefault) {
            tradeDao.clearDefaultBankAccounts()
        }
        tradeDao.updateBankAccount(account)
    }

    suspend fun deleteBankAccount(id: Long) {
        tradeDao.deleteBankAccount(id)
    }

    suspend fun setDefaultBankAccount(id: Long) {
        tradeDao.clearDefaultBankAccounts()
        tradeDao.setDefaultBankAccount(id)
    }

    suspend fun updateProfile(profile: UserProfileEntity) {
        tradeDao.insertOrUpdateProfile(profile)
    }

    suspend fun clearHistory() {
        tradeDao.clearTrades()
        val currentAccount = tradeDao.getAccountDirect() ?: UserAccountEntity(id = 1)
        val resetStats = currentAccount.copy(
            totalTrades = 0,
            wonTrades = 0,
            lostTrades = 0,
            drawTrades = 0,
            totalProfit = 0.0,
            totalLoss = 0.0
        )
        tradeDao.insertOrUpdateAccount(resetStats)
    }

    suspend fun clearTransactions() {
        tradeDao.clearTransactions()
    }
}
