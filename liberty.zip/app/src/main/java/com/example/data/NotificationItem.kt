package com.example.data

import java.util.UUID

data class NotificationItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val message: String,
    val type: String, // "TRADE_OPENED", "TRADE_EXPIRED", "DEPOSIT", "WITHDRAWAL", "PROFILE", "SECURITY"
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)
