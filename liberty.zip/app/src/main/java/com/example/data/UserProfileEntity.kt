package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfileEntity(
    @PrimaryKey
    val id: Int = 1,
    val fullName: String = "Alexander Morgan",
    val username: String = "alex_trader",
    val email: String = "alexander.morgan@demo-trading.com",
    val phoneNumber: String = "+234 801 234 5678",
    val address: String = "14 Admiralty Way, Lekki Phase 1",
    val city: String = "Lagos",
    val state: String = "Lagos State",
    val country: String = "Nigeria",
    val avatarId: Int = 1,
    val isTwoFactorEnabled: Boolean = false,
    val lastLoginSession: String = "Android Demo Session • Lagos, Nigeria"
)
