package com.example.data

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToLong
import kotlin.random.Random

data class TradingAsset(
    val symbol: String,
    val name: String,
    val basePrice: Double,
    val decimals: Int,
    val payoutPercent: Int,
    val volatility: Double,
    val iconEmoji: String
)

data class Candle(
    val timestamp: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val tickVolume: Long = 1L
)

data class ActiveTrade(
    val id: String = UUID.randomUUID().toString(),
    val assetSymbol: String,
    val assetName: String,
    val direction: String, // "UP" or "DOWN"
    val amount: Double,
    val entryPrice: Double,
    val durationSeconds: Int,
    val placedAt: Long,
    val expiresAt: Long,
    val payoutPercent: Int
) {
    val potentialProfit: Double
        get() = amount * (payoutPercent / 100.0)

    val potentialPayout: Double
        get() = amount + potentialProfit

    fun remainingSeconds(): Int {
        val rem = ((expiresAt - System.currentTimeMillis()) / 1000).toInt()
        return max(0, rem)
    }

    fun isWinning(currentPrice: Double): Boolean {
        return if (direction == "UP") currentPrice > entryPrice else currentPrice < entryPrice
    }

    fun isTie(currentPrice: Double): Boolean = currentPrice == entryPrice
}

data class TradeResultEvent(
    val trade: TradeEntity,
    val isWin: Boolean,
    val isTie: Boolean,
    val returnAmount: Double,
    val profitOrLoss: Double
)

enum class Timeframe(val label: String, val seconds: Int) {
    SEC_5("5s", 5),
    SEC_15("15s", 15),
    SEC_30("30s", 30),
    MIN_1("1m", 60),
    MIN_3("3m", 180),
    MIN_5("5m", 300),
    MIN_15("15m", 900),
    MIN_30("30m", 1800),
    HOUR_1("1H", 3600),
    HOUR_4("4H", 14400),
    DAY_1("1D", 86400)
}

class MarketSimulator(
    private val scope: CoroutineScope,
    private val repository: TradeRepository
) {
    companion object {
        val SUPPORTED_ASSETS = com.example.service.market.MarketDataDefaults.SUPPORTED_ASSETS
    }

    var isLiveActive: Boolean = false

    fun updateWithLiveTick(tick: com.example.service.market.MarketTick, liveCandles: List<Candle>) {
        assetPrices[tick.symbol] = tick.mid
        if (_selectedAsset.value.symbol == tick.symbol) {
            _currentPrice.value = tick.mid
            if (liveCandles.isNotEmpty()) {
                _candles.value = liveCandles
                val firstCandle = liveCandles.first()
                val change = tick.mid - firstCandle.open
                _priceChange24h.value = change
                _priceChangePercent24h.value = if (firstCandle.open != 0.0) (change / firstCandle.open) * 100 else 0.0
            }
        }
        scope.launch {
            checkActiveTrades()
        }
    }

    private val _selectedAsset = MutableStateFlow(SUPPORTED_ASSETS[0])
    val selectedAsset: StateFlow<TradingAsset> = _selectedAsset.asStateFlow()

    private val _currentTimeframe = MutableStateFlow(Timeframe.SEC_30)
    val currentTimeframe: StateFlow<Timeframe> = _currentTimeframe.asStateFlow()

    private val _currentPrice = MutableStateFlow(SUPPORTED_ASSETS[0].basePrice)
    val currentPrice: StateFlow<Double> = _currentPrice.asStateFlow()

    private val _priceChange24h = MutableStateFlow(0.0015)
    val priceChange24h: StateFlow<Double> = _priceChange24h.asStateFlow()

    private val _priceChangePercent24h = MutableStateFlow(0.14)
    val priceChangePercent24h: StateFlow<Double> = _priceChangePercent24h.asStateFlow()

    private val _candles = MutableStateFlow<List<Candle>>(emptyList())
    val candles: StateFlow<List<Candle>> = _candles.asStateFlow()

    private val _activeTrades = MutableStateFlow<List<ActiveTrade>>(emptyList())
    val activeTrades: StateFlow<List<ActiveTrade>> = _activeTrades.asStateFlow()

    private val _tradeEvents = MutableSharedFlow<TradeResultEvent>(extraBufferCapacity = 10)
    val tradeEvents: SharedFlow<TradeResultEvent> = _tradeEvents.asSharedFlow()

    private var simulationJob: Job? = null
    private var candleTimerJob: Job? = null

    // Track state per asset
    private val assetPrices = mutableMapOf<String, Double>()
    private val assetCandleCaches = mutableMapOf<String, MutableMap<Timeframe, MutableList<Candle>>>()

    init {
        SUPPORTED_ASSETS.forEach { asset ->
            assetPrices[asset.symbol] = asset.basePrice
            val tfMap = mutableMapOf<Timeframe, MutableList<Candle>>()
            Timeframe.entries.forEach { tf ->
                tfMap[tf] = generateInitialCandles(asset, tf).toMutableList()
            }
            assetCandleCaches[asset.symbol] = tfMap
        }

        updateActiveAssetData()
        startMarketSimulation()
    }

    fun selectAsset(asset: TradingAsset) {
        if (_selectedAsset.value.symbol == asset.symbol) return
        _selectedAsset.value = asset
        updateActiveAssetData()
    }

    fun selectTimeframe(tf: Timeframe) {
        if (_currentTimeframe.value == tf) return
        _currentTimeframe.value = tf
        updateActiveAssetData()
    }

    private fun updateActiveAssetData() {
        val asset = _selectedAsset.value
        val tf = _currentTimeframe.value
        val price = assetPrices[asset.symbol] ?: asset.basePrice
        _currentPrice.value = price

        val cached = assetCandleCaches[asset.symbol]?.get(tf) ?: generateInitialCandles(asset, tf).toMutableList()
        _candles.value = cached.toList()

        val initialClose = cached.firstOrNull()?.open ?: price
        val change = price - initialClose
        val pct = if (initialClose != 0.0) (change / initialClose) * 100 else 0.0
        _priceChange24h.value = change
        _priceChangePercent24h.value = pct
    }

    private fun generateInitialCandles(asset: TradingAsset, tf: Timeframe): List<Candle> {
        val list = mutableListOf<Candle>()
        val count = 50
        val durationMs = tf.seconds * 1000L
        val now = System.currentTimeMillis()
        var lastClose = asset.basePrice

        for (i in count downTo 1) {
            val candleTime = now - (i * durationMs)
            val delta = (Random.nextDouble() - 0.495) * asset.volatility * 2.0
            val open = lastClose
            val close = roundPrice(open + delta, asset.decimals)
            val high = roundPrice(max(open, close) + Random.nextDouble() * asset.volatility, asset.decimals)
            val low = roundPrice(min(open, close) - Random.nextDouble() * asset.volatility, asset.decimals)
            list.add(Candle(candleTime, open, high, low, close))
            lastClose = close
        }
        return list
    }

    private fun startMarketSimulation() {
        simulationJob?.cancel()
        simulationJob = scope.launch(Dispatchers.Default) {
            var tickCount = 0
            while (isActive) {
                delay(1000)
                tickCount++

                if (isLiveActive) {
                    // LIVE DATA CONNECTED: Do NOT inject fake or random candles.
                    // Continuous ticks are ingested via updateWithLiveTick directly into CandleBuilder.
                    checkActiveTrades()
                    continue
                }

                // Simulate all assets slightly in practice/demo fallback mode
                SUPPORTED_ASSETS.forEach { asset ->
                    val oldPrice = assetPrices[asset.symbol] ?: asset.basePrice
                    // Random walk with mean reversion
                    val reversion = (asset.basePrice - oldPrice) * 0.015
                    val drift = (Random.nextDouble() - 0.5) * asset.volatility + reversion
                    val newPrice = roundPrice(oldPrice + drift, asset.decimals)
                    assetPrices[asset.symbol] = newPrice

                    // Update candles for each timeframe
                    val tfMap = assetCandleCaches[asset.symbol]
                    if (tfMap != null) {
                        Timeframe.entries.forEach { tf ->
                            val candleList = tfMap[tf]
                            if (candleList != null && candleList.isNotEmpty()) {
                                val lastCandle = candleList.last()
                                val now = System.currentTimeMillis()
                                val tfMs = tf.seconds * 1000L

                                if (now - lastCandle.timestamp >= tfMs) {
                                    // Start new candle
                                    val newCandle = Candle(
                                        timestamp = now,
                                        open = newPrice,
                                        high = newPrice,
                                        low = newPrice,
                                        close = newPrice
                                    )
                                    candleList.add(newCandle)
                                    if (candleList.size > 80) {
                                        candleList.removeAt(0)
                                    }
                                } else {
                                    // Update current candle
                                    val updatedCandle = lastCandle.copy(
                                        high = max(lastCandle.high, newPrice),
                                        low = min(lastCandle.low, newPrice),
                                        close = newPrice
                                    )
                                    candleList[candleList.lastIndex] = updatedCandle
                                }
                            }
                        }
                    }
                }

                // If active asset updated, push to UI
                val curAsset = _selectedAsset.value
                val curTf = _currentTimeframe.value
                val activePrice = assetPrices[curAsset.symbol] ?: curAsset.basePrice
                _currentPrice.value = activePrice

                val currentCandleList = assetCandleCaches[curAsset.symbol]?.get(curTf)
                if (currentCandleList != null) {
                    _candles.value = currentCandleList.toList()
                    val firstCandle = currentCandleList.firstOrNull()
                    if (firstCandle != null) {
                        val change = activePrice - firstCandle.open
                        _priceChange24h.value = change
                        _priceChangePercent24h.value = (change / firstCandle.open) * 100
                    }
                }

                // Check active trades expiration
                checkActiveTrades()
            }
        }
    }

    private suspend fun checkActiveTrades() {
        val now = System.currentTimeMillis()
        val currentTrades = _activeTrades.value
        if (currentTrades.isEmpty()) return

        val expiredTrades = currentTrades.filter { now >= it.expiresAt }
        if (expiredTrades.isEmpty()) return

        val remainingTrades = currentTrades.filter { now < it.expiresAt }
        _activeTrades.value = remainingTrades

        expiredTrades.forEach { trade ->
            val asset = SUPPORTED_ASSETS.find { it.symbol == trade.assetSymbol } ?: _selectedAsset.value
            val currentAssetPrice = assetPrices[trade.assetSymbol] ?: trade.entryPrice

            val isWin = trade.isWinning(currentAssetPrice)
            val isTie = trade.isTie(currentAssetPrice)

            val result = when {
                isTie -> "DRAW"
                isWin -> "WIN"
                else -> "LOSS"
            }

            val profitOrLoss = when {
                isTie -> 0.0
                isWin -> trade.amount * (trade.payoutPercent / 100.0)
                else -> -trade.amount
            }

            val returnAmount = when {
                isTie -> trade.amount
                isWin -> trade.amount + profitOrLoss
                else -> 0.0
            }

            val completedEntity = TradeEntity(
                assetSymbol = trade.assetSymbol,
                assetName = trade.assetName,
                direction = trade.direction,
                amount = trade.amount,
                entryPrice = trade.entryPrice,
                expiryPrice = currentAssetPrice,
                durationSeconds = trade.durationSeconds,
                placedAt = trade.placedAt,
                expiresAt = trade.expiresAt,
                payoutPercent = trade.payoutPercent,
                result = result,
                profitOrLoss = profitOrLoss
            )

            // Persist to Room
            repository.recordCompletedTrade(completedEntity)

            // Emit event
            _tradeEvents.emit(
                TradeResultEvent(
                    trade = completedEntity,
                    isWin = isWin,
                    isTie = isTie,
                    returnAmount = returnAmount,
                    profitOrLoss = profitOrLoss
                )
            )
        }
    }

    suspend fun placeTrade(
        direction: String,
        amount: Double,
        durationSeconds: Int
    ): Boolean {
        val asset = _selectedAsset.value
        val entryPrice = _currentPrice.value
        val now = System.currentTimeMillis()
        val expiresAt = now + (durationSeconds * 1000L)

        // Try to deduct from balance first
        val deducted = repository.deductTradePlacement(amount)
        if (!deducted) {
            return false
        }

        val trade = ActiveTrade(
            assetSymbol = asset.symbol,
            assetName = asset.name,
            direction = direction,
            amount = amount,
            entryPrice = entryPrice,
            durationSeconds = durationSeconds,
            placedAt = now,
            expiresAt = expiresAt,
            payoutPercent = asset.payoutPercent
        )

        _activeTrades.value = _activeTrades.value + trade
        return true
    }

    private fun roundPrice(price: Double, decimals: Int): Double {
        var multiplier = 1.0
        repeat(decimals) { multiplier *= 10.0 }
        return (price * multiplier).roundToLong() / multiplier
    }
}
