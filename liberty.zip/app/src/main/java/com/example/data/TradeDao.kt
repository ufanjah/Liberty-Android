package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TradeDao {
    // Trades
    @Query("SELECT * FROM trades ORDER BY placedAt DESC")
    fun getAllTrades(): Flow<List<TradeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrade(trade: TradeEntity): Long

    @Query("DELETE FROM trades")
    suspend fun clearTrades()

    // Account
    @Query("SELECT * FROM user_account WHERE id = 1 LIMIT 1")
    fun getAccount(): Flow<UserAccountEntity?>

    @Query("SELECT * FROM user_account WHERE id = 1 LIMIT 1")
    suspend fun getAccountDirect(): UserAccountEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateAccount(account: UserAccountEntity)

    @Query("UPDATE user_account SET demoBalance = :newBalance, availableBalance = :newBalance WHERE id = 1")
    suspend fun updateBalance(newBalance: Double)

    // User Profile
    @Query("SELECT * FROM user_profile WHERE id = 1 LIMIT 1")
    fun getProfile(): Flow<UserProfileEntity?>

    @Query("SELECT * FROM user_profile WHERE id = 1 LIMIT 1")
    suspend fun getProfileDirect(): UserProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateProfile(profile: UserProfileEntity)

    // Transactions
    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<TransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionEntity): Long

    @Query("DELETE FROM transactions")
    suspend fun clearTransactions()

    // Saved Bank Accounts
    @Query("SELECT * FROM saved_bank_accounts ORDER BY isDefault DESC, createdAt DESC")
    fun getAllBankAccounts(): Flow<List<SavedBankAccountEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBankAccount(account: SavedBankAccountEntity): Long

    @Update
    suspend fun updateBankAccount(account: SavedBankAccountEntity)

    @Query("DELETE FROM saved_bank_accounts WHERE id = :id")
    suspend fun deleteBankAccount(id: Long)

    @Query("UPDATE saved_bank_accounts SET isDefault = 0")
    suspend fun clearDefaultBankAccounts()

    @Query("UPDATE saved_bank_accounts SET isDefault = 1 WHERE id = :id")
    suspend fun setDefaultBankAccount(id: Long)

    @Query("SELECT * FROM saved_bank_accounts WHERE id = :id LIMIT 1")
    suspend fun getBankAccountById(id: Long): SavedBankAccountEntity?
}
