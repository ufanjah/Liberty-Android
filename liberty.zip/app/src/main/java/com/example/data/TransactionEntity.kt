package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val type: String, // "DEPOSIT" or "WITHDRAWAL"
    val amount: Double,
    val method: String, // "Bank Transfer", "Paystack", "Flutterwave", "Access Bank", etc.
    val status: String, // "DEMO / COMPLETED", "DEMO / PENDING"
    val reference: String,
    val timestamp: Long,
    val details: String = ""
)
