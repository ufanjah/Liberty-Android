package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_account")
data class UserAccountEntity(
    @PrimaryKey
    val id: Int = 1,
    val demoBalance: Double = 10000.0,
    val availableBalance: Double = 10000.0,
    val pendingDeposits: Double = 0.0,
    val pendingWithdrawals: Double = 0.0,
    val totalDeposits: Double = 0.0,
    val totalWithdrawals: Double = 0.0,
    val totalTrades: Int = 0,
    val wonTrades: Int = 0,
    val lostTrades: Int = 0,
    val drawTrades: Int = 0,
    val totalProfit: Double = 0.0,
    val totalLoss: Double = 0.0
)
