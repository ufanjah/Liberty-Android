package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.TradingViewModel
import com.example.ui.theme.*

/**
 * Secondary trading configuration and preferences sheet.
 * Keeps the main trading dashboard clean and focused.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TradingSettingsSheet(
    viewModel: TradingViewModel,
    onDismiss: () -> Unit
) {
    var oneClickTrading by remember { mutableStateOf(false) }
    var soundAlerts by remember { mutableStateOf(true) }
    var vibrationFeedback by remember { mutableStateOf(true) }
    var showGridLines by remember { mutableStateOf(true) }
    var showLivePricePulse by remember { mutableStateOf(true) }

    // Technical indicators toggles
    var smaEnabled by remember { mutableStateOf(false) }
    var emaEnabled by remember { mutableStateOf(false) }
    var rsiEnabled by remember { mutableStateOf(false) }
    var bollingerEnabled by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = SurfaceDark,
        contentColor = TextPrimary,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        dragHandle = {
            BottomSheetDefaults.DragHandle(
                color = CardBorder,
                modifier = Modifier.padding(vertical = 10.dp)
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Title Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(SurfaceElevatedDark, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = null,
                            tint = PrimaryBlue,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "Trading Settings",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "Preferences & Chart Options",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }
                }

                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = TextSecondary
                    )
                }
            }

            HorizontalDivider(color = CardBorder, thickness = 0.5.dp)

            // Section 1: Chart Indicators
            Text(
                text = "TECHNICAL INDICATORS",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = TextSecondary,
                fontSize = 10.sp,
                letterSpacing = 0.5.sp
            )

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = SurfaceVariantDark,
                border = androidx.compose.foundation.BorderStroke(0.5.dp, CardBorder)
            ) {
                Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
                    SettingToggleRow(
                        title = "Moving Average (SMA 20)",
                        subtitle = "Trend smoothing curve",
                        checked = smaEnabled,
                        onCheckedChange = { smaEnabled = it }
                    )
                    HorizontalDivider(color = CardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)
                    SettingToggleRow(
                        title = "Exponential MA (EMA 50)",
                        subtitle = "Weighted dynamic support/resistance",
                        checked = emaEnabled,
                        onCheckedChange = { emaEnabled = it }
                    )
                    HorizontalDivider(color = CardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)
                    SettingToggleRow(
                        title = "Relative Strength (RSI 14)",
                        subtitle = "Overbought / oversold indicator",
                        checked = rsiEnabled,
                        onCheckedChange = { rsiEnabled = it }
                    )
                    HorizontalDivider(color = CardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)
                    SettingToggleRow(
                        title = "Bollinger Bands (20, 2)",
                        subtitle = "Volatility envelope bands",
                        checked = bollingerEnabled,
                        onCheckedChange = { bollingerEnabled = it }
                    )
                }
            }

            // Section 2: Trading Preferences
            Text(
                text = "EXECUTION & SOUNDS",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = TextSecondary,
                fontSize = 10.sp,
                letterSpacing = 0.5.sp
            )

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = SurfaceVariantDark,
                border = androidx.compose.foundation.BorderStroke(0.5.dp, CardBorder)
            ) {
                Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
                    SettingToggleRow(
                        title = "Sound Effects",
                        subtitle = "Trade entry and result audio chime",
                        checked = soundAlerts,
                        onCheckedChange = { soundAlerts = it }
                    )
                    HorizontalDivider(color = CardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)
                    SettingToggleRow(
                        title = "Haptic Vibration",
                        subtitle = "Tactile feedback on button presses",
                        checked = vibrationFeedback,
                        onCheckedChange = { vibrationFeedback = it }
                    )
                    HorizontalDivider(color = CardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)
                    SettingToggleRow(
                        title = "One-Click Order Entry",
                        subtitle = "Execute trades without confirmation dialogs",
                        checked = oneClickTrading,
                        onCheckedChange = { oneClickTrading = it }
                    )
                }
            }

            // Section 3: Demo Account Actions
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = SurfaceVariantDark,
                border = androidx.compose.foundation.BorderStroke(0.5.dp, CardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Reset Demo Balance",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "Restore balance to $10,000.00 USD",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            viewModel.resetDemoBalance()
                            onDismiss()
                        },
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = null,
                            tint = PrimaryBlue,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Reset $10K",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryBlue
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                color = TextPrimary
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                fontSize = 10.sp
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = PrimaryBlue,
                uncheckedThumbColor = TextMuted,
                uncheckedTrackColor = SurfaceElevatedDark
            )
        )
    }
}
