package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ActiveTrade
import com.example.data.Candle
import com.example.data.Timeframe
import com.example.service.market.CalculatedIndicators
import com.example.ui.theme.*
import java.util.*
import kotlin.math.max
import kotlin.math.min

enum class ChartType(val label: String) {
    CANDLESTICK("Candles"),
    AREA("Area"),
    LINE("Line")
}

/**
 * Professional, high-performance trading chart for Liberty.
 *
 * Visual Capabilities:
 * - Candlestick, Area, and Line rendering modes
 * - Real mathematical indicator overlays:
 *   * SMA / EMA lines
 *   * Bollinger Bands with translucent fill channel
 *   * Supertrend dynamic support/resistance color changing
 *   * Parabolic SAR dots
 *   * Bill Williams confirmed Fractals (arrows on swing highs and lows)
 *   * Fibonacci retracement grid lines
 * - Live price tracking dotted line, pulse beacon, and price pill on right-axis
 * - Interactive scrubber crosshair with OHLC measurement
 * - Active demo trade strike line, direction pill, and vertical expiry countdown line
 */
@Composable
fun CandlestickChart(
    candles: List<Candle>,
    currentPrice: Double,
    decimals: Int,
    timeframe: Timeframe,
    onTimeframeSelected: (Timeframe) -> Unit,
    activeTrades: List<ActiveTrade>,
    modifier: Modifier = Modifier,
    chartType: ChartType = ChartType.CANDLESTICK,
    calculatedIndicators: CalculatedIndicators = CalculatedIndicators(),
    showSma: Boolean = true,
    zoomCandleCount: Int = 40
) {
    var selectedCandleIndex by remember { mutableStateOf<Int?>(null) }
    val textMeasurer = rememberTextMeasurer()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(SurfaceDark.copy(alpha = 0.95f), RoundedCornerShape(12.dp))
            .padding(top = 8.dp, bottom = 6.dp, start = 8.dp, end = 8.dp)
    ) {
        // Scrubber OHLC info row when user touches chart
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .background(UpGreen, RoundedCornerShape(3.dp))
                )
                Text(
                    text = "LIVE",
                    style = MaterialTheme.typography.labelSmall,
                    color = UpGreen,
                    fontWeight = FontWeight.Black,
                    fontSize = 9.sp,
                    letterSpacing = 0.5.sp
                )
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = SurfaceVariantDark
                ) {
                    Text(
                        text = "${timeframe.label} • ${chartType.label}",
                        color = TextSecondary,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        fontSize = 8.5.sp,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                    )
                }
            }

            if (selectedCandleIndex != null && selectedCandleIndex!! in candles.indices) {
                val sc = candles[selectedCandleIndex!!]
                val isUp = sc.close >= sc.open
                Row(
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "O:${formatPrice(sc.open, decimals)}", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 8.5.sp)
                    Text(text = "H:${formatPrice(sc.high, decimals)}", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 8.5.sp)
                    Text(text = "L:${formatPrice(sc.low, decimals)}", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 8.5.sp)
                    Text(
                        text = "C:${formatPrice(sc.close, decimals)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isUp) UpGreen else DownRed,
                        fontWeight = FontWeight.Bold,
                        fontSize = 8.5.sp
                    )
                }
            } else {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    calculatedIndicators.rsiLatest?.let { rsi ->
                        Text(
                            text = "RSI: ${String.format("%.1f", rsi)}",
                            fontSize = 8.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (rsi > 70) DownRed else if (rsi < 30) UpGreen else TextSecondary
                        )
                    }
                    Text(
                        text = "Touch to inspect",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted,
                        fontSize = 8.5.sp
                    )
                }
            }
        }

        // The Canvas Chart (takes flexible height)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f, fill = true)
                .pointerInput(candles, zoomCandleCount) {
                    detectTapGestures(
                        onPress = { offset ->
                            val visibleCount = min(candles.size, zoomCandleCount)
                            selectedCandleIndex = calculateIndexFromOffset(offset.x, size.width.toFloat(), visibleCount, candles.size)
                            tryAwaitRelease()
                            selectedCandleIndex = null
                        },
                        onTap = { selectedCandleIndex = null }
                    )
                }
                .pointerInput(candles, zoomCandleCount) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            val visibleCount = min(candles.size, zoomCandleCount)
                            selectedCandleIndex = calculateIndexFromOffset(offset.x, size.width.toFloat(), visibleCount, candles.size)
                        },
                        onDrag = { change, _ ->
                            val visibleCount = min(candles.size, zoomCandleCount)
                            selectedCandleIndex = calculateIndexFromOffset(change.position.x, size.width.toFloat(), visibleCount, candles.size)
                        },
                        onDragEnd = { selectedCandleIndex = null },
                        onDragCancel = { selectedCandleIndex = null }
                    )
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize().testTag("candlestick_canvas")) {
                if (candles.isEmpty()) return@Canvas

                val visibleCount = min(candles.size, zoomCandleCount)
                val displayCandles = candles.takeLast(visibleCount)
                val startIndex = candles.size - visibleCount

                // Calculate price bounds
                var minPrice = displayCandles.minOfOrNull { it.low } ?: currentPrice
                var maxPrice = displayCandles.maxOfOrNull { it.high } ?: currentPrice
                minPrice = min(minPrice, currentPrice)
                maxPrice = max(maxPrice, currentPrice)

                // Include active trades in scale
                activeTrades.forEach {
                    minPrice = min(minPrice, it.entryPrice)
                    maxPrice = max(maxPrice, it.entryPrice)
                }

                val priceSpan = maxPrice - minPrice
                val padding = if (priceSpan > 0.0) priceSpan * 0.12 else currentPrice * 0.002
                val chartMin = minPrice - padding
                val chartMax = maxPrice + padding
                val totalSpan = max(0.00001, chartMax - chartMin)

                val chartRightMargin = 60.dp.toPx()
                val chartWidth = size.width - chartRightMargin
                val chartHeight = size.height

                // 1. Draw subtle horizontal grid lines & Price Axis
                val gridSteps = 4
                val dashEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)

                for (i in 0..gridSteps) {
                    val y = (chartHeight / gridSteps) * i
                    val priceAtY = chartMax - (i.toDouble() / gridSteps) * totalSpan
                    drawLine(
                        color = GridLine.copy(alpha = 0.5f),
                        start = Offset(0f, y),
                        end = Offset(chartWidth, y),
                        strokeWidth = 1f,
                        pathEffect = dashEffect
                    )

                    // Draw right-axis price label
                    val textLayout = textMeasurer.measure(
                        text = formatPrice(priceAtY, decimals),
                        style = TextStyle(
                            color = TextMuted,
                            fontSize = 8.5.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    )
                    drawText(
                        textLayoutResult = textLayout,
                        topLeft = Offset(chartWidth + 6.dp.toPx(), y - (textLayout.size.height / 2f))
                    )
                }

                // 2. Render Chart Data (Candles or Area or Line)
                val candleWidth = (chartWidth / visibleCount) * 0.68f
                val candleStep = chartWidth / visibleCount

                if (chartType == ChartType.CANDLESTICK) {
                    displayCandles.forEachIndexed { index, candle ->
                        val centerX = (index * candleStep) + (candleStep / 2f)
                        val isBullish = candle.close >= candle.open
                        val candleColor = if (isBullish) UpGreen else DownRed

                        val highY = (chartHeight * (1.0 - ((candle.high - chartMin) / totalSpan))).toFloat()
                        val lowY = (chartHeight * (1.0 - ((candle.low - chartMin) / totalSpan))).toFloat()
                        val openY = (chartHeight * (1.0 - ((candle.open - chartMin) / totalSpan))).toFloat()
                        val closeY = (chartHeight * (1.0 - ((candle.close - chartMin) / totalSpan))).toFloat()

                        // Draw Wick line
                        drawLine(
                            color = candleColor,
                            start = Offset(centerX, highY),
                            end = Offset(centerX, lowY),
                            strokeWidth = 1.4.dp.toPx()
                        )

                        // Draw Candle Body
                        val bodyTop = min(openY, closeY)
                        val bodyHeight = max(absFloat(openY - closeY), 2.5.dp.toPx())

                        drawRect(
                            color = candleColor,
                            topLeft = Offset(centerX - (candleWidth / 2f), bodyTop),
                            size = Size(candleWidth, bodyHeight)
                        )
                    }
                } else {
                    // Line or Area Chart
                    val path = Path()
                    val areaPath = Path()

                    displayCandles.forEachIndexed { index, candle ->
                        val x = (index * candleStep) + (candleStep / 2f)
                        val y = (chartHeight * (1.0 - ((candle.close - chartMin) / totalSpan))).toFloat()

                        if (index == 0) {
                            path.moveTo(x, y)
                            areaPath.moveTo(x, chartHeight)
                            areaPath.lineTo(x, y)
                        } else {
                            path.lineTo(x, y)
                            areaPath.lineTo(x, y)
                        }
                    }

                    if (chartType == ChartType.AREA && displayCandles.isNotEmpty()) {
                        val lastX = ((displayCandles.size - 1) * candleStep) + (candleStep / 2f)
                        areaPath.lineTo(lastX, chartHeight)
                        areaPath.close()

                        val areaBrush = Brush.verticalGradient(
                            colors = listOf(PrimaryBlue.copy(alpha = 0.35f), Color.Transparent),
                            startY = 0f,
                            endY = chartHeight
                        )
                        drawPath(path = areaPath, brush = areaBrush, style = Fill)
                    }

                    drawPath(
                        path = path,
                        color = PrimaryBlue,
                        style = Stroke(width = 2.dp.toPx())
                    )
                }

                // 3. Render Bollinger Bands Overlay (if calculated)
                if (calculatedIndicators.bollingerUpper.isNotEmpty() && calculatedIndicators.bollingerLower.isNotEmpty()) {
                    val upperPath = Path()
                    val lowerPath = Path()
                    var firstB = true

                    for (i in 0 until visibleCount) {
                        val fullIdx = startIndex + i
                        if (fullIdx in calculatedIndicators.bollingerUpper.indices) {
                            val u = calculatedIndicators.bollingerUpper[fullIdx]
                            val l = calculatedIndicators.bollingerLower[fullIdx]
                            if (u != null && l != null) {
                                val x = (i * candleStep) + (candleStep / 2f)
                                val uy = (chartHeight * (1.0 - ((u - chartMin) / totalSpan))).toFloat()
                                val ly = (chartHeight * (1.0 - ((l - chartMin) / totalSpan))).toFloat()
                                if (firstB) {
                                    upperPath.moveTo(x, uy)
                                    lowerPath.moveTo(x, ly)
                                    firstB = false
                                } else {
                                    upperPath.lineTo(x, uy)
                                    lowerPath.lineTo(x, ly)
                                }
                            }
                        }
                    }
                    drawPath(path = upperPath, color = PrimaryBlueLight.copy(alpha = 0.6f), style = Stroke(width = 1.2.dp.toPx()))
                    drawPath(path = lowerPath, color = PrimaryBlueLight.copy(alpha = 0.6f), style = Stroke(width = 1.2.dp.toPx()))
                }

                // 4. Render Supertrend Line Overlay
                if (calculatedIndicators.supertrendValues.isNotEmpty()) {
                    val stPath = Path()
                    var isFirstSt = true
                    var lastColor = UpGreen

                    for (i in 0 until visibleCount) {
                        val fullIdx = startIndex + i
                        if (fullIdx in calculatedIndicators.supertrendValues.indices) {
                            val stVal = calculatedIndicators.supertrendValues[fullIdx]
                            val isBullish = calculatedIndicators.supertrendIsBullish.getOrNull(fullIdx) ?: true
                            if (stVal != null) {
                                val x = (i * candleStep) + (candleStep / 2f)
                                val y = (chartHeight * (1.0 - ((stVal - chartMin) / totalSpan))).toFloat()
                                lastColor = if (isBullish) UpGreen else DownRed
                                if (isFirstSt) {
                                    stPath.moveTo(x, y)
                                    isFirstSt = false
                                } else {
                                    stPath.lineTo(x, y)
                                }
                            }
                        }
                    }
                    drawPath(path = stPath, color = lastColor.copy(alpha = 0.85f), style = Stroke(width = 1.6.dp.toPx()))
                }

                // 5. Technical Indicator: SMA / EMA line
                val maSeries = if (calculatedIndicators.emaValues.isNotEmpty()) calculatedIndicators.emaValues else calculatedIndicators.smaValues
                if (showSma && maSeries.isNotEmpty()) {
                    val maPath = Path()
                    var isFirstMa = true

                    for (i in 0 until visibleCount) {
                        val fullIdx = startIndex + i
                        if (fullIdx in maSeries.indices) {
                            val avg = maSeries[fullIdx]
                            if (avg != null) {
                                val x = (i * candleStep) + (candleStep / 2f)
                                val y = (chartHeight * (1.0 - ((avg - chartMin) / totalSpan))).toFloat()
                                if (isFirstMa) {
                                    maPath.moveTo(x, y)
                                    isFirstMa = false
                                } else {
                                    maPath.lineTo(x, y)
                                }
                            }
                        }
                    }

                    drawPath(
                        path = maPath,
                        color = GoldAccent.copy(alpha = 0.85f),
                        style = Stroke(width = 1.5.dp.toPx())
                    )
                }

                // 6. Bill Williams Fractals Markers (Arrows)
                calculatedIndicators.bearishFractals.forEach { fIdx ->
                    val relativeIdx = fIdx - startIndex
                    if (relativeIdx in 0 until visibleCount) {
                        val c = displayCandles[relativeIdx]
                        val x = (relativeIdx * candleStep) + (candleStep / 2f)
                        val highY = (chartHeight * (1.0 - ((c.high - chartMin) / totalSpan))).toFloat() - 6.dp.toPx()
                        // Draw Down Arrow for swing high resistance
                        val arrow = Path().apply {
                            moveTo(x, highY - 4.dp.toPx())
                            lineTo(x - 3.dp.toPx(), highY - 8.dp.toPx())
                            lineTo(x + 3.dp.toPx(), highY - 8.dp.toPx())
                            close()
                        }
                        drawPath(arrow, DownRed, style = Fill)
                    }
                }
                calculatedIndicators.bullishFractals.forEach { fIdx ->
                    val relativeIdx = fIdx - startIndex
                    if (relativeIdx in 0 until visibleCount) {
                        val c = displayCandles[relativeIdx]
                        val x = (relativeIdx * candleStep) + (candleStep / 2f)
                        val lowY = (chartHeight * (1.0 - ((c.low - chartMin) / totalSpan))).toFloat() + 6.dp.toPx()
                        // Draw Up Arrow for swing low support
                        val arrow = Path().apply {
                            moveTo(x, lowY + 4.dp.toPx())
                            lineTo(x - 3.dp.toPx(), lowY + 8.dp.toPx())
                            lineTo(x + 3.dp.toPx(), lowY + 8.dp.toPx())
                            close()
                        }
                        drawPath(arrow, UpGreen, style = Fill)
                    }
                }

                // 7. Draw Current Price Live Line & Pulsing Badge
                val currentPriceY = (chartHeight * (1.0 - ((currentPrice - chartMin) / totalSpan))).toFloat()
                if (currentPriceY in 0f..chartHeight) {
                    val priceLineEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 6f), 0f)
                    drawLine(
                        color = UpGreen,
                        start = Offset(0f, currentPriceY),
                        end = Offset(chartWidth, currentPriceY),
                        strokeWidth = 1.6.dp.toPx(),
                        pathEffect = priceLineEffect
                    )

                    // Pulsing Dot at current price on the chart
                    drawCircle(
                        color = UpGreen.copy(alpha = 0.30f),
                        radius = 7.dp.toPx(),
                        center = Offset(chartWidth, currentPriceY)
                    )
                    drawCircle(
                        color = UpGreen,
                        radius = 3.5.dp.toPx(),
                        center = Offset(chartWidth, currentPriceY)
                    )

                    // Right price badge on the axis
                    val priceText = formatPrice(currentPrice, decimals)
                    val badgeLayout = textMeasurer.measure(
                        text = priceText,
                        style = TextStyle(
                            color = BackgroundDark,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    )
                    val badgePaddingH = 4.dp.toPx()
                    val badgePaddingV = 2.5.dp.toPx()
                    val badgeWidth = badgeLayout.size.width + badgePaddingH * 2
                    val badgeHeight = badgeLayout.size.height + badgePaddingV * 2

                    drawRoundRect(
                        color = UpGreen,
                        topLeft = Offset(chartWidth + 3.dp.toPx(), currentPriceY - (badgeHeight / 2f)),
                        size = Size(badgeWidth, badgeHeight),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(4.dp.toPx(), 4.dp.toPx())
                    )
                    drawText(
                        textLayoutResult = badgeLayout,
                        topLeft = Offset(chartWidth + 3.dp.toPx() + badgePaddingH, currentPriceY - (badgeLayout.size.height / 2f))
                    )
                }

                // 8. Draw Active Trades Entry Lines, Badges & Vertical Expiry Line
                activeTrades.forEachIndexed { tIdx, trade ->
                    val tradeY = (chartHeight * (1.0 - ((trade.entryPrice - chartMin) / totalSpan))).toFloat()
                    if (tradeY in 0f..chartHeight) {
                        val isWin = trade.isWinning(currentPrice)
                        val tradeColor = if (isWin) UpGreen else DownRed
                        val tradeLineEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 4f), 0f)

                        drawLine(
                            color = tradeColor,
                            start = Offset(0f, tradeY),
                            end = Offset(chartWidth, tradeY),
                            strokeWidth = 2.dp.toPx(),
                            pathEffect = tradeLineEffect
                        )

                        // Trade Entry Marker Pill
                        val tradeText = "${if (trade.direction == "UP") "▲ UP" else "▼ DOWN"} $${trade.amount.toInt()} (${trade.remainingSeconds()}s)"
                        val tradeLayout = textMeasurer.measure(
                            text = tradeText,
                            style = TextStyle(
                                color = Color.White,
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        val tPadding = 3.dp.toPx()
                        drawRoundRect(
                            color = if (trade.direction == "UP") UpGreenDark else DownRedDark,
                            topLeft = Offset(10.dp.toPx(), tradeY - 12.dp.toPx() - (tIdx * 18.dp.toPx())),
                            size = Size(tradeLayout.size.width + tPadding * 2, tradeLayout.size.height + tPadding * 2),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(4.dp.toPx(), 4.dp.toPx())
                        )
                        drawText(
                            textLayoutResult = tradeLayout,
                            topLeft = Offset(10.dp.toPx() + tPadding, tradeY - 12.dp.toPx() + tPadding - (tIdx * 18.dp.toPx()))
                        )

                        // Vertical Expiry Marker Line on right side of chart
                        val remainingSec = trade.remainingSeconds()
                        val totalSec = max(1, trade.durationSeconds)
                        val progressFraction = (remainingSec.toFloat() / totalSec.toFloat()).coerceIn(0f, 1f)
                        val expiryX = chartWidth * (0.5f + (0.45f * (1f - progressFraction)))

                        drawLine(
                            color = GoldAccent.copy(alpha = 0.6f),
                            start = Offset(expiryX, 0f),
                            end = Offset(expiryX, chartHeight),
                            strokeWidth = 1.2.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f), 0f)
                        )

                        // Expiry flag at top of line
                        val expLabel = textMeasurer.measure(
                            text = "EXPIRY ${remainingSec}s",
                            style = TextStyle(color = BackgroundDark, fontSize = 7.5.sp, fontWeight = FontWeight.Black)
                        )
                        drawRoundRect(
                            color = GoldAccent,
                            topLeft = Offset(expiryX - (expLabel.size.width / 2f) - 3.dp.toPx(), 2.dp.toPx()),
                            size = Size(expLabel.size.width + 6.dp.toPx(), expLabel.size.height + 3.dp.toPx()),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(3.dp.toPx(), 3.dp.toPx())
                        )
                        drawText(
                            textLayoutResult = expLabel,
                            topLeft = Offset(expiryX - (expLabel.size.width / 2f), 3.5.dp.toPx())
                        )
                    }
                }

                // 9. Scrubber Crosshair overlay when touched
                if (selectedCandleIndex != null && selectedCandleIndex!! in candles.indices) {
                    val relativeIdx = selectedCandleIndex!! - startIndex
                    if (relativeIdx in 0 until visibleCount) {
                        val sc = displayCandles[relativeIdx]
                        val x = (relativeIdx * candleStep) + (candleStep / 2f)
                        val y = (chartHeight * (1.0 - ((sc.close - chartMin) / totalSpan))).toFloat()

                        drawLine(
                            color = CrosshairColor,
                            start = Offset(x, 0f),
                            end = Offset(x, chartHeight),
                            strokeWidth = 1.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f), 0f)
                        )
                        drawLine(
                            color = CrosshairColor,
                            start = Offset(0f, y),
                            end = Offset(chartWidth, y),
                            strokeWidth = 1.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f), 0f)
                        )
                        drawCircle(color = PrimaryBlue, radius = 4.dp.toPx(), center = Offset(x, y))
                    }
                }
            }
        }
    }
}

fun formatPrice(price: Double, decimals: Int): String {
    return String.format(Locale.US, "%.${decimals}f", price)
}

private fun absFloat(v: Float): Float = if (v < 0) -v else v

private fun calculateIndexFromOffset(
    touchX: Float,
    canvasWidth: Float,
    visibleCount: Int,
    totalCandles: Int
): Int {
    if (visibleCount <= 0 || canvasWidth <= 0f) return totalCandles - 1
    val candleStep = canvasWidth / visibleCount
    val localIndex = (touchX / candleStep).toInt().coerceIn(0, visibleCount - 1)
    val startIndex = totalCandles - visibleCount
    return startIndex + localIndex
}
