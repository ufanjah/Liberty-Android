package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.config.PepperstoneConfig
import com.example.data.SavedBankAccountEntity
import com.example.data.TransactionEntity
import com.example.ui.ScreenTab
import com.example.ui.TradingViewModel
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun WalletScreen(
    viewModel: TradingViewModel,
    modifier: Modifier = Modifier
) {
    val account by viewModel.account.collectAsState()
    val allTransactions by viewModel.allTransactions.collectAsState()
    val allTrades by viewModel.allTrades.collectAsState()
    val savedAccounts by viewModel.savedBankAccounts.collectAsState()
    val context = LocalContext.current

    val totalPnl = allTrades.sumOf { it.profitOrLoss }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 28.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Demo Wallet",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "Virtual simulation balances & cashflow",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = GoldGlow
                ) {
                    Text(
                        text = "SIMULATOR",
                        color = GoldAccent,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        // Available Balance Hero Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "AVAILABLE BALANCE",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary,
                            letterSpacing = 1.sp
                        )
                        Icon(
                            imageVector = Icons.Default.AccountBalanceWallet,
                            contentDescription = null,
                            tint = GoldAccent,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Text(
                        text = "$${String.format(Locale.US, "%,.2f", account.availableBalance)}",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Black,
                        color = TextPrimary,
                        letterSpacing = 0.5.sp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Demo Total: $${String.format(Locale.US, "%,.2f", account.demoBalance)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                        Text(
                            text = "Status: Demo Active",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = UpGreen
                        )
                    }

                    // Main Action Buttons: DEPOSIT and WITHDRAW
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { viewModel.selectTab(ScreenTab.DEPOSIT) },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("wallet_deposit_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = UpGreen),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(imageVector = Icons.Default.AddCircle, contentDescription = null, tint = BackgroundDark, modifier = Modifier.size(18.dp))
                                Text(text = "DEPOSIT", fontWeight = FontWeight.Black, fontSize = 14.sp, color = BackgroundDark)
                            }
                        }

                        Button(
                            onClick = { viewModel.selectTab(ScreenTab.WITHDRAW) },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("wallet_withdraw_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(imageVector = Icons.Default.ArrowOutward, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                Text(text = "WITHDRAW", fontWeight = FontWeight.Black, fontSize = 14.sp, color = Color.White)
                            }
                        }
                    }
                }
            }
        }

        // Requirement 12: Wallet Analytics Breakdown
        item {
            Text(
                text = "Wallet Analytics",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = SurfaceDark,
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    WalletMetricRow("Available Balance", "$${String.format(Locale.US, "%,.2f", account.availableBalance)}")
                    HorizontalDivider(color = CardBorder, thickness = 0.5.dp)
                    WalletMetricRow("Pending Deposits", "$${String.format(Locale.US, "%,.2f", account.pendingDeposits)}", valueColor = GoldAccent)
                    HorizontalDivider(color = CardBorder, thickness = 0.5.dp)
                    WalletMetricRow("Pending Withdrawals", "$${String.format(Locale.US, "%,.2f", account.pendingWithdrawals)}", valueColor = GoldAccent)
                    HorizontalDivider(color = CardBorder, thickness = 0.5.dp)
                    WalletMetricRow("Total Deposits", "$${String.format(Locale.US, "%,.2f", account.totalDeposits)}", valueColor = UpGreen)
                    HorizontalDivider(color = CardBorder, thickness = 0.5.dp)
                    WalletMetricRow("Total Withdrawals", "$${String.format(Locale.US, "%,.2f", account.totalWithdrawals)}", valueColor = TextSecondary)
                    HorizontalDivider(color = CardBorder, thickness = 0.5.dp)
                    WalletMetricRow(
                        "Profit/Loss",
                        "${if (totalPnl >= 0) "+" else ""}$${String.format(Locale.US, "%.2f", totalPnl)}",
                        valueColor = if (totalPnl >= 0) UpGreen else DownRed
                    )
                }
            }
        }

        // Requirement 12: Linked Bank Accounts Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(imageVector = Icons.Default.AccountBalance, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(18.dp))
                    Text(
                        text = "Linked Bank Accounts (${savedAccounts.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                TextButton(
                    onClick = { viewModel.selectTab(ScreenTab.BANK_ACCOUNTS) },
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text(
                        text = "Manage →",
                        style = MaterialTheme.typography.labelSmall,
                        color = PrimaryBlue,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        if (savedAccounts.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = SurfaceDark,
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.selectTab(ScreenTab.BANK_ACCOUNTS) }
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "No bank accounts linked yet", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                            Text(text = "Tap to verify and link your Nigerian bank", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        }
                        Icon(imageVector = Icons.Default.AddCircleOutline, contentDescription = null, tint = PrimaryBlue)
                    }
                }
            }
        } else {
            items(savedAccounts.take(2), key = { it.id }) { acc ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = SurfaceDark,
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.selectTab(ScreenTab.BANK_ACCOUNTS) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(text = acc.bankName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                                if (acc.isDefault) {
                                    Surface(shape = RoundedCornerShape(4.dp), color = UpGreenGlow) {
                                        Text(text = "DEFAULT", color = UpGreen, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                    }
                                }
                            }
                            Text(text = "${acc.accountName} • ${acc.maskedAccountNumber}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Surface(shape = RoundedCornerShape(6.dp), color = PrimaryBlue.copy(alpha = 0.2f)) {
                            Text(text = "VERIFIED", color = PrimaryBlue, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp))
                        }
                    }
                }
            }
        }

        // Trading Account Status Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("trading_account_card")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .background(
                                        brush = Brush.linearGradient(listOf(PrimaryBlue, UpGreen)),
                                        shape = RoundedCornerShape(10.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.TrendingUp,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "LIBERTY TRADING ACCOUNT",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "Internal Direct Execution",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary
                                )
                            }
                        }

                        Surface(shape = RoundedCornerShape(6.dp), color = UpGreenGlow) {
                            Text(
                                text = "ACTIVE",
                                color = UpGreen,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                fontSize = 8.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    HorizontalDivider(color = CardBorder, thickness = 0.5.dp)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "ACCOUNT STATUS", style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontSize = 8.sp)
                            Text(text = "VERIFIED", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = UpGreen)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "ACCOUNT TYPE", style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontSize = 8.sp)
                            Text(text = "DEMO", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = GoldAccent)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "TRADING STATUS", style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontSize = 8.sp)
                            Text(text = "ACTIVE", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = TextPrimary)
                        }
                    }

                    HorizontalDivider(color = CardBorder, thickness = 0.5.dp)

                    // Pepperstone Broker Option & Quick Actions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            modifier = Modifier
                                .clickable { PepperstoneConfig.openPepperstone(context) }
                                .testTag("pepperstone_broker_option_label")
                        ) {
                            Text(
                                text = "BROKER OPTION",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = "Pepperstone",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = GoldAccent
                                )
                                Icon(
                                    imageVector = Icons.Default.OpenInBrowser,
                                    contentDescription = null,
                                    tint = GoldAccent,
                                    modifier = Modifier.size(13.dp)
                                )
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(
                                onClick = { PepperstoneConfig.openPepperstone(context) },
                                modifier = Modifier
                                    .height(34.dp)
                                    .testTag("open_pepperstone_button"),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
                            ) {
                                Text(
                                    text = "Open Pepperstone",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            }

                            Button(
                                onClick = { PepperstoneConfig.openPepperstone(context) },
                                modifier = Modifier
                                    .height(34.dp)
                                    .testTag("trade_with_pepperstone_button"),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                            ) {
                                Text(
                                    text = "Trade with Pepperstone",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }

        // Admin Controls Shortcut Card
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = SurfaceVariantDark,
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.selectTab(ScreenTab.ADMIN_SETTINGS) }
                    .testTag("admin_settings_card")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.AdminPanelSettings, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(20.dp))
                        Column {
                            Text(text = "Payment Administration", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text(text = "Deposit/withdrawal limits & gateway toggles", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        }
                    }
                    Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = TextMuted)
                }
            }
        }

        // Recent Transactions Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Recent Transactions",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                TextButton(
                    onClick = { viewModel.selectTab(ScreenTab.TRANSACTIONS) },
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text(
                        text = "View All →",
                        style = MaterialTheme.typography.labelSmall,
                        color = PrimaryBlue,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        if (allTransactions.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = SurfaceDark,
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(imageVector = Icons.Default.ReceiptLong, contentDescription = null, tint = TextMuted, modifier = Modifier.size(36.dp))
                        Text(text = "No transactions yet", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                        Text(text = "Test a demo deposit or withdrawal above", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    }
                }
            }
        } else {
            items(allTransactions.take(3), key = { it.id }) { tx ->
                TransactionCardItem(tx = tx)
            }
        }

        // Safety Disclaimer Card
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = SurfaceVariantDark,
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = "Demo Notice",
                        tint = GoldAccent,
                        modifier = Modifier.size(22.dp)
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = "DEMO SIMULATION DISCLOSURE",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = GoldAccent
                        )
                        Text(
                            text = "This wallet uses virtual demo funds. No real fiat or cryptocurrency deposits or withdrawals are executed. All transactions are local simulations for training.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TransactionCardItem(tx: TransactionEntity) {
    val isDeposit = tx.type == "DEPOSIT"
    val timeFormat = remember { SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault()) }
    val formattedTime = remember(tx.timestamp) { timeFormat.format(Date(tx.timestamp)) }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = SurfaceDark,
        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
        modifier = Modifier.fillMaxWidth().testTag("transaction_item_${tx.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(if (isDeposit) UpGreenGlow else GoldGlow, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isDeposit) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                        contentDescription = tx.type,
                        tint = if (isDeposit) UpGreen else GoldAccent,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Column {
                    Text(
                        text = if (isDeposit) "Demo Deposit" else "Demo Withdrawal",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "${tx.method} • $formattedTime",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                    Text(
                        text = "Ref: ${tx.reference}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted,
                        fontSize = 9.sp
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${if (isDeposit) "+" else "-"}$${String.format(Locale.US, "%.2f", tx.amount)}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (isDeposit) UpGreen else TextPrimary
                )
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = if (tx.status.contains("COMPLETED")) UpGreenGlow else GoldGlow
                ) {
                    Text(
                        text = tx.status,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (tx.status.contains("COMPLETED")) UpGreen else GoldAccent,
                        fontWeight = FontWeight.Bold,
                        fontSize = 8.sp,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun WalletMetricRow(label: String, value: String, valueColor: Color = TextPrimary) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
        Text(text = value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = valueColor)
    }
}
