package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.UserProfileEntity
import com.example.ui.TradingViewModel
import com.example.ui.theme.*

@Composable
fun ProfileScreen(
    viewModel: TradingViewModel,
    modifier: Modifier = Modifier
) {
    val profile by viewModel.userProfile.collectAsState()

    var isEditing by remember { mutableStateOf(false) }

    // Editable form state
    var editFullName by remember(profile) { mutableStateOf(profile.fullName) }
    var editUsername by remember(profile) { mutableStateOf(profile.username) }
    var editEmail by remember(profile) { mutableStateOf(profile.email) }
    var editPhone by remember(profile) { mutableStateOf(profile.phoneNumber) }
    var editAddress by remember(profile) { mutableStateOf(profile.address) }
    var editCity by remember(profile) { mutableStateOf(profile.city) }
    var editState by remember(profile) { mutableStateOf(profile.state) }
    var editCountry by remember(profile) { mutableStateOf(profile.country) }
    var editAvatarId by remember(profile) { mutableStateOf(profile.avatarId) }

    var showAvatarPicker by remember { mutableStateOf(false) }
    var showPasswordDialog by remember { mutableStateOf(false) }
    var showLogoutDialog by remember { mutableStateOf(false) }
    var is2FaActive by remember(profile) { mutableStateOf(profile.isTwoFactorEnabled) }

    val avatarEmojis = listOf("👨‍💼", "👩‍💼", "🧑‍💻", "🦁", "🦅", "💎")

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 32.dp)
    ) {
        // Profile Header with Avatar & Name
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                modifier = Modifier.fillMaxWidth().testTag("profile_header_card")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Profile Picture with Change overlay
                    Box(
                        contentAlignment = Alignment.BottomEnd,
                        modifier = Modifier
                            .size(80.dp)
                            .clickable { showAvatarPicker = true }
                            .testTag("avatar_button")
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    brush = Brush.linearGradient(listOf(PrimaryBlue, UpGreen)),
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = avatarEmojis.getOrElse(editAvatarId) { "👨‍💼" },
                                fontSize = 38.sp
                            )
                        }
                        Box(
                            modifier = Modifier
                                .size(26.dp)
                                .background(SurfaceDark, CircleShape)
                                .padding(2.dp)
                                .background(PrimaryBlue, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Change Avatar",
                                tint = Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = profile.fullName,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "@${profile.username}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = GoldAccent
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = UpGreenGlow
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Verified, contentDescription = null, tint = UpGreen, modifier = Modifier.size(14.dp))
                            Text(
                                text = "DEMO VERIFIED TRADER",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = UpGreen,
                                fontSize = 9.sp
                            )
                        }
                    }
                }
            }
        }

        // Edit / Save Buttons Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Personal Information",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )

                if (!isEditing) {
                    TextButton(
                        onClick = { isEditing = true },
                        modifier = Modifier.testTag("edit_profile_button")
                    ) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp), tint = PrimaryBlue)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Edit Profile", color = PrimaryBlue, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(
                            onClick = {
                                // Reset to saved profile
                                editFullName = profile.fullName
                                editUsername = profile.username
                                editEmail = profile.email
                                editPhone = profile.phoneNumber
                                editAddress = profile.address
                                editCity = profile.city
                                editState = profile.state
                                editCountry = profile.country
                                editAvatarId = profile.avatarId
                                isEditing = false
                            },
                            modifier = Modifier.testTag("cancel_edit_button")
                        ) {
                            Text("Cancel", color = TextSecondary)
                        }

                        Button(
                            onClick = {
                                val updated = profile.copy(
                                    fullName = editFullName.trim(),
                                    username = editUsername.trim(),
                                    email = editEmail.trim(),
                                    phoneNumber = editPhone.trim(),
                                    address = editAddress.trim(),
                                    city = editCity.trim(),
                                    state = editState.trim(),
                                    country = editCountry.trim(),
                                    avatarId = editAvatarId
                                )
                                viewModel.updateProfile(updated)
                                isEditing = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = UpGreen),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("save_profile_button")
                        ) {
                            Text("Save Changes", color = BackgroundDark, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Profile Details Form Fields
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = SurfaceDark,
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    ProfileFieldItem("Full Name", editFullName, isEditing) { editFullName = it }
                    HorizontalDivider(color = CardBorder, thickness = 0.5.dp)
                    ProfileFieldItem("Username", editUsername, isEditing) { editUsername = it }
                    HorizontalDivider(color = CardBorder, thickness = 0.5.dp)
                    ProfileFieldItem("Email Address", editEmail, isEditing) { editEmail = it }
                    HorizontalDivider(color = CardBorder, thickness = 0.5.dp)
                    ProfileFieldItem("Phone Number", editPhone, isEditing) { editPhone = it }
                    HorizontalDivider(color = CardBorder, thickness = 0.5.dp)
                    ProfileFieldItem("Residential Address", editAddress, isEditing) { editAddress = it }
                    HorizontalDivider(color = CardBorder, thickness = 0.5.dp)
                    ProfileFieldItem("City", editCity, isEditing) { editCity = it }
                    HorizontalDivider(color = CardBorder, thickness = 0.5.dp)
                    ProfileFieldItem("State", editState, isEditing) { editState = it }
                    HorizontalDivider(color = CardBorder, thickness = 0.5.dp)
                    ProfileFieldItem("Country", editCountry, isEditing) { editCountry = it }
                }
            }
        }

        // Requirement 9: ACCOUNT SECURITY
        item {
            Text(
                text = "Account Security",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = SurfaceDark,
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Change Password
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showPasswordDialog = true }
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(20.dp))
                            Column {
                                Text(text = "Change Password", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                                Text(text = "Simulated security credentials", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                        }
                        Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = TextMuted)
                    }

                    HorizontalDivider(color = CardBorder, thickness = 0.5.dp)

                    // Two-Factor Authentication
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(20.dp))
                            Column {
                                Text(text = "Two-Factor Authentication", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                                Text(text = if (is2FaActive) "Enabled (Demo OTP Active)" else "Disabled (Tap to enable)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                        }
                        Switch(
                            checked = is2FaActive,
                            onCheckedChange = { checked ->
                                is2FaActive = checked
                                viewModel.updateProfile(profile.copy(isTwoFactorEnabled = checked))
                                viewModel.addNotification(
                                    "Security Setting Changed",
                                    "Two-factor authentication is now ${if (checked) "enabled" else "disabled"}.",
                                    "SECURITY"
                                )
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = UpGreen)
                        )
                    }

                    HorizontalDivider(color = CardBorder, thickness = 0.5.dp)

                    // Login Sessions
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Devices, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(20.dp))
                            Column {
                                Text(text = "Login Sessions", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                                Text(text = profile.lastLoginSession, style = MaterialTheme.typography.labelSmall, color = UpGreen)
                            }
                        }
                        Surface(shape = RoundedCornerShape(4.dp), color = UpGreenGlow) {
                            Text(text = "ACTIVE", style = MaterialTheme.typography.labelSmall, color = UpGreen, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                    }

                    HorizontalDivider(color = CardBorder, thickness = 0.5.dp)

                    // Logout
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showLogoutDialog = true }
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Logout, contentDescription = null, tint = DownRed, modifier = Modifier.size(20.dp))
                            Text(text = "Logout (Demo Session)", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = DownRed)
                        }
                        Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = TextMuted)
                    }
                }
            }
        }
    }

    // Avatar Picker Dialog
    if (showAvatarPicker) {
        AlertDialog(
            onDismissRequest = { showAvatarPicker = false },
            containerColor = SurfaceDark,
            title = { Text("Choose Trader Avatar", fontWeight = FontWeight.Bold, color = TextPrimary) },
            text = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    avatarEmojis.forEachIndexed { idx, emoji ->
                        Surface(
                            onClick = {
                                editAvatarId = idx
                                viewModel.updateProfile(profile.copy(avatarId = idx))
                                showAvatarPicker = false
                            },
                            shape = CircleShape,
                            color = if (editAvatarId == idx) PrimaryBlue.copy(alpha = 0.4f) else SurfaceVariantDark,
                            border = if (editAvatarId == idx) androidx.compose.foundation.BorderStroke(2.dp, PrimaryBlue) else null,
                            modifier = Modifier.size(48.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(text = emoji, fontSize = 24.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {}
        )
    }

    // Password Change Dialog
    if (showPasswordDialog) {
        var oldPass by remember { mutableStateOf("") }
        var newPass by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showPasswordDialog = false },
            containerColor = SurfaceDark,
            title = { Text("Change Password", fontWeight = FontWeight.Bold, color = TextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Enter demo security credentials:", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    OutlinedTextField(
                        value = oldPass,
                        onValueChange = { oldPass = it },
                        label = { Text("Current Password") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = PrimaryBlue, focusedTextColor = TextPrimary)
                    )
                    OutlinedTextField(
                        value = newPass,
                        onValueChange = { newPass = it },
                        label = { Text("New Password") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = PrimaryBlue, focusedTextColor = TextPrimary)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showPasswordDialog = false
                        viewModel.addNotification("Password Updated", "Your demo security password was successfully changed.", "SECURITY")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                ) {
                    Text("Save Password", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showPasswordDialog = false }) { Text("Cancel", color = TextSecondary) }
            }
        )
    }

    // Logout Dialog
    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            containerColor = SurfaceDark,
            title = { Text("Demo Logout", fontWeight = FontWeight.Bold, color = TextPrimary) },
            text = { Text("In demo mode, logout resets your current session view.", color = TextSecondary) },
            confirmButton = {
                Button(
                    onClick = {
                        showLogoutDialog = false
                        viewModel.addNotification("Session Ended", "Logged out of current demo session.", "SECURITY")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DownRed)
                ) {
                    Text("Confirm Logout", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutDialog = false }) { Text("Cancel", color = TextSecondary) }
            }
        )
    }
}

@Composable
private fun ProfileFieldItem(
    label: String,
    value: String,
    isEditing: Boolean,
    onValueChange: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontSize = 9.sp)
        if (isEditing) {
            OutlinedTextField(
                value = value,
                onValueChange = onValueChange,
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PrimaryBlue,
                    unfocusedBorderColor = CardBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                modifier = Modifier.fillMaxWidth()
            )
        } else {
            Text(
                text = value.ifBlank { "Not set" },
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                color = TextPrimary
            )
        }
    }
}
