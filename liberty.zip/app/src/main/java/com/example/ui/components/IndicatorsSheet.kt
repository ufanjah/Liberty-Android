package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.service.market.IndicatorCategory
import com.example.service.market.IndicatorDefinition
import com.example.service.market.IndicatorEngine
import com.example.service.market.IndicatorInstance
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IndicatorsSheet(
    activeIndicators: List<IndicatorInstance>,
    onAddIndicator: (IndicatorDefinition) -> Unit,
    onToggleVisibility: (String) -> Unit,
    onRemoveIndicator: (String) -> Unit,
    onEditIndicator: (IndicatorInstance) -> Unit,
    onResetIndicator: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<IndicatorCategory?>(null) }

    val filteredCatalog = remember(searchQuery, selectedCategory) {
        IndicatorEngine.CATALOG.filter { def ->
            val matchesCategory = selectedCategory == null || def.category == selectedCategory
            val matchesQuery = searchQuery.isBlank() || def.name.contains(searchQuery, ignoreCase = true)
            matchesCategory && matchesQuery
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = SurfaceDark,
        contentColor = TextPrimary,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        dragHandle = {
            BottomSheetDefaults.DragHandle(color = CardBorder)
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Technical Indicators",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "Real mathematical algorithms computed on live candles",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                }
            }

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search indicators (e.g. RSI, MACD, Bollinger)...", fontSize = 12.sp, color = TextMuted) },
                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = TextSecondary) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear", tint = TextSecondary)
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("indicator_search_input"),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PrimaryBlue,
                    unfocusedBorderColor = CardBorder,
                    focusedContainerColor = SurfaceVariantDark,
                    unfocusedContainerColor = SurfaceVariantDark
                ),
                shape = RoundedCornerShape(10.dp)
            )

            // Category Filter Chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    FilterChip(
                        selected = selectedCategory == null,
                        onClick = { selectedCategory = null },
                        label = { Text("All", fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PrimaryBlue,
                            selectedLabelColor = Color.White
                        )
                    )
                }
                items(IndicatorCategory.entries.toTypedArray()) { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat.label, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PrimaryBlue,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                // Section 1: Active Configured Indicators
                if (activeIndicators.isNotEmpty()) {
                    item {
                        Text(
                            text = "ACTIVE INDICATORS (${activeIndicators.size})",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = GoldAccent,
                            fontSize = 10.sp
                        )
                    }

                    items(activeIndicators, key = { it.id }) { instance ->
                        ActiveIndicatorCard(
                            instance = instance,
                            onToggleVisibility = { onToggleVisibility(instance.id) },
                            onEdit = { onEditIndicator(instance) },
                            onReset = { onResetIndicator(instance.id) },
                            onRemove = { onRemoveIndicator(instance.id) }
                        )
                    }

                    item {
                        HorizontalDivider(color = CardBorder, modifier = Modifier.padding(vertical = 4.dp))
                    }
                }

                // Section 2: Catalog to Add
                item {
                    Text(
                        text = "INDICATOR CATALOG",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary,
                        fontSize = 10.sp
                    )
                }

                items(filteredCatalog, key = { it.id }) { def ->
                    CatalogIndicatorRow(
                        definition = def,
                        onAdd = { onAddIndicator(def) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ActiveIndicatorCard(
    instance: IndicatorInstance,
    onToggleVisibility: () -> Unit,
    onEdit: () -> Unit,
    onReset: () -> Unit,
    onRemove: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = SurfaceVariantDark,
        border = androidx.compose.foundation.BorderStroke(1.dp, if (instance.isVisible) PrimaryBlue.copy(alpha = 0.5f) else CardBorder),
        modifier = Modifier.fillMaxWidth().testTag("active_indicator_${instance.definitionId}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .background(instance.color, CircleShape)
                )
                Column {
                    Text(
                        text = instance.name,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = if (instance.isVisible) TextPrimary else TextMuted
                    )
                    val paramSummary = instance.parameters.entries.joinToString(", ") { "${it.key}: ${it.value.toInt()}" }
                    if (paramSummary.isNotBlank()) {
                        Text(
                            text = paramSummary,
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 9.sp,
                            color = TextSecondary
                        )
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                // Visibility toggle
                IconButton(onClick = onToggleVisibility, modifier = Modifier.size(30.dp)) {
                    Icon(
                        imageVector = if (instance.isVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                        contentDescription = "Toggle Visibility",
                        tint = if (instance.isVisible) PrimaryBlue else TextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                }
                // Edit parameters
                IconButton(onClick = onEdit, modifier = Modifier.size(30.dp)) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "Edit Settings",
                        tint = TextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                }
                // Reset parameters
                IconButton(onClick = onReset, modifier = Modifier.size(30.dp)) {
                    Icon(
                        imageVector = Icons.Default.RestartAlt,
                        contentDescription = "Reset Settings",
                        tint = TextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                }
                // Remove
                IconButton(onClick = onRemove, modifier = Modifier.size(30.dp)) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "Remove",
                        tint = DownRed,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun CatalogIndicatorRow(
    definition: IndicatorDefinition,
    onAdd: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = SurfaceDark,
        border = androidx.compose.foundation.BorderStroke(0.5.dp, CardBorder),
        modifier = Modifier.fillMaxWidth().testTag("catalog_indicator_${definition.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = definition.name,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary
                )
                Text(
                    text = definition.description,
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 9.sp,
                    color = TextMuted
                )
            }

            Button(
                onClick = onAdd,
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                modifier = Modifier.height(32.dp)
            ) {
                Text(text = "+ ADD", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
