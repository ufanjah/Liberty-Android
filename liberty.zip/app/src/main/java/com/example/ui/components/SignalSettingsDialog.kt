package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.service.market.SignalSettings
import com.example.ui.theme.*

@Composable
fun SignalSettingsDialog(
    currentSettings: SignalSettings,
    onSave: (SignalSettings) -> Unit,
    onDismiss: () -> Unit
) {
    var useTrend by remember { mutableStateOf(currentSettings.useTrendEma) }
    var useRsi by remember { mutableStateOf(currentSettings.useRsi) }
    var useMacd by remember { mutableStateOf(currentSettings.useMacd) }
    var useSupertrend by remember { mutableStateOf(currentSettings.useSupertrend) }
    var minConfirmations by remember { mutableIntStateOf(currentSettings.minConfirmationsRequired) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = SurfaceDark,
            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
            modifier = Modifier.fillMaxWidth().testTag("signal_settings_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Signal Engine Configuration",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "Multi-indicator confirmation rules",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                HorizontalDivider(color = CardBorder)

                // Switches for signal rules
                SignalToggleRow(title = "Trend Confirmation (EMA)", isChecked = useTrend, onCheckedChange = { useTrend = it })
                SignalToggleRow(title = "Momentum Confirmation (RSI 14)", isChecked = useRsi, onCheckedChange = { useRsi = it })
                SignalToggleRow(title = "MACD Histogram Confirmation", isChecked = useMacd, onCheckedChange = { useMacd = it })
                SignalToggleRow(title = "Supertrend Confirmation", isChecked = useSupertrend, onCheckedChange = { useSupertrend = it })

                // Minimum Confirmations Slider/Picker
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Min Confirmations Needed", style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        (1..4).forEach { count ->
                            FilterChip(
                                selected = minConfirmations == count,
                                onClick = { minConfirmations = count },
                                label = { Text("$count", fontWeight = FontWeight.Bold) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PrimaryBlue,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                }

                // Disclaimer
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = SurfaceVariantDark,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.Top,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(16.dp))
                        Text(
                            text = "Signal conditions are purely technical heuristics to assist practice analysis. No trading system or indicator guarantees market success.",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary,
                            fontSize = 9.sp,
                            lineHeight = 13.sp
                        )
                    }
                }

                // Save Button
                Button(
                    onClick = {
                        onSave(
                            SignalSettings(
                                useTrendEma = useTrend,
                                useRsi = useRsi,
                                useMacd = useMacd,
                                useSupertrend = useSupertrend,
                                minConfirmationsRequired = minConfirmations
                            )
                        )
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth().height(44.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                ) {
                    Text(text = "SAVE SIGNAL SETTINGS", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun SignalToggleRow(
    title: String,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = title, style = MaterialTheme.typography.bodySmall, color = TextPrimary)
        Switch(
            checked = isChecked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = PrimaryBlue)
        )
    }
}
