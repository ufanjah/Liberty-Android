package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TradeEntity
import com.example.ui.HistoryFilter
import com.example.ui.TradingViewModel
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HistoryScreen(
    viewModel: TradingViewModel,
    modifier: Modifier = Modifier
) {
    val allTrades by viewModel.allTrades.collectAsState()
    val filteredTrades by viewModel.filteredTrades.collectAsState()
    val currentFilter by viewModel.historyFilter.collectAsState()
    val account by viewModel.account.collectAsState()

    var showClearDialog by remember { mutableStateOf(false) }

    val wonCount = allTrades.count { it.result == "WIN" || it.result == "WON" }
    val lostCount = allTrades.count { it.result == "LOSS" || it.result == "LOST" }
    val drawCount = allTrades.count { it.result == "DRAW" || it.result == "TIE" }
    val totalCount = allTrades.size
    val winRate = if (totalCount > 0) (wonCount.toDouble() / totalCount) * 100 else 0.0
    val totalInvestment = allTrades.sumOf { it.amount }
    val netPnl = allTrades.sumOf { it.profitOrLoss }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(horizontal = 16.dp)
    ) {
        // Screen Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Demo Trade History",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "Recorded practice executions & audited metrics",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }

            if (allTrades.isNotEmpty()) {
                IconButton(
                    onClick = { showClearDialog = true },
                    modifier = Modifier.testTag("clear_history_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteSweep,
                        contentDescription = "Clear History",
                        tint = DownRed
                    )
                }
            }
        }

        // Summary Stats Grid (Total Trades, Wins/Losses/Draws, Win Rate, Volume, Net PnL)
        Column(
            modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                StatCard(
                    title = "Total Trades",
                    value = "$totalCount",
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Wins / Losses / Draws",
                    value = "$wonCount / $lostCount / $drawCount",
                    valueColor = GoldAccent,
                    modifier = Modifier.weight(1.4f)
                )
                StatCard(
                    title = "Win Rate",
                    value = "${String.format(Locale.US, "%.1f", winRate)}%",
                    valueColor = if (winRate >= 50) UpGreen else GoldAccent,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                StatCard(
                    title = "Total Demo Investment",
                    value = "$${String.format(Locale.US, "%,.2f", totalInvestment)}",
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Net Demo Profit/Loss",
                    value = "${if (netPnl >= 0) "+" else ""}$${String.format(Locale.US, "%,.2f", netPnl)}",
                    valueColor = if (netPnl >= 0) UpGreen else DownRed,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Filter Tabs (ALL / WINS / LOSSES / DRAWS)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            HistoryFilter.entries.forEach { filter ->
                val isSelected = currentFilter == filter
                val label = when (filter) {
                    HistoryFilter.ALL -> "ALL ($totalCount)"
                    HistoryFilter.WINS -> "WINS ($wonCount)"
                    HistoryFilter.LOSSES -> "LOSSES ($lostCount)"
                    HistoryFilter.DRAWS -> "DRAWS ($drawCount)"
                }
                Surface(
                    onClick = { viewModel.setHistoryFilter(filter) },
                    shape = RoundedCornerShape(16.dp),
                    color = if (isSelected) PrimaryBlue else SurfaceVariantDark,
                    modifier = Modifier.testTag("filter_tab_${filter.name}")
                ) {
                    Text(
                        text = label,
                        color = if (isSelected) TextPrimary else TextSecondary,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }

        // List of Trades
        if (filteredTrades.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = null,
                        tint = TextMuted,
                        modifier = Modifier.size(56.dp)
                    )
                    Text(
                        text = "No trades recorded yet",
                        style = MaterialTheme.typography.bodyLarge,
                        color = TextSecondary,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "Place a demo trade on the Trade tab to see results here",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(filteredTrades, key = { it.id }) { trade ->
                    TradeHistoryCard(trade = trade)
                }
            }
        }
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            containerColor = SurfaceDark,
            title = { Text(text = "Clear History", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = { Text("Are you sure you want to clear all demo trade history?", color = TextSecondary) },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearHistory()
                        showClearDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DownRed)
                ) {
                    Text("Clear", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    valueColor: Color = TextPrimary,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = SurfaceDark,
        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                fontSize = 9.sp
            )
            Text(
                text = value,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = valueColor,
                maxLines = 1
            )
        }
    }
}

@Composable
fun TradeHistoryCard(trade: TradeEntity) {
    val isWin = trade.result == "WIN" || trade.result == "WON"
    val isTie = trade.result == "DRAW" || trade.result == "TIE"
    val resultColor = when {
        isTie -> GoldAccent
        isWin -> UpGreen
        else -> DownRed
    }

    val timeFormat = remember { SimpleDateFormat("HH:mm:ss • MMM dd", Locale.getDefault()) }
    val formattedTime = remember(trade.placedAt) { timeFormat.format(Date(trade.placedAt)) }

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = SurfaceDark,
        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
        modifier = Modifier.fillMaxWidth().testTag("trade_history_card_${trade.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Row 1: Asset, Direction, Result & Net Profit
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (trade.direction == "UP") UpGreenGlow else DownRedGlow
                    ) {
                        Text(
                            text = if (trade.direction == "UP") "▲ UP / BUY" else "▼ DOWN / SELL",
                            color = if (trade.direction == "UP") UpGreen else DownRed,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                    Text(
                        text = trade.assetSymbol,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "${trade.durationSeconds}s",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }

                // Result pill & Profit
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = resultColor.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = trade.result,
                            color = resultColor,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Text(
                        text = "${if (isWin) "+" else ""}$${String.format(Locale.US, "%.2f", trade.profitOrLoss)}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = resultColor
                    )
                }
            }

            HorizontalDivider(color = CardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)

            // Row 2: Entry Price, Expiry Price, Trade Amount, Placed Time
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Entry: ${String.format(Locale.US, "%.5f", trade.entryPrice)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                    Text(
                        text = "Exit:   ${String.format(Locale.US, "%.5f", trade.expiryPrice)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "Amount: $${String.format(Locale.US, "%.2f", trade.amount)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = GoldAccent,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = formattedTime,
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}
