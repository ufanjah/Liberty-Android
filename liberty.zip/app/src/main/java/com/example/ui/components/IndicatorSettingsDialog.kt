package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.service.market.IndicatorInstance
import com.example.ui.theme.*

@Composable
fun IndicatorSettingsDialog(
    instance: IndicatorInstance,
    onApply: (Map<String, Double>) -> Unit,
    onReset: () -> Unit,
    onDismiss: () -> Unit
) {
    val editedParams = remember { mutableStateMapOf<String, Double>().apply { putAll(instance.parameters) } }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = SurfaceDark,
            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
            modifier = Modifier.fillMaxWidth().testTag("indicator_settings_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Indicator Settings",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = instance.name,
                            style = MaterialTheme.typography.bodySmall,
                            color = PrimaryBlue,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                HorizontalDivider(color = CardBorder)

                // Parameter Controls
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    editedParams.keys.forEach { key ->
                        val currentVal = editedParams[key] ?: 0.0
                        val step = if (key.contains("stdDev", ignoreCase = true) || key.contains("multiplier", ignoreCase = true) || key.contains("start", ignoreCase = true) || key.contains("increment", ignoreCase = true)) 0.1 else 1.0

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = key.replaceFirstChar { it.uppercase() },
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary,
                                fontWeight = FontWeight.Medium
                            )

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                IconButton(
                                    onClick = {
                                        val minVal = if (step < 1.0) 0.01 else 1.0
                                        editedParams[key] = (currentVal - step).coerceAtLeast(minVal)
                                    },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Remove, contentDescription = "Decrease", tint = TextSecondary)
                                }

                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = SurfaceVariantDark,
                                    border = androidx.compose.foundation.BorderStroke(0.5.dp, CardBorder)
                                ) {
                                    Text(
                                        text = if (step < 1.0) String.format("%.2f", editedParams[key] ?: currentVal) else "${(editedParams[key] ?: currentVal).toInt()}",
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = TextPrimary
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        editedParams[key] = (currentVal + step)
                                    },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Add, contentDescription = "Increase", tint = TextSecondary)
                                }
                            }
                        }
                    }
                }

                // Action Buttons: [ RESET ] [ APPLY ]
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            onReset()
                            onDismiss()
                        },
                        modifier = Modifier.weight(1f).height(44.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(text = "RESET", fontWeight = FontWeight.Bold, color = TextSecondary)
                    }

                    Button(
                        onClick = {
                            onApply(editedParams.toMap())
                            onDismiss()
                        },
                        modifier = Modifier.weight(1f).height(44.dp).testTag("apply_indicator_settings_btn"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                    ) {
                        Text(text = "APPLY", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }
}
