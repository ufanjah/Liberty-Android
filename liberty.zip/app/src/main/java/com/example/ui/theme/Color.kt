package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// LIBERTY Trading Platform Palette
val BackgroundDark = Color(0xFF090D16)
val SurfaceDark = Color(0xFF111726)
val SurfaceVariantDark = Color(0xFF1A2234)
val SurfaceElevatedDark = Color(0xFF222B42)

val UpGreen = Color(0xFF00E676)
val UpGreenLight = Color(0xFF69F0AE)
val UpGreenDark = Color(0xFF00B050)
val UpGreenGlow = Color(0x3300E676)

val DownRed = Color(0xFFFF3366)
val DownRedDark = Color(0xFFD61A4B)
val DownRedGlow = Color(0x33FF3366)

val GoldAccent = Color(0xFFFFB300)
val GoldGlow = Color(0x33FFB300)

val PrimaryBlue = Color(0xFF3872FF)
val PrimaryBlueLight = Color(0xFF60A5FA)
val PrimaryBlueDark = Color(0xFF1D4ED8)
val PrimaryBlueVariant = Color(0xFF1E56DE)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val CardBorder = Color(0xFF25314C)
val GridLine = Color(0xFF1E283E)
val CrosshairColor = Color(0x8894A3B8)
