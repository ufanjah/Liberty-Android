package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.config.PepperstoneConfig
import com.example.data.MarketSimulator
import com.example.ui.ScreenTab
import com.example.ui.TradingViewModel
import com.example.ui.components.CandlestickChart
import com.example.ui.components.ChooseBrokerDialog
import com.example.ui.components.formatPrice
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun DashboardScreen(
    viewModel: TradingViewModel,
    modifier: Modifier = Modifier
) {
    val account by viewModel.account.collectAsState()
    val allTrades by viewModel.allTrades.collectAsState()
    val activeTrades by viewModel.simulator.activeTrades.collectAsState()
    val selectedAsset by viewModel.simulator.selectedAsset.collectAsState()
    val currentPrice by viewModel.simulator.currentPrice.collectAsState()
    val priceChangePercent by viewModel.simulator.priceChangePercent24h.collectAsState()
    val candles by viewModel.simulator.candles.collectAsState()
    val currentTimeframe by viewModel.simulator.currentTimeframe.collectAsState()
    val userProfile by viewModel.userProfile.collectAsState()
    val context = LocalContext.current
    var showChooseBrokerDialog by remember { mutableStateOf(false) }

    val totalTrades = account.totalTrades
    val wonTrades = account.wonTrades
    val winRate = if (totalTrades > 0) (wonTrades.toDouble() / totalTrades) * 100 else 0.0
    val netPnl = allTrades.sumOf { it.profitOrLoss }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 24.dp)
    ) {
        // Welcome Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(
                                brush = Brush.linearGradient(listOf(PrimaryBlue, UpGreen)),
                                shape = CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = userProfile.fullName.take(1).uppercase(),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    }
                    Column {
                        Text(
                            text = "Hello, ${userProfile.fullName.split(" ").firstOrNull() ?: "Trader"}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "LIBERTY Trading Hub • Demo Mode",
                            style = MaterialTheme.typography.labelSmall,
                            color = GoldAccent,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = SurfaceDark,
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .background(UpGreen, CircleShape)
                        )
                        Text(
                            text = "SIMULATOR ACTIVE",
                            style = MaterialTheme.typography.labelSmall,
                            color = UpGreen,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp
                        )
                    }
                }
            }
        }

        // Summary Cards Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                // Balance & Open Trades row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Balance Card
                    Surface(
                        modifier = Modifier
                            .weight(1.3f)
                            .clickable { viewModel.selectTab(ScreenTab.WALLET) }
                            .testTag("dashboard_balance_card"),
                        shape = RoundedCornerShape(14.dp),
                        color = SurfaceDark,
                        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "DEMO BALANCE",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Icon(
                                    imageVector = Icons.Default.AccountBalanceWallet,
                                    contentDescription = null,
                                    tint = GoldAccent,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Text(
                                text = "$${String.format(Locale.US, "%,.2f", account.demoBalance)}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                color = TextPrimary
                            )
                            Text(
                                text = "Available: $${String.format(Locale.US, "%,.2f", account.availableBalance)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted,
                                fontSize = 9.sp
                            )
                        }
                    }

                    // Open Trades Card
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { viewModel.selectTab(ScreenTab.OPEN_TRADES) }
                            .testTag("dashboard_open_trades_card"),
                        shape = RoundedCornerShape(14.dp),
                        color = SurfaceDark,
                        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "OPEN TRADES",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                if (activeTrades.isNotEmpty()) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .background(GoldAccent, CircleShape)
                                    )
                                }
                            }
                            Text(
                                text = "${activeTrades.size}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                color = if (activeTrades.isNotEmpty()) GoldAccent else TextPrimary
                            )
                            Text(
                                text = if (activeTrades.isNotEmpty()) "Tap to view" else "No active trades",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (activeTrades.isNotEmpty()) PrimaryBlue else TextMuted,
                                fontSize = 9.sp
                            )
                        }
                    }
                }

                // Today's P/L, Total Trades, Win Rate Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MetricMiniCard(
                        title = "NET P/L",
                        value = "${if (netPnl >= 0) "+" else ""}$${String.format(Locale.US, "%.2f", netPnl)}",
                        valueColor = if (netPnl >= 0) UpGreen else DownRed,
                        modifier = Modifier.weight(1f)
                    )
                    MetricMiniCard(
                        title = "TOTAL TRADES",
                        value = "$totalTrades",
                        valueColor = TextPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    MetricMiniCard(
                        title = "WIN RATE",
                        value = "${String.format(Locale.US, "%.1f", winRate)}%",
                        valueColor = if (winRate >= 50) UpGreen else GoldAccent,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Quick Action Shortcuts: Trade, Deposit, Withdraw
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { viewModel.selectTab(ScreenTab.TRADE) },
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .testTag("dashboard_trade_action"),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(imageVector = Icons.Default.ShowChart, contentDescription = null, modifier = Modifier.size(16.dp))
                        Text(text = "Trade Now", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }

                Button(
                    onClick = { viewModel.selectTab(ScreenTab.DEPOSIT) },
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .testTag("dashboard_deposit_action"),
                    colors = ButtonDefaults.buttonColors(containerColor = UpGreenDark),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Text(text = "Deposit", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }

                OutlinedButton(
                    onClick = { viewModel.selectTab(ScreenTab.WITHDRAW) },
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .testTag("dashboard_withdraw_action"),
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(imageVector = Icons.Default.ArrowOutward, contentDescription = null, modifier = Modifier.size(16.dp), tint = TextPrimary)
                        Text(text = "Withdraw", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = TextPrimary)
                    }
                }
            }
        }

        // Pepperstone Broker Option Card
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { PepperstoneConfig.openPepperstone(context) }
                    .testTag("dashboard_pepperstone_broker_option"),
                shape = RoundedCornerShape(14.dp),
                color = SurfaceDark,
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(GoldGlow, RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.OpenInBrowser,
                                contentDescription = null,
                                tint = GoldAccent,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "Pepperstone Broker Option",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "Trade with Pepperstone live execution partner",
                                style = MaterialTheme.typography.labelSmall,
                                color = GoldAccent,
                                fontSize = 10.sp
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(
                            onClick = { PepperstoneConfig.openPepperstone(context) },
                            modifier = Modifier.height(34.dp).testTag("dashboard_open_pepperstone_button"),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
                        ) {
                            Text(
                                text = "Open Pepperstone",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }

                        Button(
                            onClick = { showChooseBrokerDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                            modifier = Modifier.height(34.dp).testTag("dashboard_signup_broker_button")
                        ) {
                            Text(
                                text = "SIGN UP",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }

        // Live Market Section (with Candlestick Chart)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "LIVE MARKET CHART",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary,
                        fontSize = 9.sp,
                        letterSpacing = 0.5.sp
                    )
                    TextButton(
                        onClick = { viewModel.selectTab(ScreenTab.TRADE) },
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text(
                            text = "Full Trading Screen →",
                            style = MaterialTheme.typography.labelSmall,
                            color = PrimaryBlue,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                CandlestickChart(
                    candles = candles,
                    currentPrice = currentPrice,
                    decimals = selectedAsset.decimals,
                    timeframe = currentTimeframe,
                    onTimeframeSelected = { viewModel.simulator.selectTimeframe(it) },
                    activeTrades = activeTrades.filter { it.assetSymbol == selectedAsset.symbol }
                )
            }
        }

        // Market Watchlist Preview
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "WATCHLIST",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary,
                    fontSize = 9.sp,
                    letterSpacing = 0.5.sp
                )

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = SurfaceDark,
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        MarketSimulator.SUPPORTED_ASSETS.take(4).forEach { asset ->
                            val isSelected = asset.symbol == selectedAsset.symbol
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.simulator.selectAsset(asset)
                                        viewModel.selectTab(ScreenTab.TRADE)
                                    }
                                    .padding(vertical = 6.dp, horizontal = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(text = asset.iconEmoji, fontSize = 16.sp)
                                    Column {
                                        Text(
                                            text = asset.symbol,
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = if (isSelected) PrimaryBlue else TextPrimary
                                        )
                                        Text(
                                            text = asset.name,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = TextSecondary
                                        )
                                    }
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Surface(shape = RoundedCornerShape(4.dp), color = UpGreenGlow) {
                                        Text(
                                            text = "+${asset.payoutPercent}%",
                                            color = UpGreen,
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.labelSmall,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                    Icon(
                                        imageVector = Icons.Default.ChevronRight,
                                        contentDescription = "Trade",
                                        tint = TextMuted,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showChooseBrokerDialog) {
        ChooseBrokerDialog(
            context = context,
            onDismiss = { showChooseBrokerDialog = false }
        )
    }
}

@Composable
private fun MetricMiniCard(
    title: String,
    value: String,
    valueColor: Color = TextPrimary,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = SurfaceDark,
        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                fontSize = 8.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = valueColor,
                maxLines = 1
            )
        }
    }
}
