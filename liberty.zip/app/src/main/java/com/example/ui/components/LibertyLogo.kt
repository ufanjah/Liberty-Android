package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

/**
 * Distinctive, professional LIBERTY brand logo for short-expiry trading.
 *
 * Design Concept:
 * - A stylized geometric "L" forming the structural base and vertical pillar.
 * - An integrated ascending market trend bar and breakout arrowhead rising dynamically
 *   from the corner of the "L", symbolizing upward price momentum and financial liberty.
 * - Modern dual gradient (Liberty Blue #2563EB to Upward Green #10B981).
 * - Recognizable at 20dp up to 120dp.
 */
@Composable
fun LibertyLogo(
    modifier: Modifier = Modifier,
    size: Dp = 32.dp,
    showGlow: Boolean = true
) {
    Box(
        modifier = modifier
            .size(size)
            .background(
                brush = Brush.radialGradient(
                    colors = if (showGlow) {
                        listOf(PrimaryBlue.copy(alpha = 0.25f), Color.Transparent)
                    } else {
                        listOf(Color.Transparent, Color.Transparent)
                    }
                ),
                shape = RoundedCornerShape(8.dp)
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize().padding(size * 0.12f)) {
            val w = this.size.width
            val h = this.size.height

            // 1. The Stylized "L" Pillar & Foot
            // Left vertical column: x in [0.05w .. 0.32w], y in [0.05h .. 0.95h]
            // Bottom horizontal foot: x in [0.05w .. 0.65w], y in [0.72h .. 0.95h]
            val pathL = Path().apply {
                // Top-left corner
                moveTo(w * 0.08f, h * 0.08f)
                lineTo(w * 0.32f, h * 0.08f)
                lineTo(w * 0.32f, h * 0.68f)
                lineTo(w * 0.65f, h * 0.68f)
                lineTo(w * 0.65f, h * 0.92f)
                lineTo(w * 0.08f, h * 0.92f)
                close()
            }

            val lBrush = Brush.verticalGradient(
                colors = listOf(PrimaryBlueLight, PrimaryBlueDark)
            )
            drawPath(path = pathL, brush = lBrush, style = Fill)

            // 2. The Dynamic Upward Market Surge & Arrowhead (Rising from L foot to top-right)
            val pathSurge = Path().apply {
                // Diagonal ascending candlestick beam
                moveTo(w * 0.38f, h * 0.64f)
                lineTo(w * 0.54f, h * 0.64f)
                lineTo(w * 0.78f, h * 0.28f)
                lineTo(w * 0.62f, h * 0.28f)
                close()
            }

            val surgeBrush = Brush.linearGradient(
                colors = listOf(PrimaryBlue, UpGreen),
                start = Offset(w * 0.38f, h * 0.64f),
                end = Offset(w * 0.78f, h * 0.28f)
            )
            drawPath(path = pathSurge, brush = surgeBrush, style = Fill)

            // 3. Arrowhead Apex at top right
            val pathArrow = Path().apply {
                moveTo(w * 0.94f, h * 0.06f) // Tip
                lineTo(w * 0.60f, h * 0.12f)
                lineTo(w * 0.72f, h * 0.24f)
                lineTo(w * 0.88f, h * 0.40f)
                close()
            }

            val arrowBrush = Brush.linearGradient(
                colors = listOf(UpGreen, UpGreenLight),
                start = Offset(w * 0.60f, h * 0.40f),
                end = Offset(w * 0.94f, h * 0.06f)
            )
            drawPath(path = pathArrow, brush = arrowBrush, style = Fill)
        }
    }
}

/**
 * Full Liberty Header Brand with Logo and Subtitle.
 */
@Composable
fun LibertyBrandHeader(
    modifier: Modifier = Modifier,
    logoSize: Dp = 28.dp,
    showSubtitle: Boolean = true
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        LibertyLogo(size = logoSize)
        Column {
            Text(
                text = "LIBERTY",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp,
                color = TextPrimary
            )
            if (showSubtitle) {
                Text(
                    text = "Demo Trading Hub",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary,
                    fontSize = 8.sp,
                    letterSpacing = 0.5.sp
                )
            }
        }
    }
}

/**
 * Subtle geometric financial watermark background for Liberty screens.
 * Ensures chart and numbers are 100% readable while establishing distinct platform depth.
 */
@Composable
fun LibertyWatermarkBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
    ) {
        // Faint geometric watermark
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Subtle dark grid pattern
            val gridSpacing = 40.dp.toPx()
            val gridColor = Color(0xFF131D2F).copy(alpha = 0.35f)

            var x = 0f
            while (x < w) {
                drawLine(
                    color = gridColor,
                    start = Offset(x, 0f),
                    end = Offset(x, h),
                    strokeWidth = 0.5f
                )
                x += gridSpacing
            }

            var y = 0f
            while (y < h) {
                drawLine(
                    color = gridColor,
                    start = Offset(0f, y),
                    end = Offset(w, y),
                    strokeWidth = 0.5f
                )
                y += gridSpacing
            }

            // Faint Liberty stylized L watermark in upper background
            val wmX = w * 0.65f
            val wmY = h * 0.15f
            val wmSize = w * 0.35f
            val wmColor = Color(0xFF1E293B).copy(alpha = 0.18f)

            val pathL = Path().apply {
                moveTo(wmX, wmY)
                lineTo(wmX + wmSize * 0.28f, wmY)
                lineTo(wmX + wmSize * 0.28f, wmY + wmSize * 0.7f)
                lineTo(wmX + wmSize * 0.75f, wmY + wmSize * 0.7f)
                lineTo(wmX + wmSize * 0.75f, wmY + wmSize)
                lineTo(wmX, wmY + wmSize)
                close()
            }
            drawPath(path = pathL, color = wmColor, style = Stroke(width = 2.dp.toPx()))
        }

        content()
    }
}
