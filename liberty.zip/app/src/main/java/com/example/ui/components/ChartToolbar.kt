package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.TipsAndUpdates
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Timeframe
import com.example.service.market.SignalEvaluation
import com.example.service.market.SignalState
import com.example.ui.theme.*

/**
 * Compact toolbar for Liberty chart terminal.
 * Features: Timeframe selector, Chart Type, Indicator Manager, Signal confirmation pill, and Zoom buttons.
 */
@Composable
fun ChartToolbar(
    timeframe: Timeframe,
    chartType: ChartType,
    activeIndicatorCount: Int,
    signalEvaluation: SignalEvaluation?,
    showCandleCountdown: Boolean = true,
    candleCountdownText: String = "",
    onTimeframeClick: () -> Unit,
    onChartTypeClick: () -> Unit,
    onIndicatorClick: () -> Unit,
    onSignalClick: () -> Unit,
    onZoomIn: () -> Unit,
    onZoomOut: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("chart_toolbar"),
        shape = RoundedCornerShape(10.dp),
        color = SurfaceDark,
        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left Group: Timeframe & Chart Type & Indicators & Signal
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp),
                modifier = Modifier.weight(1f, fill = false)
            ) {
                // Timeframe Pill: [ 30s ▾ / Candle ends in 00:18 ]
                Surface(
                    onClick = onTimeframeClick,
                    shape = RoundedCornerShape(6.dp),
                    color = SurfaceVariantDark,
                    border = androidx.compose.foundation.BorderStroke(0.5.dp, CardBorder),
                    modifier = Modifier.testTag("toolbar_timeframe_button")
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.5.dp),
                        horizontalAlignment = Alignment.Start
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Text(
                                text = timeframe.label,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                fontSize = 10.sp
                            )
                            Text(text = "▾", color = TextSecondary, fontSize = 8.sp)
                        }
                        if (showCandleCountdown && candleCountdownText.isNotBlank()) {
                            Text(
                                text = "Candle ends in $candleCountdownText",
                                style = MaterialTheme.typography.labelSmall,
                                color = GoldAccent,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 7.sp
                            )
                        }
                    }
                }

                // Chart Type Pill: [ Candles ▾ ]
                Surface(
                    onClick = onChartTypeClick,
                    shape = RoundedCornerShape(6.dp),
                    color = SurfaceVariantDark,
                    border = androidx.compose.foundation.BorderStroke(0.5.dp, CardBorder),
                    modifier = Modifier.testTag("toolbar_chart_type_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Text(
                            text = when (chartType) {
                                ChartType.CANDLESTICK -> "📊 Candles"
                                ChartType.AREA -> "📈 Area"
                                ChartType.LINE -> "📉 Line"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary,
                            fontSize = 10.sp
                        )
                        Text(text = "▾", color = TextSecondary, fontSize = 8.sp)
                    }
                }

                // Indicators Pill
                Surface(
                    onClick = onIndicatorClick,
                    shape = RoundedCornerShape(6.dp),
                    color = if (activeIndicatorCount > 0) PrimaryBlue.copy(alpha = 0.2f) else SurfaceVariantDark,
                    border = androidx.compose.foundation.BorderStroke(0.5.dp, if (activeIndicatorCount > 0) PrimaryBlue else CardBorder),
                    modifier = Modifier.testTag("toolbar_indicator_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Text(
                            text = if (activeIndicatorCount > 0) "⚡ Indicators ($activeIndicatorCount)" else "⚡ Indicators",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = if (activeIndicatorCount > 0) PrimaryBlueLight else TextSecondary,
                            fontSize = 10.sp
                        )
                        Text(text = "▾", color = TextSecondary, fontSize = 8.sp)
                    }
                }

                // Signal Engine Pill (BUY / SELL / WAIT)
                signalEvaluation?.let { sig ->
                    val sigColor = when (sig.state) {
                        SignalState.BUY -> UpGreen
                        SignalState.SELL -> DownRed
                        SignalState.WAIT -> GoldAccent
                    }
                    Surface(
                        onClick = onSignalClick,
                        shape = RoundedCornerShape(6.dp),
                        color = sigColor.copy(alpha = 0.15f),
                        border = androidx.compose.foundation.BorderStroke(0.5.dp, sigColor.copy(alpha = 0.4f)),
                        modifier = Modifier.testTag("toolbar_signal_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Icon(imageVector = Icons.Default.TipsAndUpdates, contentDescription = null, tint = sigColor, modifier = Modifier.size(11.dp))
                            Text(
                                text = "${sig.state.name} (${sig.confirmations}/${sig.totalConditionsChecked})",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Black,
                                color = sigColor,
                                fontSize = 9.sp
                            )
                        }
                    }
                }
            }

            // Right Group: Zoom Controls
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Surface(
                    onClick = onZoomOut,
                    shape = RoundedCornerShape(6.dp),
                    color = SurfaceVariantDark,
                    modifier = Modifier.size(24.dp).testTag("toolbar_zoom_out")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(imageVector = Icons.Default.Remove, contentDescription = "Zoom Out", tint = TextSecondary, modifier = Modifier.size(13.dp))
                    }
                }

                Surface(
                    onClick = onZoomIn,
                    shape = RoundedCornerShape(6.dp),
                    color = SurfaceVariantDark,
                    modifier = Modifier.size(24.dp).testTag("toolbar_zoom_in")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Zoom In", tint = TextSecondary, modifier = Modifier.size(13.dp))
                    }
                }
            }
        }
    }
}
