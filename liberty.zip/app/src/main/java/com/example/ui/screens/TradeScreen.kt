package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ActiveTrade
import com.example.data.Timeframe
import com.example.service.market.DataConnectionState
import com.example.service.market.IndicatorInstance
import com.example.service.market.SignalState
import com.example.ui.TradingViewModel
import com.example.ui.components.*
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import java.util.Locale
import kotlin.math.max

/**
 * Modern, professional market analysis & demo trading terminal for Liberty.
 *
 * Designed for Google Play compliance:
 * - Transparent "DEMO MODE" & "DEMO DATA" status labels
 * - Prominent "DEMO BUY" and "DEMO SELL" execution buttons
 * - Live Market Analysis pipeline (MarketDataService -> CandleBuilder -> IndicatorEngine -> SignalEngine)
 * - [ SIGN UP ] and [ SIGN IN ] buttons above chart
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TradeScreen(
    viewModel: TradingViewModel,
    modifier: Modifier = Modifier,
    onOpenDrawer: () -> Unit = {}
) {
    val account by viewModel.account.collectAsState()
    val selectedAsset by viewModel.simulator.selectedAsset.collectAsState()
    val currentTimeframe by viewModel.simulator.currentTimeframe.collectAsState()
    val currentPrice by viewModel.simulator.currentPrice.collectAsState()
    val candles by viewModel.simulator.candles.collectAsState()
    val activeTrades by viewModel.simulator.activeTrades.collectAsState()

    val selectedAmount by viewModel.selectedAmount.collectAsState()
    val selectedExpirySeconds by viewModel.selectedExpirySeconds.collectAsState()
    val isPlacingTrade by viewModel.isPlacingTrade.collectAsState()

    // Real-Time Market Data & Indicator States
    val connectionStatus by viewModel.marketDataService.connectionStatus.collectAsState(DataConnectionState.DEMO_DATA)
    val lastUpdateFormatted by viewModel.marketDataService.lastUpdateFormatted.collectAsState("")
    val activeIndicators by viewModel.activeIndicators.collectAsState()
    val calculatedIndicators by viewModel.calculatedIndicators.collectAsState()
    val signalEvaluation by viewModel.signalEvaluation.collectAsState()

    // Chart customization states
    var chartType by remember { mutableStateOf(ChartType.CANDLESTICK) }
    var zoomCandleCount by remember { mutableIntStateOf(40) }
    var showCandleCountdown by remember { mutableStateOf(true) }

    // Live continuous ticker for exact countdown calculations
    var currentTimestamp by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (isActive) {
            currentTimestamp = System.currentTimeMillis()
            delay(250)
        }
    }

    // Precise live candle countdown from current timeframe and live clock
    val candleSecondsLeft = remember(currentTimeframe, currentTimestamp) {
        calculateCandleRemainingSeconds(currentTimeframe, currentTimestamp)
    }
    val candleCountdownText = remember(candleSecondsLeft) {
        formatSecondsToClock(candleSecondsLeft)
    }

    // Dialog & Bottom Sheet states
    var showAssetSheet by remember { mutableStateOf(false) }
    var showTimeframeSheet by remember { mutableStateOf(false) }
    var showChartTypeSheet by remember { mutableStateOf(false) }
    var showExpirySheet by remember { mutableStateOf(false) }
    var showAmountSheet by remember { mutableStateOf(false) }
    var showSettingsSheet by remember { mutableStateOf(false) }
    var showIndicatorsSheet by remember { mutableStateOf(false) }
    var showSignalSettingsDialog by remember { mutableStateOf(false) }
    var editingIndicatorInstance by remember { mutableStateOf<IndicatorInstance?>(null) }

    // Broker dialog states
    var showChooseBrokerDialog by remember { mutableStateOf(false) }
    var brokerDialogMode by remember { mutableStateOf(BrokerDialogMode.SIGN_UP) }

    val context = LocalContext.current

    val potentialProfit = selectedAmount * (selectedAsset.payoutPercent / 100.0)
    val totalPotentialPayout = selectedAmount + potentialProfit

    LibertyWatermarkBackground(modifier = modifier) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // ==========================================
            // 1. TOP SECTION: LIBERTY HEADER, [SIGN UP] [SIGN IN], DEMO MODE, ASSET & PRICE
            // ==========================================
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = SurfaceDark.copy(alpha = 0.95f),
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                modifier = Modifier.fillMaxWidth().testTag("trading_top_header")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    // Row 1: Brand Logo + [ SIGN UP ] [ SIGN IN ] + Demo Balance
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Left: Drawer menu toggle + Liberty Logo & Brand Identity
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            IconButton(
                                onClick = onOpenDrawer,
                                modifier = Modifier.size(26.dp).testTag("trade_screen_drawer_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Menu,
                                    contentDescription = "Menu",
                                    tint = TextPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            LibertyLogo(size = 20.dp)
                            Text(
                                text = "LIBERTY",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.5.sp,
                                color = TextPrimary,
                                fontSize = 13.sp
                            )
                        }

                        // Center: [ SIGN UP ] [ SIGN IN ] Buttons above chart (Requirement)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Button(
                                onClick = {
                                    brokerDialogMode = BrokerDialogMode.SIGN_UP
                                    showChooseBrokerDialog = true
                                },
                                shape = RoundedCornerShape(6.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                                contentPadding = PaddingValues(horizontal = 7.dp, vertical = 2.dp),
                                modifier = Modifier.height(26.dp).testTag("header_signup_button")
                            ) {
                                Text(text = "SIGN UP", fontSize = 9.sp, fontWeight = FontWeight.Black, color = Color.White)
                            }

                            OutlinedButton(
                                onClick = {
                                    brokerDialogMode = BrokerDialogMode.SIGN_IN
                                    showChooseBrokerDialog = true
                                },
                                shape = RoundedCornerShape(6.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryBlueLight),
                                contentPadding = PaddingValues(horizontal = 7.dp, vertical = 2.dp),
                                modifier = Modifier.height(26.dp).testTag("header_signin_button")
                            ) {
                                Text(text = "SIGN IN", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = PrimaryBlueLight)
                            }
                        }

                        // Right: DEMO BALANCE & Quick reset
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "DEMO BALANCE",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary,
                                    fontSize = 7.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "$${String.format(Locale.US, "%,.2f", account.demoBalance)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Black,
                                    color = TextPrimary,
                                    fontSize = 11.5.sp
                                )
                            }

                            IconButton(
                                onClick = { viewModel.resetDemoBalance() },
                                modifier = Modifier.size(22.dp).testTag("quick_reset_balance_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Reset Demo Balance",
                                    tint = PrimaryBlue,
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                        }
                    }

                    // Row 2: Asset selector, live price & Connection Status Badge
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Left: Selected Asset & Price
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Surface(
                                onClick = { showAssetSheet = true },
                                shape = RoundedCornerShape(7.dp),
                                color = SurfaceVariantDark,
                                border = androidx.compose.foundation.BorderStroke(0.5.dp, CardBorder),
                                modifier = Modifier.testTag("top_bar_asset_selector")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    Text(text = selectedAsset.iconEmoji, fontSize = 11.sp)
                                    Text(
                                        text = selectedAsset.symbol,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Black,
                                        color = TextPrimary,
                                        fontSize = 10.5.sp
                                    )
                                    Text(text = "▾", color = TextSecondary, fontSize = 8.sp)
                                }
                            }

                            // Price display
                            Text(
                                text = formatPrice(currentPrice, selectedAsset.decimals),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Black,
                                color = TextPrimary,
                                fontSize = 12.sp
                            )
                        }

                        // Center: ● DEMO MODE Badge
                        Surface(
                            shape = RoundedCornerShape(5.dp),
                            color = GoldGlow
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Box(modifier = Modifier.size(5.dp).background(GoldAccent, CircleShape))
                                Text(
                                    text = "DEMO MODE",
                                    color = GoldAccent,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 7.5.sp
                                )
                            }
                        }

                        // Right: Connection Status Badge (DEMO DATA / LIVE / CONNECTING / DATA LOST)
                        val statusColor = when (connectionStatus) {
                            DataConnectionState.LIVE -> UpGreen
                            DataConnectionState.DEMO_DATA -> GoldAccent
                            DataConnectionState.CONNECTING, DataConnectionState.RECONNECTING -> PrimaryBlue
                            else -> DownRed
                        }
                        val sourceSubtitle = when (connectionStatus) {
                            DataConnectionState.LIVE -> if (lastUpdateFormatted.isNotBlank()) "Source: Deriv • $lastUpdateFormatted" else "Source: Deriv"
                            DataConnectionState.DEMO_DATA -> "Demo Simulation"
                            DataConnectionState.CONNECTING -> "Connecting Deriv..."
                            DataConnectionState.RECONNECTING -> "Reconnecting Deriv..."
                            DataConnectionState.DATA_CONNECTION_LOST -> "Tap to Retry"
                            DataConnectionState.LIVE_DATA_UNAVAILABLE -> "Market Closed"
                        }
                        Surface(
                            onClick = { viewModel.reconnectMarketData() },
                            shape = RoundedCornerShape(5.dp),
                            color = statusColor.copy(alpha = 0.12f),
                            border = androidx.compose.foundation.BorderStroke(0.5.dp, statusColor.copy(alpha = 0.4f)),
                            modifier = Modifier.testTag("live_connection_badge")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Box(modifier = Modifier.size(5.dp).background(statusColor, CircleShape))
                                Column {
                                    Text(
                                        text = connectionStatus.label,
                                        fontSize = 7.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = statusColor
                                    )
                                    Text(
                                        text = sourceSubtitle,
                                        fontSize = 6.sp,
                                        color = TextMuted
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // ==========================================
            // 2. SECOND SECTION: CHART TOOLBAR (Timeframe, Chart type, Indicators, Zoom)
            // ==========================================
            ChartToolbar(
                timeframe = currentTimeframe,
                chartType = chartType,
                activeIndicatorCount = activeIndicators.count { it.isVisible },
                signalEvaluation = signalEvaluation,
                showCandleCountdown = showCandleCountdown,
                candleCountdownText = candleCountdownText,
                onTimeframeClick = { showTimeframeSheet = true },
                onChartTypeClick = { showChartTypeSheet = true },
                onIndicatorClick = { showIndicatorsSheet = true },
                onSignalClick = { showSignalSettingsDialog = true },
                onZoomIn = { zoomCandleCount = max(15, zoomCandleCount - 10) },
                onZoomOut = { zoomCandleCount = (zoomCandleCount + 10).coerceAtMost(90) }
            )

            // ==========================================
            // 3. LARGE CENTER: LIVE MARKET CHART (Modifier.weight(1f) to maximize vertical space)
            // ==========================================
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                CandlestickChart(
                    candles = candles,
                    currentPrice = currentPrice,
                    decimals = selectedAsset.decimals,
                    timeframe = currentTimeframe,
                    onTimeframeSelected = { viewModel.simulator.selectTimeframe(it) },
                    activeTrades = activeTrades.filter { it.assetSymbol == selectedAsset.symbol },
                    chartType = chartType,
                    calculatedIndicators = calculatedIndicators,
                    showSma = activeIndicators.any { it.definitionId == "SMA" && it.isVisible },
                    zoomCandleCount = zoomCandleCount,
                    modifier = Modifier.fillMaxSize()
                )
            }

            // ==========================================
            // 4. MARKET SIGNAL PANEL (Requirement: Market Signal, Confirmations, Trend, Momentum, MACD)
            // ==========================================
            Surface(
                onClick = { showSignalSettingsDialog = true },
                shape = RoundedCornerShape(8.dp),
                color = SurfaceDark,
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                modifier = Modifier.fillMaxWidth().testTag("market_signal_panel")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 5.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Left: Market Signal Status & Confirmations
                    val sigColor = when (signalEvaluation.state) {
                        SignalState.BUY -> UpGreen
                        SignalState.SELL -> DownRed
                        SignalState.WAIT -> GoldAccent
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "MARKET SIGNAL",
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary
                        )

                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = sigColor.copy(alpha = 0.18f),
                            border = androidx.compose.foundation.BorderStroke(0.5.dp, sigColor)
                        ) {
                            Text(
                                text = signalEvaluation.state.name,
                                color = sigColor,
                                fontWeight = FontWeight.Black,
                                fontSize = 9.sp,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                            )
                        }

                        Text(
                            text = "Confirmations: ${signalEvaluation.confirmations} / ${signalEvaluation.totalConditionsChecked}",
                            fontSize = 8.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )
                    }

                    // Right: Trend, Momentum, MACD breakdown
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "Trend: ${signalEvaluation.trendStatus.uppercase()}",
                            fontSize = 7.5.sp,
                            color = if (signalEvaluation.trendStatus.contains("Bullish", true)) UpGreen else if (signalEvaluation.trendStatus.contains("Bearish", true)) DownRed else TextSecondary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Momentum: ${signalEvaluation.momentumStatus.uppercase()}",
                            fontSize = 7.5.sp,
                            color = if (signalEvaluation.momentumStatus.contains("Positive", true)) UpGreen else if (signalEvaluation.momentumStatus.contains("Negative", true)) DownRed else TextSecondary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Compact Active Trade Strip (if any open)
            if (activeTrades.isNotEmpty()) {
                CompactActiveTradeCard(
                    activeTrades = activeTrades,
                    currentPrice = currentPrice,
                    decimals = selectedAsset.decimals
                )
            }

            // ==========================================
            // 5. BOTTOM SECTION: DURATION CHIPS, INVESTMENT, DEMO BUY, DEMO SELL
            // ==========================================
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = SurfaceDark,
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                modifier = Modifier.fillMaxWidth().testTag("bottom_trading_controls")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    // Row 1: Duration & Investment Selectors
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Duration Preset Chips: [15s] [30s] [1m] [3m] [5m]
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "Duration",
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 8.sp,
                                color = TextSecondary,
                                fontWeight = FontWeight.Bold
                            )
                            listOf(15 to "15s", 30 to "30s", 60 to "1m", 180 to "3m", 300 to "5m").forEach { (sec, label) ->
                                val isSel = selectedExpirySeconds == sec
                                Surface(
                                    onClick = { viewModel.setExpiry(sec) },
                                    shape = RoundedCornerShape(5.dp),
                                    color = if (isSel) PrimaryBlue else SurfaceVariantDark,
                                    border = androidx.compose.foundation.BorderStroke(0.5.dp, if (isSel) PrimaryBlue else CardBorder)
                                ) {
                                    Text(
                                        text = label,
                                        fontSize = 8.5.sp,
                                        fontWeight = if (isSel) FontWeight.Black else FontWeight.Medium,
                                        color = if (isSel) Color.White else TextPrimary,
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.5.dp)
                                    )
                                }
                            }
                        }

                        // Investment Selector
                        Surface(
                            onClick = { showAmountSheet = true },
                            shape = RoundedCornerShape(6.dp),
                            color = SurfaceVariantDark,
                            border = androidx.compose.foundation.BorderStroke(0.5.dp, CardBorder),
                            modifier = Modifier.testTag("compact_amount_selector")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Text(
                                    text = "Inv:",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontSize = 8.sp,
                                    color = TextSecondary
                                )
                                Text(
                                    text = "$${selectedAmount.toInt()}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Black,
                                    color = GoldAccent,
                                    fontSize = 11.sp
                                )
                                Text(text = "▾", color = TextSecondary, fontSize = 8.sp)
                            }
                        }
                    }

                    // Simulated Payout Info
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Simulated Payout (${selectedAsset.payoutPercent}%):",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary,
                            fontSize = 8.5.sp
                        )
                        Text(
                            text = "+$${String.format(Locale.US, "%.2f", potentialProfit)}  (Total: $${String.format(Locale.US, "%.2f", totalPotentialPayout)})",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = UpGreen,
                            fontSize = 9.sp
                        )
                    }

                    // Row 2: DEMO BUY and DEMO SELL (Clearly labeled, never representing real orders)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // LEFT: DEMO BUY (Green)
                        Button(
                            onClick = { viewModel.placeTrade("UP") },
                            enabled = !isPlacingTrade,
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("trade_up_button"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = UpGreen,
                                contentColor = BackgroundDark,
                                disabledContainerColor = UpGreen.copy(alpha = 0.5f)
                            ),
                            elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.TrendingUp,
                                    contentDescription = null,
                                    tint = BackgroundDark,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "DEMO BUY",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Black,
                                        color = BackgroundDark
                                    )
                                    Text(
                                        text = "+$${String.format(Locale.US, "%.2f", potentialProfit)}",
                                        fontSize = 8.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = BackgroundDark.copy(alpha = 0.85f)
                                    )
                                }
                            }
                        }

                        // RIGHT: DEMO SELL (Red)
                        Button(
                            onClick = { viewModel.placeTrade("DOWN") },
                            enabled = !isPlacingTrade,
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("trade_down_button"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DownRed,
                                contentColor = TextPrimary,
                                disabledContainerColor = DownRed.copy(alpha = 0.5f)
                            ),
                            elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.TrendingDown,
                                    contentDescription = null,
                                    tint = TextPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "DEMO SELL",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Black,
                                        color = TextPrimary
                                    )
                                    Text(
                                        text = "+$${String.format(Locale.US, "%.2f", potentialProfit)}",
                                        fontSize = 8.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary.copy(alpha = 0.85f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal Sheets & Dialogs

    // 1. Asset Selection Sheet
    if (showAssetSheet) {
        AssetSelectorSheet(
            selectedAsset = selectedAsset,
            onAssetSelected = { viewModel.simulator.selectAsset(it) },
            onDismiss = { showAssetSheet = false }
        )
    }

    // 2. Timeframe Selector Sheet
    if (showTimeframeSheet) {
        TimeframeSelectorSheet(
            currentTimeframe = currentTimeframe,
            showCandleCountdown = showCandleCountdown,
            onToggleCandleCountdown = { showCandleCountdown = it },
            onTimeframeSelected = { viewModel.simulator.selectTimeframe(it) },
            onDismiss = { showTimeframeSheet = false }
        )
    }

    // 3. Chart Type Selector Sheet
    if (showChartTypeSheet) {
        ChartTypeSelectorSheet(
            currentChartType = chartType,
            onChartTypeSelected = { chartType = it },
            onDismiss = { showChartTypeSheet = false }
        )
    }

    // 4. Expiry Duration Selector Sheet
    if (showExpirySheet) {
        ExpirySelectorSheet(
            currentExpirySeconds = selectedExpirySeconds,
            payoutPercent = selectedAsset.payoutPercent,
            onExpirySelected = { viewModel.setExpiry(it) },
            onDismiss = { showExpirySheet = false }
        )
    }

    // 5. Investment Amount Selector Sheet
    if (showAmountSheet) {
        AmountSelectorSheet(
            currentAmount = selectedAmount,
            demoBalance = account.demoBalance,
            onAmountSelected = { viewModel.setAmount(it) },
            onDismiss = { showAmountSheet = false }
        )
    }

    // 6. Settings Bottom Sheet
    if (showSettingsSheet) {
        TradingSettingsSheet(
            viewModel = viewModel,
            onDismiss = { showSettingsSheet = false }
        )
    }

    // 7. Indicators Manager Bottom Sheet
    if (showIndicatorsSheet) {
        IndicatorsSheet(
            activeIndicators = activeIndicators,
            onAddIndicator = { def ->
                viewModel.addIndicator(def)
            },
            onToggleVisibility = { id -> viewModel.toggleIndicatorVisibility(id) },
            onRemoveIndicator = { id -> viewModel.removeIndicator(id) },
            onEditIndicator = { inst -> editingIndicatorInstance = inst },
            onResetIndicator = { id -> viewModel.resetIndicatorParams(id) },
            onDismiss = { showIndicatorsSheet = false }
        )
    }

    // 8. Indicator Parameter Settings Dialog
    editingIndicatorInstance?.let { instance ->
        IndicatorSettingsDialog(
            instance = instance,
            onApply = { newParams ->
                viewModel.updateIndicatorParams(instance.id, newParams)
                editingIndicatorInstance = null
            },
            onReset = {
                viewModel.resetIndicatorParams(instance.id)
                editingIndicatorInstance = null
            },
            onDismiss = { editingIndicatorInstance = null }
        )
    }

    // 9. Signal Settings Dialog
    if (showSignalSettingsDialog) {
        SignalSettingsDialog(
            currentSettings = viewModel.signalSettings.collectAsState().value,
            onSave = { viewModel.updateSignalSettings(it) },
            onDismiss = { showSignalSettingsDialog = false }
        )
    }

    // 10. Choose Your Broker Dialog (Sign Up or Sign In flow)
    if (showChooseBrokerDialog) {
        ChooseBrokerDialog(
            context = context,
            mode = brokerDialogMode,
            onDismiss = { showChooseBrokerDialog = false }
        )
    }
}

fun calculateCandleRemainingSeconds(timeframe: Timeframe, nowMs: Long = System.currentTimeMillis()): Int {
    val intervalMs = timeframe.seconds * 1000L
    if (intervalMs <= 0L) return 0
    val elapsedInBucket = nowMs % intervalMs
    val remainingMs = intervalMs - elapsedInBucket
    return max(0, (remainingMs / 1000L).toInt())
}

fun formatSecondsToClock(seconds: Int): String {
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    val s = seconds % 60
    return if (h > 0) {
        String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
    } else {
        String.format(Locale.US, "%02d:%02d", m, s)
    }
}

/**
 * Compact Active Trade Card.
 * Displays: Asset, Direction, Entry Price, Investment, Expiry countdown, Live status.
 */
@Composable
private fun CompactActiveTradeCard(
    activeTrades: List<ActiveTrade>,
    currentPrice: Double,
    decimals: Int
) {
    Surface(
        modifier = Modifier.fillMaxWidth().testTag("compact_active_trade_card"),
        shape = RoundedCornerShape(10.dp),
        color = SurfaceDark,
        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            activeTrades.forEach { trade ->
                val isTie = trade.isTie(currentPrice)
                val isWin = trade.isWinning(currentPrice)
                val statusColor = when {
                    isTie -> GoldAccent
                    isWin -> UpGreen
                    else -> DownRed
                }
                val statusText = when {
                    isTie -> "DRAW"
                    isWin -> "IN THE MONEY"
                    else -> "OUT OF THE MONEY"
                }
                val secondsLeft = trade.remainingSeconds()
                val totalSeconds = max(1, trade.durationSeconds)
                val progress = (secondsLeft.toFloat() / totalSeconds.toFloat()).coerceIn(0f, 1f)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val isUp = trade.direction == "UP"
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = if (isUp) UpGreen else DownRed
                        ) {
                            Text(
                                text = if (isUp) "UP ↑" else "DOWN ↓",
                                color = if (isUp) BackgroundDark else TextPrimary,
                                fontWeight = FontWeight.Black,
                                fontSize = 8.sp,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                        Text(
                            text = trade.assetSymbol,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            fontSize = 11.sp
                        )
                        Text(
                            text = "Entry: ${formatPrice(trade.entryPrice, decimals)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary,
                            fontSize = 8.5.sp
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = statusColor.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = statusText,
                                color = statusColor,
                                fontWeight = FontWeight.Bold,
                                fontSize = 7.5.sp,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }

                        // Requirement 2: Trade Expiry Countdown (e.g. "Trade expires in 00:27")
                        Surface(
                            shape = RoundedCornerShape(5.dp),
                            color = (if (secondsLeft <= 5) DownRed else GoldAccent).copy(alpha = 0.15f),
                            border = androidx.compose.foundation.BorderStroke(0.5.dp, if (secondsLeft <= 5) DownRed else GoldAccent.copy(alpha = 0.6f))
                        ) {
                            Text(
                                text = "Trade expires in ${formatSecondsToClock(secondsLeft)}",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Black,
                                fontSize = 8.5.sp,
                                color = if (secondsLeft <= 5) DownRed else GoldAccent,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth().height(2.dp),
                    color = if (secondsLeft <= 5) DownRed else PrimaryBlue,
                    trackColor = CardBorder
                )
            }
        }
    }
}
