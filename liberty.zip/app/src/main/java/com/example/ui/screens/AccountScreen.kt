package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.config.AppConfig
import com.example.config.BrokerConfig
import com.example.service.market.DataConnectionState
import com.example.ui.TradingViewModel
import com.example.ui.components.BrokerDialogMode
import com.example.ui.components.ChooseBrokerDialog
import com.example.ui.theme.*
import java.util.Locale

/**
 * Production-ready Account Screen for Liberty.
 *
 * Requirements (Play Store First Architecture):
 * - Header: LIBERTY DEMO ACCOUNT
 * - Demo Balance ($10,000 default simulated funds)
 * - Trading Statistics calculated from actual recorded demo trades (Wins, Losses, Draws, Win Rate, Investment, PnL)
 * - Broker Pathways (Pepperstone & Pocket Option)
 * - Data Provider Status (Live vs Demo Data transparency)
 * - Legal: Privacy Policy & Terms of Service disclosures
 * - About Liberty (version, architecture, disclaimer)
 */
@Composable
fun AccountScreen(
    viewModel: TradingViewModel,
    modifier: Modifier = Modifier
) {
    val account by viewModel.account.collectAsState()
    val allTrades by viewModel.allTrades.collectAsState()
    val connectionStatus by viewModel.marketDataService.connectionStatus.collectAsState(DataConnectionState.DEMO_DATA)
    val lastUpdateFormatted by viewModel.marketDataService.lastUpdateFormatted.collectAsState("")

    var showResetDialog by remember { mutableStateOf(false) }
    var showBrokerDialog by remember { mutableStateOf(false) }
    var brokerDialogMode by remember { mutableStateOf(BrokerDialogMode.SIGN_UP) }
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showTermsDialog by remember { mutableStateOf(false) }

    val context = LocalContext.current

    // Actual Calculated Statistics
    val totalCount = allTrades.size
    val wonCount = allTrades.count { it.result == "WIN" || it.result == "WON" }
    val lostCount = allTrades.count { it.result == "LOSS" || it.result == "LOST" }
    val drawCount = allTrades.count { it.result == "DRAW" || it.result == "TIE" }
    val winRate = if (totalCount > 0) (wonCount.toDouble() / totalCount) * 100 else 0.0
    val totalInvestment = allTrades.sumOf { it.amount }
    val netPnl = allTrades.sumOf { it.profitOrLoss }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp)
    ) {
        // Section 1: LIBERTY DEMO ACCOUNT Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "LIBERTY DEMO ACCOUNT",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = TextPrimary,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "Simulated trading terminal & performance analytics",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = GoldGlow
                ) {
                    Text(
                        text = "DEMO MODE",
                        color = GoldAccent,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        // Section 2: Demo Balance Hero Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "AVAILABLE DEMO BALANCE",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary,
                            letterSpacing = 0.8.sp
                        )
                        Icon(
                            imageVector = Icons.Default.AccountBalanceWallet,
                            contentDescription = null,
                            tint = GoldAccent,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Text(
                        text = "$${String.format(Locale.US, "%,.2f", account.demoBalance)}",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Black,
                        color = TextPrimary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { viewModel.topUpDemoBalance(1000.0) },
                            modifier = Modifier.weight(1f).height(40.dp).testTag("top_up_1000_button"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                        ) {
                            Text(text = "+$1,000 Demo", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        OutlinedButton(
                            onClick = { showResetDialog = true },
                            modifier = Modifier.weight(1f).height(40.dp).testTag("reset_balance_button"),
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary)
                        ) {
                            Text(text = "Reset $10,000", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Section 3: Actual Trading Statistics
        item {
            Text(
                text = "TRADING STATISTICS",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = SurfaceDark,
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    AccountMetricRow("Total Trades", "$totalCount")
                    HorizontalDivider(color = CardBorder, thickness = 0.5.dp)
                    AccountMetricRow("Wins", "$wonCount", valueColor = UpGreen)
                    HorizontalDivider(color = CardBorder, thickness = 0.5.dp)
                    AccountMetricRow("Losses", "$lostCount", valueColor = DownRed)
                    HorizontalDivider(color = CardBorder, thickness = 0.5.dp)
                    AccountMetricRow("Draws", "$drawCount", valueColor = GoldAccent)
                    HorizontalDivider(color = CardBorder, thickness = 0.5.dp)
                    AccountMetricRow("Win Rate", "${String.format(Locale.US, "%.1f", winRate)}%", valueColor = if (winRate >= 50) UpGreen else GoldAccent)
                    HorizontalDivider(color = CardBorder, thickness = 0.5.dp)
                    AccountMetricRow("Total Demo Volume", "$${String.format(Locale.US, "%.2f", totalInvestment)}")
                    HorizontalDivider(color = CardBorder, thickness = 0.5.dp)
                    AccountMetricRow(
                        "Net Demo P&L",
                        "${if (netPnl >= 0) "+" else ""}$${String.format(Locale.US, "%.2f", netPnl)}",
                        valueColor = if (netPnl >= 0) UpGreen else DownRed
                    )
                }
            }
        }

        // Section 4: Broker Pathways (Sign Up & Sign In)
        item {
            Text(
                text = "BROKER PATHWAYS",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Ready to trade live? Choose an official regulated broker.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                brokerDialogMode = BrokerDialogMode.SIGN_UP
                                showBrokerDialog = true
                            },
                            modifier = Modifier.weight(1f).height(40.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                        ) {
                            Text("CHOOSE BROKER", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                brokerDialogMode = BrokerDialogMode.SIGN_IN
                                showBrokerDialog = true
                            },
                            modifier = Modifier.weight(1f).height(40.dp),
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryBlueLight)
                        ) {
                            Text("BROKER LOGIN", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = PrimaryBlueLight)
                        }
                    }
                }
            }
        }

        // Section 5: Data Provider Status
        item {
            Text(
                text = "DATA PROVIDER STATUS",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = SurfaceDark,
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "Current Stream", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (connectionStatus == DataConnectionState.LIVE) UpGreenGlow else GoldGlow
                        ) {
                            Text(
                                text = connectionStatus.label,
                                color = if (connectionStatus == DataConnectionState.LIVE) UpGreen else GoldAccent,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Provider", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        Text(text = "Deriv Public WebSocket", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = TextPrimary)
                    }
                    if (lastUpdateFormatted.isNotBlank()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Last Update", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            Text(text = lastUpdateFormatted, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = TextPrimary)
                        }
                    }
                    Text(
                        text = "Official Deriv public WebSocket feed (wss://api.derivws.com/trading/v1/options/ws/public). Read-only market ticks for analysis and simulated demo trading. Does not collect credentials or execute real-money orders.",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted,
                        fontSize = 8.5.sp
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { viewModel.switchToLiveFeed() },
                            modifier = Modifier.weight(1f).height(36.dp),
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, UpGreen)
                        ) {
                            Text("LIVE FEED", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = UpGreen)
                        }
                        OutlinedButton(
                            onClick = { viewModel.switchToDemoFeed() },
                            modifier = Modifier.weight(1f).height(36.dp),
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
                        ) {
                            Text("DEMO SIMULATION", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
                        }
                    }
                }
            }
        }

        // Section 6: Legal & Compliance Disclosures (Google Play First)
        item {
            Text(
                text = "LEGAL & COMPLIANCE",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = SurfaceDark,
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    AccountSettingsRow(
                        title = "Privacy Policy",
                        subtitle = "Data safety and privacy disclosures",
                        icon = Icons.Default.PrivacyTip,
                        onClick = { showPrivacyDialog = true }
                    )
                    HorizontalDivider(color = CardBorder, thickness = 0.5.dp)
                    AccountSettingsRow(
                        title = "Terms & Conditions",
                        subtitle = "Service guidelines and user agreement",
                        icon = Icons.Default.Description,
                        onClick = { showTermsDialog = true }
                    )
                    HorizontalDivider(color = CardBorder, thickness = 0.5.dp)
                    AccountSettingsRow(
                        title = "Risk Warning",
                        subtitle = "Financial derivatives and simulated trading notice",
                        icon = Icons.Default.WarningAmber,
                        onClick = {
                            BrokerConfig.openUrl(context, AppConfig.RISK_DISCLOSURE_URL, "Financial risk warning: CFD and options trading carries high risk.")
                        }
                    )
                }
            }
        }

        // Section 7: About Liberty
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = SurfaceVariantDark,
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "ABOUT LIBERTY",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = GoldAccent
                    )
                    Text(
                        text = "${AppConfig.PLATFORM_NAME} v${AppConfig.APP_VERSION_NAME} (Build ${AppConfig.APP_VERSION_CODE})",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "LIBERTY is a Live Market Analysis & Demo Trading Platform. All trades placed inside this application use virtual practice balances and do not execute real money transactions.",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                        fontSize = 9.sp,
                        lineHeight = 13.sp
                    )
                }
            }
        }
    }

    // Reset Demo Balance Confirmation Dialog
    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            containerColor = SurfaceDark,
            title = { Text(text = "Reset Demo Balance", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = { Text("Are you sure you want to reset your virtual demo balance to $10,000.00?", color = TextSecondary) },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.resetDemoBalance()
                        showResetDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                ) {
                    Text("Reset to $10,000", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }

    // Broker Dialog
    if (showBrokerDialog) {
        ChooseBrokerDialog(
            context = context,
            mode = brokerDialogMode,
            onDismiss = { showBrokerDialog = false }
        )
    }

    // Privacy Policy Dialog
    if (showPrivacyDialog) {
        PolicyTextDialog(
            title = "Privacy Policy",
            content = """
                LIBERTY Privacy Policy
                Last updated: 2026

                1. Data Collection:
                LIBERTY operates as a local-first application. Your simulated demo trades, practice balance, and indicator configurations are stored securely on your local device. We do not transmit or sell personal trading behavior to third parties.

                2. Market Data Streams:
                When connecting to external market feeds, device network requests are made strictly to retrieve financial quotes. No sensitive personal identifier is bundled into public market data calls.

                3. Broker Authentication:
                LIBERTY directs users to official broker web portals for live accounts. LIBERTY never collects, accesses, or stores your broker passwords or financial account credentials.

                4. Contact:
                For privacy inquiries: support@libertytrading.io
            """.trimIndent(),
            onDismiss = { showPrivacyDialog = false }
        )
    }

    // Terms of Service Dialog
    if (showTermsDialog) {
        PolicyTextDialog(
            title = "Terms & Conditions",
            content = """
                LIBERTY Terms of Service
                Last updated: 2026

                1. Simulated / Practice Platform:
                LIBERTY provides educational technical analysis tools, indicators, and a virtual demo trading terminal. No actual monetary orders are sent to markets from within this application.

                2. No Investment Advice:
                Technical indicators, signals, and charts provided in LIBERTY are mathematical heuristics and do not constitute financial or investment advice. Past practice performance does not guarantee future results.

                3. Third-Party Brokers:
                Any live trading account opened through third-party broker links (e.g. Pepperstone, Pocket Option) is governed solely by the respective broker's regulatory licensing and customer agreement.
            """.trimIndent(),
            onDismiss = { showTermsDialog = false }
        )
    }
}

@Composable
private fun AccountMetricRow(
    label: String,
    value: String,
    valueColor: Color = TextPrimary
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        Text(text = value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = valueColor)
    }
}

@Composable
private fun AccountSettingsRow(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        color = Color.Transparent,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(20.dp))
                Column {
                    Text(text = title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text(text = subtitle, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }
            Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = TextMuted, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
private fun PolicyTextDialog(
    title: String,
    content: String,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = SurfaceDark,
            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }
                HorizontalDivider(color = CardBorder)
                Text(
                    text = content,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    lineHeight = 18.sp,
                    modifier = Modifier.heightIn(max = 350.dp)
                )
                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth().height(40.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                ) {
                    Text("CLOSE", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
