package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.TradeResultEvent
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun TradeResultDialog(
    event: TradeResultEvent,
    onDismiss: () -> Unit
) {
    val trade = event.trade
    val isWin = event.isWin
    val isTie = event.isTie

    val title = when {
        isTie -> "DRAW"
        isWin -> "WIN!"
        else -> "LOSS"
    }

    val bannerColor = when {
        isTie -> GoldAccent
        isWin -> UpGreen
        else -> DownRed
    }

    val profitText = when {
        isTie -> "$0.00 (Refunded)"
        isWin -> "+$${String.format(Locale.US, "%.2f", event.profitOrLoss)}"
        else -> "-$${String.format(Locale.US, "%.2f", trade.amount)}"
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, bannerColor.copy(alpha = 0.5f)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("trade_result_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Circular result icon
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .background(bannerColor.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when {
                            isTie -> Icons.Default.Equalizer
                            isWin -> Icons.Default.Check
                            else -> Icons.Default.Close
                        },
                        contentDescription = title,
                        tint = bannerColor,
                        modifier = Modifier.size(36.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = title,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = bannerColor
                )

                Text(
                    text = profitText,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.ExtraBold,
                    color = bannerColor,
                    modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                )

                HorizontalDivider(color = CardBorder, thickness = 1.dp)

                Spacer(modifier = Modifier.height(16.dp))

                // Trade Details breakdown
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ResultRow("Asset", trade.assetSymbol)
                    ResultRow("Direction", if (trade.direction == "UP") "▲ UP / BUY" else "▼ DOWN / SELL")
                    ResultRow("Trade Amount", "$${String.format(Locale.US, "%.2f", trade.amount)}")
                    ResultRow("Entry Price", String.format(Locale.US, "%.5f", trade.entryPrice))
                    ResultRow("Expiry Price", String.format(Locale.US, "%.5f", trade.expiryPrice))
                    ResultRow("Duration", "${trade.durationSeconds}s")
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("dismiss_result_button")
                ) {
                    Text(
                        text = "Continue Trading",
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}

@Composable
private fun ResultRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
        Text(text = value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = TextPrimary)
    }
}
