package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.ScreenTab
import com.example.ui.TradingViewModel
import com.example.ui.theme.*
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DepositScreen(
    viewModel: TradingViewModel,
    modifier: Modifier = Modifier
) {
    var amountText by remember { mutableStateOf("50") }
    var selectedMethod by remember { mutableStateOf("Paystack") }
    var showReviewDialog by remember { mutableStateOf(false) }
    var showSuccessDialog by remember { mutableStateOf(false) }
    var confirmedRef by remember { mutableStateOf("") }
    var confirmedAmount by remember { mutableStateOf(0.0) }

    val presetAmounts = listOf(10.0, 25.0, 50.0, 100.0, 250.0, 500.0)
    val parsedAmount = amountText.toDoubleOrNull() ?: 0.0
    // Demo Nigerian exchange conversion (1 USD = ~₦1,500 demo rate)
    val nairaEquivalent = parsedAmount * 1500.0

    val paymentMethods = listOf(
        PaymentMethodOption(
            id = "Paystack",
            name = "Paystack (Demo)",
            subtitle = "Cards, Apple Pay, USSD, Bank Account",
            badge = "POPULAR IN NIGERIA",
            icon = Icons.Default.CreditCard
        ),
        PaymentMethodOption(
            id = "Flutterwave",
            name = "Flutterwave (Demo)",
            subtitle = "Barter, Bank Transfer, Card, Mobile Money",
            badge = "AFRICAN GATEWAY",
            icon = Icons.Default.AccountBalance
        ),
        PaymentMethodOption(
            id = "Bank Transfer",
            name = "Direct Bank Transfer (Demo)",
            subtitle = "Access, GTBank, Zenith, Kuda, FirstBank",
            badge = "INSTANT VIRTUAL ACCOUNT",
            icon = Icons.Default.AccountBalanceWallet
        )
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 32.dp)
    ) {
        // Back Button & Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                IconButton(
                    onClick = { viewModel.selectTab(ScreenTab.WALLET) },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextPrimary
                    )
                }
                Column {
                    Text(
                        text = "Deposit Funds",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "Nigerian Payment Gateway Simulator",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }

        // Demo Simulation Disclaimer
        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = SurfaceVariantDark,
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Demo Notice",
                        tint = GoldAccent,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "SIMULATION ONLY: No actual bank account or card will be charged. This demonstrates Nigerian deposit workflows using demo money.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
            }
        }

        // Amount Input Section
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = SurfaceDark,
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "SELECT OR ENTER DEMO AMOUNT",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary,
                        fontSize = 9.sp,
                        letterSpacing = 0.5.sp
                    )

                    OutlinedTextField(
                        value = amountText,
                        onValueChange = { input ->
                            if (input.all { it.isDigit() || it == '.' }) {
                                amountText = input
                            }
                        },
                        prefix = {
                            Text(
                                text = "$",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = GoldAccent
                            )
                        },
                        suffix = {
                            Text(
                                text = "USD",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PrimaryBlue,
                            unfocusedBorderColor = CardBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("deposit_amount_field")
                    )

                    // Naira estimate conversion
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Estimated in Naira (₦):",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                        Text(
                            text = "≈ ₦${String.format(Locale.US, "%,.0f", nairaEquivalent)}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = UpGreen
                        )
                    }

                    // Preset chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        presetAmounts.take(4).forEach { amt ->
                            val isSelected = parsedAmount == amt
                            Surface(
                                onClick = { amountText = amt.toInt().toString() },
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) PrimaryBlue else SurfaceVariantDark,
                                border = if (isSelected) null else androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier.padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "$${amt.toInt()}",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) TextPrimary else TextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Payment Method Section
        item {
            Text(
                text = "Nigerian Payment Methods (Demo Simulation)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                paymentMethods.forEach { method ->
                    val isSelected = selectedMethod == method.id
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedMethod = method.id }
                            .testTag("payment_method_${method.id}"),
                        shape = RoundedCornerShape(14.dp),
                        color = SurfaceDark,
                        border = androidx.compose.foundation.BorderStroke(
                            width = if (isSelected) 1.5.dp else 1.dp,
                            color = if (isSelected) PrimaryBlue else CardBorder
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(if (isSelected) PrimaryBlue.copy(alpha = 0.2f) else SurfaceVariantDark, RoundedCornerShape(10.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = method.icon,
                                        contentDescription = null,
                                        tint = if (isSelected) PrimaryBlue else TextSecondary,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Column {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = method.name,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimary
                                        )
                                    }
                                    Text(
                                        text = method.subtitle,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary,
                                        fontSize = 11.sp
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = SurfaceVariantDark,
                                        modifier = Modifier.padding(top = 4.dp)
                                    ) {
                                        Text(
                                            text = method.badge,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = GoldAccent,
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }

                            RadioButton(
                                selected = isSelected,
                                onClick = { selectedMethod = method.id },
                                colors = RadioButtonDefaults.colors(
                                    selectedColor = PrimaryBlue,
                                    unselectedColor = TextMuted
                                )
                            )
                        }
                    }
                }
            }
        }

        // Review Deposit Button
        item {
            Button(
                onClick = {
                    if (parsedAmount > 0) {
                        showReviewDialog = true
                    }
                },
                enabled = parsedAmount > 0,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("confirm_deposit_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = UpGreen)
            ) {
                Text(
                    text = "REVIEW DEMO DEPOSIT • $${String.format(Locale.US, "%.2f", parsedAmount)}",
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp,
                    color = BackgroundDark
                )
            }
        }
    }

    // Review Dialog (Requirement 7: Select Method -> Enter Amount -> Review -> Confirm)
    if (showReviewDialog) {
        val ref = remember { "LIB-DEP-${(100000..999999).random()}" }
        AlertDialog(
            onDismissRequest = { showReviewDialog = false },
            containerColor = SurfaceDark,
            title = {
                Text(
                    text = "Review Demo Deposit",
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Verify your simulated payment details:",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = SurfaceVariantDark,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Amount (USD)", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                                Text("$${String.format(Locale.US, "%.2f", parsedAmount)}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = UpGreen)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Estimated (NGN)", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                                Text("≈ ₦${String.format(Locale.US, "%,.0f", nairaEquivalent)}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = TextPrimary)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Payment Gateway", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                                Text(selectedMethod, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = TextPrimary)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Status", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                                Text("DEMO / COMPLETED", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = GoldAccent)
                            }
                        }
                    }
                    Text(
                        text = "Demo Mode: No money will be deducted from any real card or bank.",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        confirmedAmount = parsedAmount
                        confirmedRef = ref
                        viewModel.depositDemo(parsedAmount, selectedMethod)
                        showReviewDialog = false
                        showSuccessDialog = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = UpGreen)
                ) {
                    Text("Confirm Demo Deposit", color = BackgroundDark, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showReviewDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }

    if (showSuccessDialog) {
        AlertDialog(
            onDismissRequest = { showSuccessDialog = false },
            containerColor = SurfaceDark,
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = UpGreen)
                    Text(text = "DEMO Deposit Successful", color = TextPrimary, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Simulated deposit credited to your virtual wallet:",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = SurfaceVariantDark,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(text = "Amount: $${String.format(Locale.US, "%.2f", confirmedAmount)}", fontWeight = FontWeight.Bold, color = UpGreen)
                            Text(text = "Method: $selectedMethod", style = MaterialTheme.typography.labelSmall, color = TextPrimary)
                            Text(text = "Reference: $confirmedRef", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text(text = "Status: DEMO / COMPLETED", style = MaterialTheme.typography.labelSmall, color = GoldAccent, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSuccessDialog = false
                        viewModel.selectTab(ScreenTab.WALLET)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                ) {
                    Text("Go to Wallet", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

private data class PaymentMethodOption(
    val id: String,
    val name: String,
    val subtitle: String,
    val badge: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)
