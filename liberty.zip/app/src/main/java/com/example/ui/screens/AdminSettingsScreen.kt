package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.config.AdminConfig
import com.example.ui.ScreenTab
import com.example.ui.TradingViewModel
import com.example.ui.theme.*

@Composable
fun AdminSettingsScreen(
    viewModel: TradingViewModel,
    modifier: Modifier = Modifier
) {
    val currentConfig by viewModel.adminConfig.collectAsState()

    var bankDepositEnabled by remember(currentConfig) { mutableStateOf(currentConfig.isBankTransferDepositEnabled) }
    var paystackDepositEnabled by remember(currentConfig) { mutableStateOf(currentConfig.isPaystackDepositEnabled) }
    var flutterwaveDepositEnabled by remember(currentConfig) { mutableStateOf(currentConfig.isFlutterwaveDepositEnabled) }

    var bankWithdrawalEnabled by remember(currentConfig) { mutableStateOf(currentConfig.isBankWithdrawalEnabled) }
    var paystackPayoutEnabled by remember(currentConfig) { mutableStateOf(currentConfig.isPaystackPayoutEnabled) }
    var flutterwavePayoutEnabled by remember(currentConfig) { mutableStateOf(currentConfig.isFlutterwavePayoutEnabled) }

    var minDepositText by remember(currentConfig) { mutableStateOf(currentConfig.minDepositUsd.toInt().toString()) }
    var minWithdrawalText by remember(currentConfig) { mutableStateOf(currentConfig.minWithdrawalUsd.toInt().toString()) }
    var maxWithdrawalText by remember(currentConfig) { mutableStateOf(currentConfig.maxWithdrawalUsd.toInt().toString()) }
    var feeText by remember(currentConfig) { mutableStateOf(currentConfig.transactionFeePercent.toString()) }

    var showLiveWarningDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(horizontal = 16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(
                    onClick = { viewModel.selectTab(ScreenTab.WALLET) },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                }
                Column {
                    Text(text = "Payment Administration", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text(text = "Gateway & limits control", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
            }

            Button(
                onClick = {
                    val updated = currentConfig.copy(
                        isBankTransferDepositEnabled = bankDepositEnabled,
                        isPaystackDepositEnabled = paystackDepositEnabled,
                        isFlutterwaveDepositEnabled = flutterwaveDepositEnabled,
                        isBankWithdrawalEnabled = bankWithdrawalEnabled,
                        isPaystackPayoutEnabled = paystackPayoutEnabled,
                        isFlutterwavePayoutEnabled = flutterwavePayoutEnabled,
                        minDepositUsd = minDepositText.toDoubleOrNull() ?: 10.0,
                        minWithdrawalUsd = minWithdrawalText.toDoubleOrNull() ?: 10.0,
                        maxWithdrawalUsd = maxWithdrawalText.toDoubleOrNull() ?: 5000.0,
                        transactionFeePercent = feeText.toDoubleOrNull() ?: 0.0
                    )
                    viewModel.updateAdminConfig(updated)
                },
                colors = ButtonDefaults.buttonColors(containerColor = UpGreen),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(text = "Save", color = BackgroundDark, fontWeight = FontWeight.Bold)
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxWidth().weight(1f),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            // Environment Mode (DEMO vs LIVE)
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = SurfaceDark,
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = "PAYMENT ENVIRONMENT", style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontWeight = FontWeight.Bold)
                                Text(text = "Demo Simulation Mode", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = GoldAccent)
                            }
                            Surface(shape = RoundedCornerShape(6.dp), color = GoldGlow) {
                                Text(text = "ACTIVE", color = GoldAccent, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                        }

                        HorizontalDivider(color = CardBorder, thickness = 0.5.dp)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = "Enable LIVE Payment Processing", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                                Text(text = "Requires verified Paystack/Flutterwave backend keys", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            }
                            Switch(
                                checked = false,
                                onCheckedChange = { showLiveWarningDialog = true },
                                colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = UpGreen)
                            )
                        }
                    }
                }
            }

            // Deposit Methods Control
            item {
                Text(text = "Deposit Methods", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
            }

            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = SurfaceDark,
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        AdminToggleRow("Direct Bank Transfer", bankDepositEnabled) { bankDepositEnabled = it }
                        HorizontalDivider(color = CardBorder, thickness = 0.5.dp)
                        AdminToggleRow("Paystack Gateway", paystackDepositEnabled) { paystackDepositEnabled = it }
                        HorizontalDivider(color = CardBorder, thickness = 0.5.dp)
                        AdminToggleRow("Flutterwave Gateway", flutterwaveDepositEnabled) { flutterwaveDepositEnabled = it }
                    }
                }
            }

            // Withdrawal Methods Control
            item {
                Text(text = "Withdrawal Methods", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
            }

            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = SurfaceDark,
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        AdminToggleRow("Nigerian Bank Account Transfer", bankWithdrawalEnabled) { bankWithdrawalEnabled = it }
                        HorizontalDivider(color = CardBorder, thickness = 0.5.dp)
                        AdminToggleRow("Paystack Automated Payout", paystackPayoutEnabled) { paystackPayoutEnabled = it }
                        HorizontalDivider(color = CardBorder, thickness = 0.5.dp)
                        AdminToggleRow("Flutterwave Automated Payout", flutterwavePayoutEnabled) { flutterwavePayoutEnabled = it }
                    }
                }
            }

            // Limits & Fees
            item {
                Text(text = "Thresholds & Transaction Fees", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
            }

            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = SurfaceDark,
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        AdminInputField("Minimum Deposit ($)", minDepositText) { minDepositText = it }
                        AdminInputField("Minimum Withdrawal ($)", minWithdrawalText) { minWithdrawalText = it }
                        AdminInputField("Maximum Withdrawal ($)", maxWithdrawalText) { maxWithdrawalText = it }
                        AdminInputField("Transaction Fee (%)", feeText) { feeText = it }
                    }
                }
            }
        }
    }

    if (showLiveWarningDialog) {
        AlertDialog(
            onDismissRequest = { showLiveWarningDialog = false },
            containerColor = SurfaceDark,
            title = { Text("Live Processing Inactive", fontWeight = FontWeight.Bold, color = TextPrimary) },
            text = {
                Text(
                    text = "Live payment processing is strictly disabled in demo mode. To connect real Paystack/Flutterwave payments, configure your server-side API keys and webhook secrets on your secure backend.",
                    color = TextSecondary
                )
            },
            confirmButton = {
                Button(onClick = { showLiveWarningDialog = false }, colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)) {
                    Text("Understood", color = Color.White)
                }
            }
        )
    }
}

@Composable
private fun AdminToggleRow(title: String, isChecked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = title, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
        Switch(
            checked = isChecked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = UpGreen)
        )
    }
}

@Composable
private fun AdminInputField(label: String, value: String, onValueChange: (String) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, style = MaterialTheme.typography.bodySmall, color = TextSecondary, modifier = Modifier.weight(1.5f))
        OutlinedTextField(
            value = value,
            onValueChange = { if (it.all { c -> c.isDigit() || c == '.' }) onValueChange(it) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = PrimaryBlue,
                unfocusedBorderColor = CardBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier.weight(1f).height(48.dp)
        )
    }
}
