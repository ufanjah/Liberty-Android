package com.example.ui

import android.app.Application
import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.config.AdminConfig
import com.example.config.NigerianBankDirectory
import com.example.data.*
import com.example.service.broker.*
import com.example.service.market.MarketDataService
import com.example.service.market.*
import com.example.service.payment.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.Locale

enum class ScreenTab(val label: String) {
    DASHBOARD("Dashboard"),
    TRADE("Trade"),
    OPEN_TRADES("Open Trades"),
    HISTORY("History"),
    ACCOUNT("Account"),
    WALLET("Wallet"),
    DEPOSIT("Deposit"),
    WITHDRAW("Withdraw"),
    TRANSACTIONS("Transactions"),
    BANK_ACCOUNTS("Linked Banks"),
    ADMIN_SETTINGS("Admin Settings"),
    PROFILE("Profile"),
    SECURITY("Security")
}

enum class HistoryFilter {
    ALL, WINS, LOSSES, DRAWS
}

class TradingViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getInstance(application)
    val repository = TradeRepository(database.tradeDao())
    val simulator = MarketSimulator(viewModelScope, repository)

    // Market Data Architecture Components (Requirement 4)
    val candleBuilder = CandleBuilder()
    val marketDataService = MarketDataService(viewModelScope, candleBuilder)
    val brokerIntegration: BrokerIntegration = LibertyDemoBrokerAdapter()

    // Active Indicator Instances
    private val _activeIndicators = MutableStateFlow<List<IndicatorInstance>>(
        listOf(
            IndicatorInstance(
                id = "sma_10",
                definitionId = "SMA",
                name = "SMA (Simple Moving Average)",
                category = IndicatorCategory.TREND,
                parameters = mapOf("length" to 10.0),
                isVisible = true,
                color = Color(0xFFFFB300)
            ),
            IndicatorInstance(
                id = "bollinger_20",
                definitionId = "BOLLINGER",
                name = "Bollinger Bands",
                category = IndicatorCategory.VOLATILITY,
                parameters = mapOf("length" to 20.0, "stdDev" to 2.0),
                isVisible = true,
                color = Color(0xFF60A5FA)
            ),
            IndicatorInstance(
                id = "supertrend_10",
                definitionId = "SUPERTREND",
                name = "Supertrend",
                category = IndicatorCategory.TREND,
                parameters = mapOf("atrPeriod" to 10.0, "multiplier" to 3.0),
                isVisible = false,
                color = Color(0xFF00E676)
            ),
            IndicatorInstance(
                id = "fractals_2",
                definitionId = "FRACTALS",
                name = "Bill Williams Fractals",
                category = IndicatorCategory.PRICE_ACTION,
                parameters = mapOf("strength" to 2.0),
                isVisible = false,
                color = Color(0xFFFFB300)
            )
        )
    )
    val activeIndicators: StateFlow<List<IndicatorInstance>> = _activeIndicators.asStateFlow()

    // Signal Engine Configuration
    private val _signalSettings = MutableStateFlow(SignalSettings())
    val signalSettings: StateFlow<SignalSettings> = _signalSettings.asStateFlow()

    // Calculated Indicators from live candles
    val calculatedIndicators: StateFlow<CalculatedIndicators> = combine(
        simulator.candles,
        activeIndicators
    ) { candles, indicators ->
        IndicatorEngine.calculateIndicators(candles, indicators)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), CalculatedIndicators())

    // Signal Evaluation
    val signalEvaluation: StateFlow<SignalEvaluation> = combine(
        simulator.candles,
        calculatedIndicators,
        signalSettings
    ) { candles, indicators, settings ->
        SignalEngine.evaluate(candles, indicators, settings)
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        SignalEvaluation(
            state = SignalState.WAIT,
            confirmations = 0,
            totalConditionsChecked = 4,
            trendStatus = "Evaluating",
            momentumStatus = "Neutral",
            details = emptyList()
        )
    )

    // Payment Provider Layer (Mock for DEMO, ready for Paystack / Flutterwave backend proxy)
    val paymentProvider: PaymentProvider = MockPaymentProvider()

    // Trading Account Service (Clean broker abstraction)
    val tradingAccountService: TradingAccountService = DemoTradingAccountService()
    val tradingAccountInfo: StateFlow<TradingAccountInfo> = tradingAccountService.tradingAccount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), TradingAccountInfo())

    // Admin Configuration
    private val _adminConfig = MutableStateFlow(AdminConfig())
    val adminConfig: StateFlow<AdminConfig> = _adminConfig.asStateFlow()

    private val tradePlacementMutex = Mutex()
    private val _isPlacingTrade = MutableStateFlow(false)
    val isPlacingTrade: StateFlow<Boolean> = _isPlacingTrade.asStateFlow()

    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = application.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vibratorManager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        application.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    // Navigation Tab (TRADE is primary focus)
    private val _currentTab = MutableStateFlow(ScreenTab.TRADE)
    val currentTab: StateFlow<ScreenTab> = _currentTab.asStateFlow()

    // Navigation back stack for sub-screens
    private val _navigationStack = mutableListOf(ScreenTab.TRADE)

    // Trade inputs
    private val _selectedAmount = MutableStateFlow(10.0)
    val selectedAmount: StateFlow<Double> = _selectedAmount.asStateFlow()

    private val _selectedExpirySeconds = MutableStateFlow(30)
    val selectedExpirySeconds: StateFlow<Int> = _selectedExpirySeconds.asStateFlow()

    // History filter
    private val _historyFilter = MutableStateFlow(HistoryFilter.ALL)
    val historyFilter: StateFlow<HistoryFilter> = _historyFilter.asStateFlow()

    // Dialog & Feedback state
    private val _currentResultEvent = MutableStateFlow<TradeResultEvent?>(null)
    val currentResultEvent: StateFlow<TradeResultEvent?> = _currentResultEvent.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    // In-app Notifications
    private val _notifications = MutableStateFlow<List<NotificationItem>>(
        listOf(
            NotificationItem(
                title = "Welcome to LIBERTY",
                message = "Your $10,000 virtual demo balance is ready for practice trading.",
                type = "SECURITY"
            )
        )
    )
    val notifications: StateFlow<List<NotificationItem>> = _notifications.asStateFlow()

    val unreadNotificationCount: StateFlow<Int> = _notifications.map { list ->
        list.count { !it.isRead }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 1)

    val account: StateFlow<UserAccountEntity> = repository.account
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserAccountEntity(id = 1, demoBalance = 10000.0, availableBalance = 10000.0))

    val userProfile: StateFlow<UserProfileEntity> = repository.userProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserProfileEntity())

    val allTransactions: StateFlow<List<TransactionEntity>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savedBankAccounts: StateFlow<List<SavedBankAccountEntity>> = repository.savedBankAccounts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTrades: StateFlow<List<TradeEntity>> = repository.allTrades
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredTrades: StateFlow<List<TradeEntity>> = combine(allTrades, historyFilter) { trades, filter ->
        when (filter) {
            HistoryFilter.ALL -> trades
            HistoryFilter.WINS -> trades.filter { it.result == "WIN" || it.result == "WON" }
            HistoryFilter.LOSSES -> trades.filter { it.result == "LOSS" || it.result == "LOST" }
            HistoryFilter.DRAWS -> trades.filter { it.result == "DRAW" || it.result == "TIE" }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Collect simulator trade results
        viewModelScope.launch {
            simulator.tradeEvents.collect { event ->
                _currentResultEvent.value = event
                triggerHaptic(if (event.isWin) 80 else 40)

                val resultTitle = when {
                    event.isTie -> "Trade Expired: DRAW"
                    event.isWin -> "Trade Won: +$${String.format(Locale.US, "%.2f", event.profitOrLoss)}"
                    else -> "Trade Lost: -$${String.format(Locale.US, "%.2f", event.trade.amount)}"
                }
                val resultMsg = "${event.trade.assetSymbol} • ${event.trade.direction} at ${String.format(Locale.US, "%.5f", event.trade.entryPrice)} → ${String.format(Locale.US, "%.5f", event.trade.expiryPrice)}"
                addNotification(resultTitle, resultMsg, if (event.isWin) "TRADE_EXPIRED_WIN" else if (event.isTie) "TRADE_EXPIRED_DRAW" else "TRADE_EXPIRED_LOSS")
            }
        }

        // Seed initial verified demo bank account if none exist
        viewModelScope.launch {
            savedBankAccounts.first { accounts ->
                if (accounts.isEmpty()) {
                    repository.saveBankAccount(
                        SavedBankAccountEntity(
                            bankName = "Guaranty Trust Bank (GTBank)",
                            bankCode = "058",
                            accountNumber = "0123456789",
                            accountName = "Alexander Morgan Adeyemi",
                            accountType = "Savings",
                            isDefault = true,
                            isVerified = true
                        )
                    )
                }
                true
            }
        }

        // Wire live ticks from MarketDataService into CandleBuilder and MarketSimulator
        viewModelScope.launch {
            marketDataService.observeTicks().collect { tick ->
                val currentTf = simulator.currentTimeframe.value
                val liveCandles = candleBuilder.getCandles(tick.symbol, currentTf)
                simulator.updateWithLiveTick(tick, liveCandles)
            }
        }

        // Track live connection state
        viewModelScope.launch {
            marketDataService.connectionStatus.collect { status ->
                simulator.isLiveActive = (status == DataConnectionState.LIVE)
            }
        }

        // Synchronize asset selection with Deriv WebSocket subscription
        viewModelScope.launch {
            simulator.selectedAsset.collect { asset ->
                marketDataService.selectSymbol(asset.symbol)
            }
        }

        // When timeframe changes, update candles from CandleBuilder
        viewModelScope.launch {
            simulator.currentTimeframe.collect { tf ->
                val asset = simulator.selectedAsset.value
                val candles = candleBuilder.getCandles(asset.symbol, tf)
                if (candles.isNotEmpty()) {
                    val latestTick = marketDataService.getLatestTick(asset.symbol)
                    if (latestTick != null) {
                        simulator.updateWithLiveTick(latestTick, candles)
                    }
                }
            }
        }
    }

    fun selectTab(tab: ScreenTab) {
        if (_currentTab.value != tab) {
            _navigationStack.add(tab)
            _currentTab.value = tab
        }
    }

    fun navigateBack(): Boolean {
        if (_navigationStack.size > 1) {
            _navigationStack.removeAt(_navigationStack.lastIndex)
            _currentTab.value = _navigationStack.last()
            return true
        }
        return false
    }

    fun setAmount(amount: Double) {
        if (amount > 0) {
            _selectedAmount.value = (amount * 100).toLong() / 100.0
        }
    }

    fun adjustAmount(delta: Double) {
        val next = (_selectedAmount.value + delta).coerceAtLeast(1.0)
        _selectedAmount.value = (next * 100).toLong() / 100.0
    }

    fun setExpiry(seconds: Int) {
        _selectedExpirySeconds.value = seconds
    }

    fun setHistoryFilter(filter: HistoryFilter) {
        _historyFilter.value = filter
    }

    fun dismissResultDialog() {
        _currentResultEvent.value = null
    }

    fun dismissSnackbar() {
        _snackbarMessage.value = null
    }

    fun showSnackbar(message: String) {
        _snackbarMessage.value = message
    }

    fun addIndicator(definition: IndicatorDefinition) {
        val newInst = IndicatorInstance(
            id = "${definition.id.lowercase()}_${System.currentTimeMillis()}",
            definitionId = definition.id,
            name = definition.name,
            category = definition.category,
            parameters = definition.defaultParameters,
            isVisible = true,
            color = Color(definition.defaultColorHex)
        )
        _activeIndicators.value = _activeIndicators.value + newInst
        showSnackbar("Added ${definition.name}")
    }

    fun toggleIndicatorVisibility(instanceId: String) {
        _activeIndicators.value = _activeIndicators.value.map {
            if (it.id == instanceId) it.copy(isVisible = !it.isVisible) else it
        }
    }

    fun removeIndicator(instanceId: String) {
        val target = _activeIndicators.value.firstOrNull { it.id == instanceId }
        _activeIndicators.value = _activeIndicators.value.filter { it.id != instanceId }
        target?.let { showSnackbar("Removed ${it.name}") }
    }

    fun updateIndicatorParams(instanceId: String, newParams: Map<String, Double>) {
        _activeIndicators.value = _activeIndicators.value.map {
            if (it.id == instanceId) it.copy(parameters = newParams) else it
        }
        showSnackbar("Updated parameters")
    }

    fun resetIndicatorParams(instanceId: String) {
        val target = _activeIndicators.value.firstOrNull { it.id == instanceId } ?: return
        val def = IndicatorEngine.CATALOG.firstOrNull { it.id == target.definitionId } ?: return
        _activeIndicators.value = _activeIndicators.value.map {
            if (it.id == instanceId) it.copy(parameters = def.defaultParameters) else it
        }
        showSnackbar("Reset parameters to default")
    }

    fun updateSignalSettings(settings: SignalSettings) {
        _signalSettings.value = settings
        showSnackbar("Saved signal rules")
    }

    fun reconnectMarketData() {
        marketDataService.reconnect()
        showSnackbar("Reconnecting to live data...")
    }

    fun switchToLiveFeed() {
        marketDataService.updateConfig(MarketDataConfig(isLiveConfigured = true))
        showSnackbar("Switched to Live Deriv Feed")
    }

    fun switchToDemoFeed() {
        marketDataService.updateConfig(MarketDataConfig(isLiveConfigured = false))
        showSnackbar("Switched to Demo Simulation")
    }

    fun placeTrade(direction: String) {
        viewModelScope.launch {
            if (_isPlacingTrade.value) return@launch

            tradePlacementMutex.withLock {
                _isPlacingTrade.value = true
                try {
                    // When in LIVE mode, verify a valid live stream is connected
                    val connStatus = marketDataService.connectionStatus.value
                    if (marketDataService.isLiveConnection && connStatus != DataConnectionState.LIVE) {
                        _snackbarMessage.value = "LIVE DATA REQUIRED"
                        triggerHaptic(20)
                        return@withLock
                    }

                    val amount = _selectedAmount.value
                    val duration = _selectedExpirySeconds.value
                    val currentBal = account.value.availableBalance

                    if (currentBal < amount) {
                        _snackbarMessage.value = "Insufficient demo balance! Top up in Wallet."
                        triggerHaptic(20)
                        return@withLock
                    }

                    val success = simulator.placeTrade(direction, amount, duration)
                    if (success) {
                        triggerHaptic(50)
                        _snackbarMessage.value = "Demo trade placed: $direction $$amount (${duration}s)"
                        addNotification(
                            "Trade Opened: $direction",
                            "$direction $${amount.toInt()} on ${simulator.selectedAsset.value.symbol} (${duration}s)",
                            "TRADE_OPENED"
                        )
                    } else {
                        _snackbarMessage.value = "Failed to place trade. Please check balance."
                    }
                } finally {
                    kotlinx.coroutines.delay(400)
                    _isPlacingTrade.value = false
                }
            }
        }
    }

    fun resetDemoBalance() {
        viewModelScope.launch {
            repository.resetDemoBalance()
            triggerHaptic(30)
            _snackbarMessage.value = "Demo balance reset to $10,000.00"
            addNotification("Balance Reset", "Your virtual demo balance has been restored to $10,000.00.", "SECURITY")
        }
    }

    fun topUpDemoBalance(amount: Double) {
        viewModelScope.launch {
            repository.topUpDemoBalance(amount)
            triggerHaptic(30)
            _snackbarMessage.value = "Added $${amount.toInt()} demo funds"
            addNotification("Demo Funds Added", "+$${amount.toInt()} virtual credit added to wallet.", "DEPOSIT")
        }
    }

    /**
     * Requirement 7: DEPOSIT FLOW with Payment Provider abstraction
     */
    fun depositDemo(amount: Double, paymentMethod: String) {
        val minDep = _adminConfig.value.minDepositUsd
        if (amount < minDep) {
            _snackbarMessage.value = "Minimum deposit amount is $${minDep.toInt()}"
            triggerHaptic(20)
            return
        }

        viewModelScope.launch {
            val req = DepositRequest(
                amount = amount,
                paymentMethod = paymentMethod,
                customerEmail = userProfile.value.email,
                customerName = userProfile.value.fullName
            )
            val result = paymentProvider.initializeDeposit(req)
            result.onSuccess { response ->
                repository.recordDeposit(amount, paymentMethod, response.reference)
                triggerHaptic(50)
                _snackbarMessage.value = "DEMO Deposit successful: +$${String.format(Locale.US, "%.2f", amount)}"
                addNotification(
                    "Demo Deposit Completed",
                    "Simulated deposit of $${String.format(Locale.US, "%.2f", amount)} via $paymentMethod (Ref: ${response.reference})",
                    "DEPOSIT"
                )
            }.onFailure { err ->
                _snackbarMessage.value = "Deposit simulation failed: ${err.message}"
            }
        }
    }

    /**
     * Requirement 8: WITHDRAWAL FLOW with Payment Provider abstraction & limits
     */
    fun withdrawDemo(amount: Double, bankName: String, accountName: String, accountNumber: String): Boolean {
        val minWth = _adminConfig.value.minWithdrawalUsd
        val maxWth = _adminConfig.value.maxWithdrawalUsd
        val avail = account.value.availableBalance

        if (amount < minWth) {
            _snackbarMessage.value = "Minimum withdrawal is $${minWth.toInt()}"
            triggerHaptic(20)
            return false
        }
        if (amount > maxWth) {
            _snackbarMessage.value = "Maximum withdrawal is $${maxWth.toInt()}"
            triggerHaptic(20)
            return false
        }
        if (avail < amount) {
            _snackbarMessage.value = "Insufficient available demo funds to withdraw"
            triggerHaptic(20)
            return false
        }

        val bank = NigerianBankDirectory.findByName(bankName)
        val bankCode = bank?.code ?: "058"

        viewModelScope.launch {
            val req = WithdrawalRequest(
                amount = amount,
                bankCode = bankCode,
                bankName = bankName,
                accountNumber = accountNumber,
                accountName = accountName,
                paymentMethod = "Nigerian Bank Transfer",
                customerEmail = userProfile.value.email
            )
            val result = paymentProvider.initializeWithdrawal(req)
            result.onSuccess { response ->
                val tx = repository.recordWithdrawal(amount, bankName, accountName, accountNumber, response.reference)
                if (tx != null) {
                    triggerHaptic(50)
                    _snackbarMessage.value = "DEMO Withdrawal submitted: $${String.format(Locale.US, "%.2f", amount)}"
                    addNotification(
                        "Demo Withdrawal Requested",
                        "Simulated payout of $${String.format(Locale.US, "%.2f", amount)} to $bankName (Ref: ${response.reference})",
                        "WITHDRAWAL"
                    )
                }
            }.onFailure { err ->
                _snackbarMessage.value = "Withdrawal request failed: ${err.message}"
            }
        }
        return true
    }

    /**
     * Requirement 3: ACCOUNT NAME VERIFICATION via Payment Provider
     */
    suspend fun resolveAccountName(bankCode: String, accountNumber: String): Result<AccountResolutionResult> {
        return paymentProvider.resolveAccount(bankCode, accountNumber)
    }

    /**
     * Requirement 4: SAVE VERIFIED BANK ACCOUNT
     */
    fun saveBankAccount(
        bankName: String,
        bankCode: String,
        accountNumber: String,
        accountName: String,
        accountType: String,
        phoneNumber: String = "",
        isDefault: Boolean = false
    ) {
        viewModelScope.launch {
            val entity = SavedBankAccountEntity(
                bankName = bankName,
                bankCode = bankCode,
                accountNumber = accountNumber,
                accountName = accountName,
                accountType = accountType,
                phoneNumber = phoneNumber,
                isDefault = isDefault,
                isVerified = true
            )
            repository.saveBankAccount(entity)
            triggerHaptic(40)
            _snackbarMessage.value = "Bank account saved to Linked Accounts"
            addNotification(
                "Bank Account Linked",
                "Verified $bankName (${entity.maskedAccountNumber}) added.",
                "SECURITY"
            )
        }
    }

    fun updateBankAccount(account: SavedBankAccountEntity) {
        viewModelScope.launch {
            repository.updateBankAccount(account)
            _snackbarMessage.value = "Bank account updated"
        }
    }

    fun deleteBankAccount(id: Long) {
        viewModelScope.launch {
            repository.deleteBankAccount(id)
            triggerHaptic(30)
            _snackbarMessage.value = "Bank account removed"
        }
    }

    fun setDefaultBankAccount(id: Long) {
        viewModelScope.launch {
            repository.setDefaultBankAccount(id)
            triggerHaptic(30)
            _snackbarMessage.value = "Set as default payout account"
        }
    }

    fun updateAdminConfig(config: AdminConfig) {
        _adminConfig.value = config
        _snackbarMessage.value = "Payment administration settings saved"
    }

    fun updateProfile(profile: UserProfileEntity) {
        viewModelScope.launch {
            repository.updateProfile(profile)
            triggerHaptic(30)
            _snackbarMessage.value = "Profile updated successfully"
            addNotification("Profile Updated", "Your trader profile information has been saved.", "PROFILE")
        }
    }

    fun addNotification(title: String, message: String, type: String) {
        val item = NotificationItem(
            title = title,
            message = message,
            type = type,
            timestamp = System.currentTimeMillis()
        )
        _notifications.value = listOf(item) + _notifications.value
    }

    fun markNotificationsRead() {
        _notifications.value = _notifications.value.map { it.copy(isRead = true) }
    }

    fun clearNotifications() {
        _notifications.value = emptyList()
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
            _snackbarMessage.value = "Trade history cleared"
        }
    }

    fun clearTransactions() {
        viewModelScope.launch {
            repository.clearTransactions()
            _snackbarMessage.value = "Transaction history cleared"
        }
    }

    private fun triggerHaptic(durationMs: Long) {
        try {
            if (vibrator?.hasVibrator() == true) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(durationMs)
                }
            }
        } catch (_: Exception) {}
    }
}
