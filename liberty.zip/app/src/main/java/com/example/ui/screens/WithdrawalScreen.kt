package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.config.NigerianBankDirectory
import com.example.data.SavedBankAccountEntity
import com.example.ui.ScreenTab
import com.example.ui.TradingViewModel
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WithdrawalScreen(
    viewModel: TradingViewModel,
    modifier: Modifier = Modifier
) {
    val account by viewModel.account.collectAsState()
    val savedAccounts by viewModel.savedBankAccounts.collectAsState()
    val adminConfig by viewModel.adminConfig.collectAsState()

    var amountText by remember { mutableStateOf("50") }
    var selectedAccountId by remember { mutableStateOf<Long?>(null) }
    var selectedPayoutMethod by remember { mutableStateOf("Nigerian Bank Account Transfer") }

    var showConfirmDialog by remember { mutableStateOf(false) }
    var showResultDialog by remember { mutableStateOf(false) }
    var showAddAccountDialog by remember { mutableStateOf(false) }
    var lastSubmittedRef by remember { mutableStateOf("") }
    var lastWithdrawalId by remember { mutableStateOf("") }

    // Auto-select default bank account if none selected
    LaunchedEffect(savedAccounts) {
        if (selectedAccountId == null && savedAccounts.isNotEmpty()) {
            val defaultAcc = savedAccounts.find { it.isDefault } ?: savedAccounts.first()
            selectedAccountId = defaultAcc.id
        }
    }

    val selectedAccount = savedAccounts.find { it.id == selectedAccountId }

    val parsedAmount = amountText.toDoubleOrNull() ?: 0.0
    val minWithdrawal = adminConfig.minWithdrawalUsd
    val maxWithdrawal = adminConfig.maxWithdrawalUsd
    val isAmountValid = parsedAmount >= minWithdrawal && parsedAmount <= maxWithdrawal && parsedAmount <= account.availableBalance
    val canSubmit = isAmountValid && selectedAccount != null

    val payoutMethods = listOf(
        "Nigerian Bank Account Transfer",
        "Paystack Automated Payout",
        "Flutterwave Automated Payout"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 32.dp)
    ) {
        // Back Button & Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                IconButton(
                    onClick = { viewModel.selectTab(ScreenTab.WALLET) },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextPrimary
                    )
                }
                Column {
                    Text(
                        text = "Withdraw Funds",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "Simulated Nigerian Payout Request",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }

        // Available Balance Indicator
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = SurfaceDark,
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "AVAILABLE FOR DEMO PAYOUT",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "$${String.format(Locale.US, "%,.2f", account.availableBalance)}",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Black,
                            color = UpGreen
                        )
                        Text(
                            text = "Limits: $${minWithdrawal.toInt()} min - $${maxWithdrawal.toInt()} max",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted,
                            fontSize = 9.sp
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = GoldGlow
                    ) {
                        Text(
                            text = "DEMO ONLY",
                            color = GoldAccent,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        // 1. Select Saved Bank Account (Requirement 8)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Select Destination Bank Account",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                TextButton(
                    onClick = { showAddAccountDialog = true },
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Add New", color = PrimaryBlue, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (savedAccounts.isEmpty()) {
            item {
                Surface(
                    onClick = { showAddAccountDialog = true },
                    shape = RoundedCornerShape(14.dp),
                    color = SurfaceDark,
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                    modifier = Modifier.fillMaxWidth().testTag("add_account_prompt")
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.AccountBalance, contentDescription = null, tint = PrimaryBlue)
                        Column {
                            Text(text = "No bank account linked", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text(text = "Tap to verify and link a Nigerian bank account", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                    }
                }
            }
        } else {
            items(savedAccounts, key = { it.id }) { acc ->
                val isSelected = selectedAccountId == acc.id
                Surface(
                    onClick = { selectedAccountId = acc.id },
                    shape = RoundedCornerShape(12.dp),
                    color = SurfaceDark,
                    border = androidx.compose.foundation.BorderStroke(
                        width = if (isSelected) 1.5.dp else 1.dp,
                        color = if (isSelected) PrimaryBlue else CardBorder
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("select_account_${acc.id}")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = { selectedAccountId = acc.id },
                                colors = RadioButtonDefaults.colors(selectedColor = PrimaryBlue)
                            )
                            Column {
                                Text(text = acc.bankName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                                Text(text = "${acc.accountName} • ${acc.maskedAccountNumber}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                        }

                        Surface(shape = RoundedCornerShape(4.dp), color = PrimaryBlue.copy(alpha = 0.2f)) {
                            Text(text = "VERIFIED", color = PrimaryBlue, style = MaterialTheme.typography.labelSmall, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                    }
                }
            }
        }

        // 2. Select Payment Payout Rail (Requirement 5)
        item {
            Text(
                text = "Payout Service / Rail",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                payoutMethods.forEach { method ->
                    val isSelected = selectedPayoutMethod == method
                    Surface(
                        onClick = { selectedPayoutMethod = method },
                        shape = RoundedCornerShape(10.dp),
                        color = SurfaceDark,
                        border = androidx.compose.foundation.BorderStroke(
                            width = if (isSelected) 1.dp else 0.5.dp,
                            color = if (isSelected) PrimaryBlue else CardBorder
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = method, style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                            RadioButton(
                                selected = isSelected,
                                onClick = { selectedPayoutMethod = method },
                                colors = RadioButtonDefaults.colors(selectedColor = PrimaryBlue)
                            )
                        }
                    }
                }
            }
        }

        // 3. Enter Amount
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = SurfaceDark,
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "ENTER WITHDRAWAL AMOUNT (USD)",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary,
                        fontSize = 8.sp
                    )

                    OutlinedTextField(
                        value = amountText,
                        onValueChange = { input ->
                            if (input.all { it.isDigit() || it == '.' }) {
                                amountText = input
                            }
                        },
                        prefix = { Text(text = "$", color = GoldAccent, fontWeight = FontWeight.Bold) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PrimaryBlue,
                            unfocusedBorderColor = CardBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("withdraw_amount_field")
                    )

                    // Error states
                    if (parsedAmount > 0 && parsedAmount < minWithdrawal) {
                        Text(text = "Amount below minimum withdrawal limit ($${minWithdrawal.toInt()})", color = DownRed, style = MaterialTheme.typography.labelSmall)
                    } else if (parsedAmount > maxWithdrawal) {
                        Text(text = "Amount exceeds maximum withdrawal limit ($${maxWithdrawal.toInt()})", color = DownRed, style = MaterialTheme.typography.labelSmall)
                    } else if (parsedAmount > account.availableBalance) {
                        Text(text = "Amount exceeds available balance ($${String.format(Locale.US, "%.2f", account.availableBalance)})", color = DownRed, style = MaterialTheme.typography.labelSmall)
                    } else if (parsedAmount > 0) {
                        Text(text = "≈ ₦${String.format(Locale.US, "%,.0f", parsedAmount * 1500)} Estimated at ₦1,500/USD", color = UpGreen, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }

        // Review & Submit Button
        item {
            Button(
                onClick = { showConfirmDialog = true },
                enabled = canSubmit,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("review_withdrawal_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
            ) {
                Text(
                    text = "REVIEW WITHDRAWAL • $${String.format(Locale.US, "%.2f", parsedAmount)}",
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp,
                    color = Color.White
                )
            }
        }
    }

    // Confirmation Review Dialog (Requirement 8)
    if (showConfirmDialog && selectedAccount != null) {
        val currentDate = remember { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date()) }
        val generatedWithdrawalId = remember { "WTH-${(100000..999999).random()}" }

        AlertDialog(
            onDismissRequest = { showConfirmDialog = false },
            containerColor = SurfaceDark,
            title = {
                Text(
                    text = "Confirm Demo Withdrawal",
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Please verify your simulated payout request:",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = SurfaceVariantDark,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            ConfirmRow("Withdrawal ID", generatedWithdrawalId, valueColor = GoldAccent)
                            ConfirmRow("Amount", "$${String.format(Locale.US, "%.2f", parsedAmount)} (≈ ₦${String.format(Locale.US, "%,.0f", parsedAmount * 1500)})")
                            ConfirmRow("Destination Bank", selectedAccount.bankName)
                            ConfirmRow("Account Name", selectedAccount.accountName)
                            ConfirmRow("Account Number", selectedAccount.maskedAccountNumber)
                            ConfirmRow("Payout Rail", selectedPayoutMethod)
                            ConfirmRow("Date", currentDate)
                            ConfirmRow("Status", "DEMO / PENDING", valueColor = GoldAccent)
                        }
                    }

                    Text(
                        text = "Notice: This will record a DEMO withdrawal. In demo mode, no real money is sent.",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val success = viewModel.withdrawDemo(
                            amount = parsedAmount,
                            bankName = selectedAccount.bankName,
                            accountName = selectedAccount.accountName,
                            accountNumber = selectedAccount.accountNumber
                        )
                        if (success) {
                            lastSubmittedRef = "LIB-WTH-${(100000..999999).random()}"
                            lastWithdrawalId = generatedWithdrawalId
                            showConfirmDialog = false
                            showResultDialog = true
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = UpGreen)
                ) {
                    Text("Confirm Payout", color = BackgroundDark, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }

    // Success Result Dialog
    if (showResultDialog) {
        AlertDialog(
            onDismissRequest = { showResultDialog = false },
            containerColor = SurfaceDark,
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = GoldAccent)
                    Text(text = "DEMO Withdrawal Queued", color = TextPrimary, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Simulated withdrawal registered with status DEMO / PENDING.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Text(text = "Withdrawal ID: $lastWithdrawalId", style = MaterialTheme.typography.labelSmall, color = TextPrimary, fontWeight = FontWeight.Bold)
                    Text(text = "Reference: $lastSubmittedRef", style = MaterialTheme.typography.labelSmall, color = GoldAccent, fontWeight = FontWeight.Bold)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showResultDialog = false
                        viewModel.selectTab(ScreenTab.TRANSACTIONS)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                ) {
                    Text("View Transactions", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // Add New Bank Account Dialog
    if (showAddAccountDialog) {
        BankVerificationDialog(
            viewModel = viewModel,
            initialAccount = null,
            onDismiss = { showAddAccountDialog = false }
        )
    }
}

@Composable
private fun ConfirmRow(label: String, value: String, valueColor: Color = TextPrimary) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        Text(text = value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = valueColor)
    }
}
