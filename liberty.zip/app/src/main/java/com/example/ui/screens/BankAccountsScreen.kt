package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.config.NigerianBank
import com.example.config.NigerianBankDirectory
import com.example.data.SavedBankAccountEntity
import com.example.service.payment.AccountResolutionResult
import com.example.ui.ScreenTab
import com.example.ui.TradingViewModel
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BankAccountsScreen(
    viewModel: TradingViewModel,
    modifier: Modifier = Modifier
) {
    val savedAccounts by viewModel.savedBankAccounts.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }
    var accountToEdit by remember { mutableStateOf<SavedBankAccountEntity?>(null) }
    var accountToDelete by remember { mutableStateOf<SavedBankAccountEntity?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(horizontal = 16.dp)
    ) {
        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(
                    onClick = { viewModel.selectTab(ScreenTab.WALLET) },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextPrimary
                    )
                }
                Column {
                    Text(
                        text = "Linked Bank Accounts",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "Nigerian payout destinations",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }

            Button(
                onClick = { showAddDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = UpGreen),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                modifier = Modifier.testTag("add_bank_account_button")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = BackgroundDark, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "Add Bank", fontWeight = FontWeight.Bold, color = BackgroundDark, fontSize = 12.sp)
            }
        }

        // Demo Simulation Disclaimer
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = SurfaceVariantDark,
            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(20.dp))
                Text(
                    text = "Demo Mode: Verification simulates NIBSS NUBAN name resolution. Live account linkage requires configured payment provider keys.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            }
        }

        // List of Saved Bank Accounts
        if (savedAccounts.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.AccountBalance, contentDescription = null, tint = TextMuted, modifier = Modifier.size(48.dp))
                    Text(text = "No linked bank accounts", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                    Text(text = "Add your Nigerian bank account for demo withdrawals", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(savedAccounts, key = { it.id }) { acc ->
                    SavedBankCard(
                        account = acc,
                        onSetDefault = { viewModel.setDefaultBankAccount(acc.id) },
                        onEdit = { accountToEdit = acc },
                        onDelete = { accountToDelete = acc }
                    )
                }
            }
        }
    }

    // Add / Verify Bank Account Dialog
    if (showAddDialog) {
        BankVerificationDialog(
            viewModel = viewModel,
            initialAccount = null,
            onDismiss = { showAddDialog = false }
        )
    }

    // Edit Bank Account Dialog
    accountToEdit?.let { editTarget ->
        BankVerificationDialog(
            viewModel = viewModel,
            initialAccount = editTarget,
            onDismiss = { accountToEdit = null }
        )
    }

    // Delete Confirmation Dialog
    accountToDelete?.let { delTarget ->
        AlertDialog(
            onDismissRequest = { accountToDelete = null },
            containerColor = SurfaceDark,
            title = { Text(text = "Remove Bank Account?", fontWeight = FontWeight.Bold, color = TextPrimary) },
            text = {
                Text(
                    text = "Are you sure you want to remove ${delTarget.bankName} (${delTarget.maskedAccountNumber})?",
                    color = TextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteBankAccount(delTarget.id)
                        accountToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DownRed)
                ) {
                    Text("Remove", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { accountToDelete = null }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
fun SavedBankCard(
    account: SavedBankAccountEntity,
    onSetDefault: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = SurfaceDark,
        border = androidx.compose.foundation.BorderStroke(
            width = if (account.isDefault) 1.5.dp else 1.dp,
            color = if (account.isDefault) UpGreen else CardBorder
        ),
        modifier = Modifier.fillMaxWidth().testTag("saved_bank_card_${account.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Top Row: Bank name & badges
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .background(PrimaryBlue.copy(alpha = 0.2f), RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.AccountBalance, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(18.dp))
                    }
                    Column {
                        Text(text = account.bankName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text(text = "Code: ${account.bankCode} • ${account.accountType}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (account.isDefault) {
                        Surface(shape = RoundedCornerShape(6.dp), color = UpGreenGlow) {
                            Text(
                                text = "DEFAULT",
                                style = MaterialTheme.typography.labelSmall,
                                color = UpGreen,
                                fontWeight = FontWeight.Bold,
                                fontSize = 8.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Surface(shape = RoundedCornerShape(6.dp), color = PrimaryBlue.copy(alpha = 0.2f)) {
                        Text(
                            text = "VERIFIED",
                            style = MaterialTheme.typography.labelSmall,
                            color = PrimaryBlue,
                            fontWeight = FontWeight.Bold,
                            fontSize = 8.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            HorizontalDivider(color = CardBorder, thickness = 0.5.dp)

            // Account details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "ACCOUNT NAME", style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontSize = 8.sp)
                    Text(text = account.accountName, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = TextPrimary)
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "ACCOUNT NUMBER", style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontSize = 8.sp)
                    Text(text = account.maskedAccountNumber, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = GoldAccent)
                }
            }

            // Actions row: Set Default, Edit, Delete
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!account.isDefault) {
                    TextButton(onClick = onSetDefault) {
                        Text("Set Default", color = PrimaryBlue, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    }
                }
                IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                    Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit", tint = TextSecondary, modifier = Modifier.size(16.dp))
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                    Icon(imageVector = Icons.Default.DeleteOutline, contentDescription = "Delete", tint = DownRed, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

/**
 * Bank Account Form & Account-Name Verification Flow (Requirements 2, 3, 4)
 */
@Composable
fun BankVerificationDialog(
    viewModel: TradingViewModel,
    initialAccount: SavedBankAccountEntity?,
    onDismiss: () -> Unit
) {
    val allBanks = NigerianBankDirectory.ALL_BANKS
    var selectedBank by remember {
        mutableStateOf(
            if (initialAccount != null) {
                NigerianBankDirectory.findByCode(initialAccount.bankCode) ?: allBanks.first()
            } else {
                allBanks.first()
            }
        )
    }
    var accountNumber by remember { mutableStateOf(initialAccount?.accountNumber ?: "") }
    var accountType by remember { mutableStateOf(initialAccount?.accountType ?: "Savings") }
    var phoneNumber by remember { mutableStateOf(initialAccount?.phoneNumber ?: "") }
    var setAsDefault by remember { mutableStateOf(initialAccount?.isDefault ?: false) }

    var isVerifying by remember { mutableStateOf(false) }
    var verificationResult by remember {
        mutableStateOf(
            if (initialAccount != null) {
                AccountResolutionResult(
                    bankCode = initialAccount.bankCode,
                    bankName = initialAccount.bankName,
                    accountNumber = initialAccount.accountNumber,
                    accountName = initialAccount.accountName
                )
            } else null
        )
    }
    var userConfirmedName by remember { mutableStateOf(initialAccount != null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var showBankPicker by remember { mutableStateOf(false) }
    var bankSearchQuery by remember { mutableStateOf("") }

    val coroutineScope = rememberCoroutineScope()

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceDark,
        title = {
            Text(
                text = if (initialAccount == null) "Add Nigerian Bank Account" else "Edit Bank Account",
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        },
        text = {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 420.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Bank selection trigger (automatically binds bank code)
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(text = "Select Bank", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Surface(
                            onClick = { showBankPicker = true },
                            shape = RoundedCornerShape(10.dp),
                            color = SurfaceVariantDark,
                            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                            modifier = Modifier.fillMaxWidth().testTag("bank_picker_trigger")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = selectedBank.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                                    Text(text = "Bank Code: ${selectedBank.code} (${selectedBank.category.label})", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                }
                                Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null, tint = TextSecondary)
                            }
                        }
                    }
                }

                // Account Number Input
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(text = "Account Number (10 Digits)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        OutlinedTextField(
                            value = accountNumber,
                            onValueChange = {
                                if (it.length <= 10 && it.all { c -> c.isDigit() }) {
                                    accountNumber = it
                                    verificationResult = null
                                    userConfirmedName = false
                                    errorMessage = null
                                }
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = PrimaryBlue,
                                unfocusedBorderColor = CardBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            modifier = Modifier.fillMaxWidth().testTag("bank_account_number_input")
                        )
                    }
                }

                // Account Type & Phone
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(text = "Account Type", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("Savings", "Current").forEach { type ->
                                    val isSel = accountType == type
                                    Surface(
                                        onClick = { accountType = type },
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (isSel) PrimaryBlue else SurfaceVariantDark,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Box(modifier = Modifier.padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                                            Text(text = type, color = if (isSel) TextPrimary else TextSecondary, style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Phone number
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(text = "Phone Number (Linked to Account)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        OutlinedTextField(
                            value = phoneNumber,
                            onValueChange = { phoneNumber = it },
                            singleLine = true,
                            placeholder = { Text("+234...", color = TextMuted) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = PrimaryBlue,
                                unfocusedBorderColor = CardBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                // Verify Button (Requirement 3: Account Name Verification)
                item {
                    if (verificationResult == null) {
                        Button(
                            onClick = {
                                if (accountNumber.length != 10) {
                                    errorMessage = "Please enter a valid 10-digit NUBAN account number."
                                    return@Button
                                }
                                isVerifying = true
                                errorMessage = null
                                coroutineScope.launch {
                                    val res = viewModel.resolveAccountName(selectedBank.code, accountNumber)
                                    isVerifying = false
                                    res.onSuccess {
                                        verificationResult = it
                                        userConfirmedName = true
                                    }.onFailure {
                                        errorMessage = it.message ?: "Failed to verify account"
                                    }
                                }
                            },
                            enabled = accountNumber.length == 10 && !isVerifying,
                            modifier = Modifier.fillMaxWidth().height(44.dp).testTag("verify_account_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            if (isVerifying) {
                                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Verifying with NIBSS...")
                            } else {
                                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Verify Account Name", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Display Returned Account Name & Demo Verification Banner
                verificationResult?.let { res ->
                    item {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = UpGreenGlow,
                            border = androidx.compose.foundation.BorderStroke(1.dp, UpGreen.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = "VERIFIED ACCOUNT NAME", style = MaterialTheme.typography.labelSmall, color = UpGreen, fontWeight = FontWeight.Bold, fontSize = 8.sp)
                                    Surface(shape = RoundedCornerShape(4.dp), color = UpGreen) {
                                        Text(text = "DEMO VERIFIED", color = BackgroundDark, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                    }
                                }
                                Text(
                                    text = res.accountName,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Black,
                                    color = TextPrimary
                                )
                                Text(
                                    text = res.message,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary,
                                    fontSize = 10.sp
                                )

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(top = 4.dp)
                                ) {
                                    Checkbox(
                                        checked = userConfirmedName,
                                        onCheckedChange = { userConfirmedName = it },
                                        colors = CheckboxDefaults.colors(checkedColor = UpGreen)
                                    )
                                    Text(
                                        text = "I confirm this account name matches my records",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextPrimary
                                    )
                                }
                            }
                        }
                    }
                }

                // Default switch
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "Set as default payout account", style = MaterialTheme.typography.bodySmall, color = TextPrimary)
                        Switch(
                            checked = setAsDefault,
                            onCheckedChange = { setAsDefault = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = UpGreen)
                        )
                    }
                }

                // Error message
                errorMessage?.let { err ->
                    item {
                        Text(text = err, color = DownRed, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val resolved = verificationResult
                    if (resolved != null && userConfirmedName) {
                        if (initialAccount != null) {
                            viewModel.updateBankAccount(
                                initialAccount.copy(
                                    bankName = selectedBank.name,
                                    bankCode = selectedBank.code,
                                    accountNumber = accountNumber,
                                    accountName = resolved.accountName,
                                    accountType = accountType,
                                    phoneNumber = phoneNumber,
                                    isDefault = setAsDefault
                                )
                            )
                        } else {
                            viewModel.saveBankAccount(
                                bankName = selectedBank.name,
                                bankCode = selectedBank.code,
                                accountNumber = accountNumber,
                                accountName = resolved.accountName,
                                accountType = accountType,
                                phoneNumber = phoneNumber,
                                isDefault = setAsDefault
                            )
                        }
                        onDismiss()
                    }
                },
                enabled = verificationResult != null && userConfirmedName,
                colors = ButtonDefaults.buttonColors(containerColor = UpGreen),
                modifier = Modifier.testTag("save_bank_confirm_button")
            ) {
                Text("Save Account", color = BackgroundDark, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = TextSecondary) }
        }
    )

    // Full Nigerian Bank Directory Picker
    if (showBankPicker) {
        val filteredBanks = remember(bankSearchQuery) {
            if (bankSearchQuery.isBlank()) allBanks
            else allBanks.filter {
                it.name.contains(bankSearchQuery, ignoreCase = true) ||
                it.shortName.contains(bankSearchQuery, ignoreCase = true) ||
                it.code.contains(bankSearchQuery)
            }
        }

        AlertDialog(
            onDismissRequest = { showBankPicker = false },
            containerColor = SurfaceDark,
            title = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Select Nigerian Financial Institution", fontWeight = FontWeight.Bold, color = TextPrimary)
                    OutlinedTextField(
                        value = bankSearchQuery,
                        onValueChange = { bankSearchQuery = it },
                        placeholder = { Text("Search bank name or code...", color = TextMuted) },
                        singleLine = true,
                        leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = TextSecondary) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PrimaryBlue,
                            unfocusedBorderColor = CardBorder,
                            focusedTextColor = TextPrimary
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("bank_search_input")
                    )
                }
            },
            text = {
                LazyColumn(modifier = Modifier.heightIn(max = 350.dp)) {
                    items(filteredBanks, key = { it.code }) { bank ->
                        val isSel = bank.code == selectedBank.code
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedBank = bank
                                    verificationResult = null
                                    showBankPicker = false
                                }
                                .padding(vertical = 10.dp, horizontal = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = bank.name,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSel) PrimaryBlue else TextPrimary
                                )
                                Text(
                                    text = "Code: ${bank.code} • ${bank.category.label}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary,
                                    fontSize = 10.sp
                                )
                            }
                            if (isSel) {
                                Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(18.dp))
                            }
                        }
                        HorizontalDivider(color = CardBorder, thickness = 0.5.dp)
                    }
                }
            },
            confirmButton = {}
        )
    }
}
