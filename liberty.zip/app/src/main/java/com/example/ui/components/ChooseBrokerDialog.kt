package com.example.ui.components

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.config.BrokerConfig
import com.example.ui.theme.*

enum class BrokerDialogMode {
    SIGN_UP,
    SIGN_IN
}

/**
 * Choose Your Broker Dialog.
 *
 * Requirements:
 * - Title: "Choose Your Broker"
 * - SIGN UP mode:
 *   Subtitle: "Ready to move from demo trading to a live account? Choose a broker below."
 *   1. PEPPERSTONE: [ SIGN UP ] -> Opens exact Pepperstone partner tracking URL
 *   2. POCKET OPTION: [ SIGN UP ] -> Opens Pocket Option registration URL
 * - SIGN IN mode:
 *   Subtitle: "Select your broker to continue to their official login portal."
 *   1. PEPPERSTONE: [ SIGN IN ] -> Opens Pepperstone official login
 *   2. POCKET OPTION: [ SIGN IN ] -> Opens Pocket Option official login
 * - Security: Transparently clarifies Liberty never collects/stores broker credentials.
 */
@Composable
fun ChooseBrokerDialog(
    context: Context,
    mode: BrokerDialogMode = BrokerDialogMode.SIGN_UP,
    onDismiss: () -> Unit
) {
    val isSignUp = mode == BrokerDialogMode.SIGN_UP

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .wrapContentHeight()
                .testTag("choose_broker_dialog"),
            shape = RoundedCornerShape(22.dp),
            color = SurfaceDark,
            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header with Close Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .background(UpGreen, CircleShape)
                            )
                            Text(
                                text = "Choose Your Broker",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Black,
                                color = TextPrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isSignUp) {
                                "Ready to move from demo trading to a live account? Choose a broker below."
                            } else {
                                "Select your broker to continue to their official secure login portal."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            lineHeight = 18.sp
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(32.dp).testTag("close_choose_broker_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                HorizontalDivider(color = CardBorder, thickness = 0.5.dp)

                // Broker 1: Pepperstone
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = SurfaceVariantDark,
                    border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryBlue.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth().testTag("broker_card_pepperstone")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(
                                            brush = Brush.linearGradient(listOf(PrimaryBlue, UpGreen)),
                                            shape = RoundedCornerShape(10.dp)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "P",
                                        color = Color.White,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 18.sp
                                    )
                                }

                                Column {
                                    Text(
                                        text = "Pepperstone",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                    Text(
                                        text = if (isSignUp) "Open a live trading account" else "Official live client portal",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = GoldAccent,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = UpGreenGlow
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.VerifiedUser,
                                        contentDescription = null,
                                        tint = UpGreen,
                                        modifier = Modifier.size(11.dp)
                                    )
                                    Text(
                                        text = "REGULATED",
                                        color = UpGreen,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 8.sp
                                    )
                                }
                            }
                        }

                        // Broker Highlights
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            BrokerFeatureChip(text = "Multi-Regulated")
                            BrokerFeatureChip(text = "Raw Spreads")
                            BrokerFeatureChip(text = "Fast Execution")
                        }

                        // Pepperstone Action Button
                        Button(
                            onClick = {
                                if (isSignUp) {
                                    BrokerConfig.openPepperstoneSignUp(context)
                                } else {
                                    BrokerConfig.openPepperstoneSignIn(context)
                                }
                                onDismiss()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .testTag("pepperstone_action_button"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.OpenInBrowser,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp),
                                    tint = Color.White
                                )
                                Text(
                                    text = if (isSignUp) "SIGN UP WITH PEPPERSTONE" else "SIGN IN TO PEPPERSTONE",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 11.5.sp,
                                    letterSpacing = 0.5.sp,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }

                // Broker 2: Pocket Option
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = SurfaceVariantDark,
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                    modifier = Modifier.fillMaxWidth().testTag("broker_card_pocket_option")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(
                                            brush = Brush.linearGradient(listOf(Color(0xFF0284C7), Color(0xFF0369A1))),
                                            shape = RoundedCornerShape(10.dp)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "PO",
                                        color = Color.White,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 15.sp
                                    )
                                }

                                Column {
                                    Text(
                                        text = "Pocket Option",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                    Text(
                                        text = if (isSignUp) "Digital options registration" else "Official trader login",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = SurfaceElevatedDark
                            ) {
                                Text(
                                    text = "FAST OPTIONS",
                                    color = TextSecondary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 8.sp,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            BrokerFeatureChip(text = "5s - 4h Expiries")
                            BrokerFeatureChip(text = "100+ Assets")
                            BrokerFeatureChip(text = "Social Trading")
                        }

                        // Pocket Option Action Button
                        OutlinedButton(
                            onClick = {
                                if (isSignUp) {
                                    BrokerConfig.openPocketOptionSignUp(context)
                                } else {
                                    BrokerConfig.openPocketOptionSignIn(context)
                                }
                                onDismiss()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .testTag("pocket_option_action_button"),
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryBlueLight)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.OpenInBrowser,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp),
                                    tint = PrimaryBlueLight
                                )
                                Text(
                                    text = if (isSignUp) "SIGN UP WITH POCKET OPTION" else "SIGN IN TO POCKET OPTION",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 11.5.sp,
                                    letterSpacing = 0.5.sp,
                                    color = PrimaryBlueLight
                                )
                            }
                        }
                    }
                }

                // Security & Privacy Guarantee Note
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = TextMuted,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "Liberty opens official broker portals directly and never collects or stores passwords.",
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 9.sp,
                        color = TextMuted,
                        lineHeight = 13.sp
                    )
                }

                // Dismiss / Continue Demo Button
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth().testTag("continue_demo_button")
                ) {
                    Text(
                        text = "Continue Demo Trading",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

@Composable
private fun BrokerFeatureChip(text: String) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = SurfaceElevatedDark
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = null,
                tint = UpGreen,
                modifier = Modifier.size(10.dp)
            )
            Text(
                text = text,
                color = TextSecondary,
                fontSize = 9.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
