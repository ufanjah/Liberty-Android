package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.ScreenTab
import com.example.ui.TradingViewModel
import com.example.ui.theme.*

enum class TransactionFilter {
    ALL, DEPOSITS, WITHDRAWALS
}

@Composable
fun TransactionsScreen(
    viewModel: TradingViewModel,
    modifier: Modifier = Modifier
) {
    val allTransactions by viewModel.allTransactions.collectAsState()
    var currentFilter by remember { mutableStateOf(TransactionFilter.ALL) }
    var showClearDialog by remember { mutableStateOf(false) }

    val filteredTransactions = remember(allTransactions, currentFilter) {
        when (currentFilter) {
            TransactionFilter.ALL -> allTransactions
            TransactionFilter.DEPOSITS -> allTransactions.filter { it.type == "DEPOSIT" }
            TransactionFilter.WITHDRAWALS -> allTransactions.filter { it.type == "WITHDRAWAL" }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(horizontal = 16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(
                    onClick = { viewModel.selectTab(ScreenTab.WALLET) },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back to Wallet",
                        tint = TextPrimary
                    )
                }
                Column {
                    Text(
                        text = "Transaction History",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "Demo deposits & withdrawals",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }

            if (allTransactions.isNotEmpty()) {
                IconButton(
                    onClick = { showClearDialog = true },
                    modifier = Modifier.testTag("clear_transactions_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteSweep,
                        contentDescription = "Clear History",
                        tint = DownRed
                    )
                }
            }
        }

        // Filter Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TransactionFilter.entries.forEach { filter ->
                val isSelected = currentFilter == filter
                val count = when (filter) {
                    TransactionFilter.ALL -> allTransactions.size
                    TransactionFilter.DEPOSITS -> allTransactions.count { it.type == "DEPOSIT" }
                    TransactionFilter.WITHDRAWALS -> allTransactions.count { it.type == "WITHDRAWAL" }
                }
                val label = when (filter) {
                    TransactionFilter.ALL -> "All ($count)"
                    TransactionFilter.DEPOSITS -> "Deposits ($count)"
                    TransactionFilter.WITHDRAWALS -> "Withdrawals ($count)"
                }
                Surface(
                    onClick = { currentFilter = filter },
                    shape = RoundedCornerShape(20.dp),
                    color = if (isSelected) PrimaryBlue else SurfaceVariantDark,
                    modifier = Modifier.testTag("tx_filter_${filter.name}")
                ) {
                    Text(
                        text = label,
                        color = if (isSelected) TextPrimary else TextSecondary,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }
        }

        // List
        if (filteredTransactions.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ReceiptLong,
                        contentDescription = null,
                        tint = TextMuted,
                        modifier = Modifier.size(56.dp)
                    )
                    Text(
                        text = "No transactions found",
                        style = MaterialTheme.typography.bodyLarge,
                        color = TextSecondary,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "Demo deposits and withdrawal requests will be recorded here",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(filteredTransactions, key = { it.id }) { tx ->
                    TransactionCardItem(tx = tx)
                }
            }
        }
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            containerColor = SurfaceDark,
            title = { Text(text = "Clear Transactions", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = { Text("Are you sure you want to clear your simulated transaction log?", color = TextSecondary) },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearTransactions()
                        showClearDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DownRed)
                ) {
                    Text("Clear", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}
