package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.config.PepperstoneConfig
import com.example.ui.ScreenTab
import com.example.ui.TradingViewModel
import com.example.ui.components.ChooseBrokerDialog
import com.example.ui.components.LibertyLogo
import com.example.ui.components.NotificationsSheet
import com.example.ui.components.TradeResultDialog
import com.example.ui.screens.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: TradingViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                LibertyApp(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibertyApp(viewModel: TradingViewModel) {
    val currentTab by viewModel.currentTab.collectAsState()
    val activeTrades by viewModel.simulator.activeTrades.collectAsState()
    val currentResultEvent by viewModel.currentResultEvent.collectAsState()
    val snackbarMessage by viewModel.snackbarMessage.collectAsState()
    val unreadNotifications by viewModel.unreadNotificationCount.collectAsState()
    val notifications by viewModel.notifications.collectAsState()
    val userProfile by viewModel.userProfile.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current
    var showNotificationsSheet by remember { mutableStateOf(false) }
    var showChooseBrokerDialog by remember { mutableStateOf(false) }

    // Android Hardware/Gesture Back Handler
    BackHandler(enabled = currentTab != ScreenTab.DASHBOARD) {
        if (!viewModel.navigateBack()) {
            viewModel.selectTab(ScreenTab.DASHBOARD)
        }
    }

    LaunchedEffect(snackbarMessage) {
        val msg = snackbarMessage
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
            viewModel.dismissSnackbar()
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = SurfaceDark,
                drawerContentColor = TextPrimary,
                modifier = Modifier.width(300.dp)
            ) {
                // Drawer Header
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SurfaceVariantDark)
                        .padding(20.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        LibertyLogo(size = 40.dp)
                        Column {
                            Text(text = "LIBERTY", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, color = TextPrimary)
                            Text(text = "Demo Trading Hub", style = MaterialTheme.typography.labelSmall, color = GoldAccent, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = userProfile.fullName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text(text = userProfile.email, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }

                HorizontalDivider(color = CardBorder)

                // Navigation Items (Requirement 15: All 10 destinations)
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    DrawerNavRow(
                        title = "Dashboard",
                        icon = Icons.Default.Dashboard,
                        isSelected = currentTab == ScreenTab.DASHBOARD
                    ) {
                        viewModel.selectTab(ScreenTab.DASHBOARD)
                        coroutineScope.launch { drawerState.close() }
                    }

                    DrawerNavRow(
                        title = "Trade",
                        icon = Icons.Default.ShowChart,
                        isSelected = currentTab == ScreenTab.TRADE
                    ) {
                        viewModel.selectTab(ScreenTab.TRADE)
                        coroutineScope.launch { drawerState.close() }
                    }

                    DrawerNavRow(
                        title = "Open Trades",
                        icon = Icons.Default.HourglassBottom,
                        badge = if (activeTrades.isNotEmpty()) "${activeTrades.size}" else null,
                        isSelected = currentTab == ScreenTab.OPEN_TRADES
                    ) {
                        viewModel.selectTab(ScreenTab.OPEN_TRADES)
                        coroutineScope.launch { drawerState.close() }
                    }

                    DrawerNavRow(
                        title = "Trade History",
                        icon = Icons.Default.History,
                        isSelected = currentTab == ScreenTab.HISTORY
                    ) {
                        viewModel.selectTab(ScreenTab.HISTORY)
                        coroutineScope.launch { drawerState.close() }
                    }

                    DrawerNavRow(
                        title = "Demo Account Analytics",
                        icon = Icons.Default.Assessment,
                        isSelected = currentTab == ScreenTab.ACCOUNT
                    ) {
                        viewModel.selectTab(ScreenTab.ACCOUNT)
                        coroutineScope.launch { drawerState.close() }
                    }

                    DrawerNavRow(
                        title = "Trade with a Broker",
                        icon = Icons.Default.OpenInBrowser,
                        badge = "LIVE"
                    ) {
                        coroutineScope.launch { drawerState.close() }
                        showChooseBrokerDialog = true
                    }

                    DrawerNavRow(
                        title = "Open Pepperstone",
                        icon = Icons.Default.TrendingUp
                    ) {
                        coroutineScope.launch { drawerState.close() }
                        PepperstoneConfig.openPepperstone(context)
                    }

                    DrawerNavRow(
                        title = "Trader Profile",
                        icon = Icons.Default.Person,
                        isSelected = currentTab == ScreenTab.PROFILE
                    ) {
                        viewModel.selectTab(ScreenTab.PROFILE)
                        coroutineScope.launch { drawerState.close() }
                    }
                }
            }
        }
    ) {
        Scaffold(
            modifier = Modifier
                .fillMaxSize()
                .background(BackgroundDark),
            containerColor = BackgroundDark,
            contentWindowInsets = WindowInsets.systemBars,
            topBar = {
                if (currentTab != ScreenTab.TRADE) {
                    // Top App Bar for secondary screens
                    Surface(
                        color = SurfaceDark,
                        tonalElevation = 2.dp,
                        border = androidx.compose.foundation.BorderStroke(0.5.dp, CardBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                IconButton(
                                    onClick = { coroutineScope.launch { drawerState.open() } },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Menu,
                                        contentDescription = "Menu",
                                        tint = TextPrimary
                                    )
                                }
                                LibertyLogo(size = 24.dp)
                                Text(
                                    text = "LIBERTY",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.sp,
                                    color = TextPrimary
                                )
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = GoldGlow
                                ) {
                                    Text(
                                        text = "DEMO",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = GoldAccent,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 9.sp,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            // Right Actions: Notifications Bell & Profile Avatar
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                IconButton(
                                    onClick = { showNotificationsSheet = true },
                                    modifier = Modifier.size(36.dp).testTag("notifications_bell")
                                ) {
                                    BadgedBox(
                                        badge = {
                                            if (unreadNotifications > 0) {
                                                Badge(containerColor = GoldAccent) {
                                                    Text(text = "$unreadNotifications", color = BackgroundDark, fontWeight = FontWeight.Bold, fontSize = 9.sp)
                                                }
                                            }
                                        }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Notifications,
                                            contentDescription = "Notifications",
                                            tint = TextPrimary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }

                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .background(PrimaryBlue, CircleShape)
                                        .clickable { viewModel.selectTab(ScreenTab.PROFILE) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = userProfile.fullName.take(1).uppercase(),
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                }
                            }
                        }
                    }
                }
            },
            snackbarHost = {
                SnackbarHost(hostState = snackbarHostState) { data ->
                    Snackbar(
                        containerColor = SurfaceVariantDark,
                        contentColor = TextPrimary,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Text(text = data.visuals.message, fontWeight = FontWeight.SemiBold)
                    }
                }
            },
            bottomBar = {
                NavigationBar(
                    containerColor = SurfaceDark,
                    contentColor = TextPrimary,
                    tonalElevation = 4.dp,
                    windowInsets = WindowInsets.navigationBars,
                    modifier = Modifier.testTag("bottom_navigation_bar")
                ) {
                    // 1. TRADE (Terminal)
                    NavigationBarItem(
                        selected = currentTab == ScreenTab.TRADE,
                        onClick = { viewModel.selectTab(ScreenTab.TRADE) },
                        icon = {
                            Icon(
                                imageVector = if (currentTab == ScreenTab.TRADE) Icons.Filled.ShowChart else Icons.Outlined.ShowChart,
                                contentDescription = "Trade"
                            )
                        },
                        label = { Text("Trade", fontSize = 10.sp, fontWeight = if (currentTab == ScreenTab.TRADE) FontWeight.Bold else FontWeight.Normal) },
                        colors = navBarColors(),
                        modifier = Modifier.testTag("nav_tab_trade")
                    )

                    // 2. TRADES (Active Open Trades)
                    NavigationBarItem(
                        selected = currentTab == ScreenTab.OPEN_TRADES,
                        onClick = { viewModel.selectTab(ScreenTab.OPEN_TRADES) },
                        icon = {
                            BadgedBox(
                                badge = {
                                    if (activeTrades.isNotEmpty()) {
                                        Badge(containerColor = UpGreen) {
                                            Text(text = "${activeTrades.size}", color = BackgroundDark, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = if (currentTab == ScreenTab.OPEN_TRADES) Icons.Filled.Timelapse else Icons.Outlined.Timelapse,
                                    contentDescription = "Trades"
                                )
                            }
                        },
                        label = { Text("Trades", fontSize = 10.sp, fontWeight = if (currentTab == ScreenTab.OPEN_TRADES) FontWeight.Bold else FontWeight.Normal) },
                        colors = navBarColors(),
                        modifier = Modifier.testTag("nav_tab_open_trades")
                    )

                    // 3. HISTORY
                    NavigationBarItem(
                        selected = currentTab == ScreenTab.HISTORY,
                        onClick = { viewModel.selectTab(ScreenTab.HISTORY) },
                        icon = {
                            Icon(
                                imageVector = if (currentTab == ScreenTab.HISTORY) Icons.Filled.History else Icons.Outlined.History,
                                contentDescription = "History"
                            )
                        },
                        label = { Text("History", fontSize = 10.sp, fontWeight = if (currentTab == ScreenTab.HISTORY) FontWeight.Bold else FontWeight.Normal) },
                        colors = navBarColors(),
                        modifier = Modifier.testTag("nav_tab_history")
                    )

                    // 4. ACCOUNT (Demo account analytics, balance, win rate)
                    val isAccountSelected = currentTab == ScreenTab.ACCOUNT || currentTab == ScreenTab.WALLET || currentTab == ScreenTab.DEPOSIT || currentTab == ScreenTab.WITHDRAW || currentTab == ScreenTab.PROFILE || currentTab == ScreenTab.DASHBOARD
                    NavigationBarItem(
                        selected = isAccountSelected,
                        onClick = { viewModel.selectTab(ScreenTab.ACCOUNT) },
                        icon = {
                            Icon(
                                imageVector = if (isAccountSelected) Icons.Filled.AccountBalanceWallet else Icons.Outlined.AccountBalanceWallet,
                                contentDescription = "Account"
                            )
                        },
                        label = { Text("Account", fontSize = 10.sp, fontWeight = if (isAccountSelected) FontWeight.Bold else FontWeight.Normal) },
                        colors = navBarColors(),
                        modifier = Modifier.testTag("nav_tab_account")
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .consumeWindowInsets(innerPadding)
                    .imePadding()
            ) {
                when (currentTab) {
                    ScreenTab.DASHBOARD -> DashboardScreen(viewModel = viewModel)
                    ScreenTab.TRADE -> TradeScreen(
                        viewModel = viewModel,
                        onOpenDrawer = { coroutineScope.launch { drawerState.open() } }
                    )
                    ScreenTab.OPEN_TRADES -> OpenTradesScreen(viewModel = viewModel)
                    ScreenTab.HISTORY -> HistoryScreen(viewModel = viewModel)
                    ScreenTab.ACCOUNT -> AccountScreen(viewModel = viewModel)
                    ScreenTab.WALLET -> WalletScreen(viewModel = viewModel)
                    ScreenTab.DEPOSIT -> DepositScreen(viewModel = viewModel)
                    ScreenTab.WITHDRAW -> WithdrawalScreen(viewModel = viewModel)
                    ScreenTab.TRANSACTIONS -> TransactionsScreen(viewModel = viewModel)
                    ScreenTab.BANK_ACCOUNTS -> BankAccountsScreen(viewModel = viewModel)
                    ScreenTab.ADMIN_SETTINGS -> AdminSettingsScreen(viewModel = viewModel)
                    ScreenTab.PROFILE, ScreenTab.SECURITY -> ProfileScreen(viewModel = viewModel)
                }
            }
        }
    }

    // Trade Expiration Result Celebration Dialog
    currentResultEvent?.let { event ->
        TradeResultDialog(
            event = event,
            onDismiss = { viewModel.dismissResultDialog() }
        )
    }

    // In-app Notifications Sheet
    if (showNotificationsSheet) {
        NotificationsSheet(
            notifications = notifications,
            onMarkAllRead = { viewModel.markNotificationsRead() },
            onClearAll = { viewModel.clearNotifications() },
            onDismiss = { showNotificationsSheet = false }
        )
    }

    // Choose Your Broker Dialog (Sign-up / broker connection)
    if (showChooseBrokerDialog) {
        ChooseBrokerDialog(
            context = context,
            onDismiss = { showChooseBrokerDialog = false }
        )
    }
}

@Composable
private fun DrawerNavRow(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    badge: String? = null,
    isSelected: Boolean = false,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        color = if (isSelected) PrimaryBlue.copy(alpha = 0.2f) else Color.Transparent,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isSelected) PrimaryBlue else TextSecondary,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                    color = if (isSelected) PrimaryBlue else TextPrimary
                )
            }
            if (badge != null) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = UpGreenGlow
                ) {
                    Text(
                        text = badge,
                        color = UpGreen,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun navBarColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = PrimaryBlue,
    selectedTextColor = PrimaryBlue,
    unselectedIconColor = TextSecondary,
    unselectedTextColor = TextSecondary,
    indicatorColor = PrimaryBlue.copy(alpha = 0.15f)
)
