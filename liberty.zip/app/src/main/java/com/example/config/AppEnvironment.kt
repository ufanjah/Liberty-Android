package com.example.config

/**
 * Environment configuration for Liberty.
 *
 * Enforces production/development separation:
 * - DEVELOPMENT: Uses simulated DEMO DATA and local diagnostics.
 * - STAGING: Integration testing against sandbox endpoints.
 * - PRODUCTION: Verified live streams only, strictly separates demo simulator badges,
 *   ready for Google Play submission.
 */
enum class AppEnvironment {
    DEVELOPMENT,
    STAGING,
    PRODUCTION
}

object AppConfig {
    val CURRENT_ENVIRONMENT: AppEnvironment = AppEnvironment.PRODUCTION

    const val APP_VERSION_NAME: String = "1.0.0"
    const val APP_VERSION_CODE: Int = 1
    const val PLATFORM_NAME: String = "LIBERTY"
    const val PLATFORM_DESCRIPTION: String = "Live Market Analysis & Demo Trading Platform"

    // Google Play Disclosures & Legal Policy Links
    const val PRIVACY_POLICY_URL: String = "https://libertytrading.io/privacy"
    const val TERMS_OF_SERVICE_URL: String = "https://libertytrading.io/terms"
    const val RISK_DISCLOSURE_URL: String = "https://libertytrading.io/risk-disclosure"

    const val SUPPORT_EMAIL: String = "support@libertytrading.io"
}
