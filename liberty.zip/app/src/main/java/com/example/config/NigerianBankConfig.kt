package com.example.config

data class NigerianBank(
    val code: String,
    val name: String,
    val shortName: String,
    val category: BankCategory,
    val isEnabled: Boolean = true,
    val supportedProviders: List<String> = listOf("BANK_TRANSFER", "PAYSTACK", "FLUTTERWAVE")
)

enum class BankCategory(val label: String) {
    COMMERCIAL("Commercial Bank"),
    FINTECH_MFB("Digital / Microfinance"),
    PAYMENT_SERVICE_BANK("Payment Service Bank (PSB)"),
    NON_INTEREST("Non-Interest Bank"),
    MERCHANT("Merchant / Corporate")
}

object NigerianBankDirectory {
    val ALL_BANKS: List<NigerianBank> = listOf(
        NigerianBank("058", "Guaranty Trust Bank (GTBank)", "GTBank", BankCategory.COMMERCIAL),
        NigerianBank("044", "Access Bank", "Access", BankCategory.COMMERCIAL),
        NigerianBank("063", "Access Bank (Diamond)", "Diamond", BankCategory.COMMERCIAL),
        NigerianBank("057", "Zenith Bank", "Zenith", BankCategory.COMMERCIAL),
        NigerianBank("011", "First Bank of Nigeria", "FirstBank", BankCategory.COMMERCIAL),
        NigerianBank("033", "United Bank for Africa (UBA)", "UBA", BankCategory.COMMERCIAL),
        NigerianBank("070", "Fidelity Bank", "Fidelity", BankCategory.COMMERCIAL),
        NigerianBank("214", "First City Monument Bank (FCMB)", "FCMB", BankCategory.COMMERCIAL),
        NigerianBank("032", "Union Bank of Nigeria", "Union Bank", BankCategory.COMMERCIAL),
        NigerianBank("232", "Sterling Bank", "Sterling", BankCategory.COMMERCIAL),
        NigerianBank("221", "Stanbic IBTC Bank", "Stanbic", BankCategory.COMMERCIAL),
        NigerianBank("035", "Wema Bank", "Wema", BankCategory.COMMERCIAL),
        NigerianBank("076", "Polaris Bank", "Polaris", BankCategory.COMMERCIAL),
        NigerianBank("082", "Keystone Bank", "Keystone", BankCategory.COMMERCIAL),
        NigerianBank("050", "Ecobank Nigeria", "Ecobank", BankCategory.COMMERCIAL),
        NigerianBank("215", "Unity Bank", "Unity", BankCategory.COMMERCIAL),
        NigerianBank("103", "Globus Bank", "Globus", BankCategory.COMMERCIAL),
        NigerianBank("105", "PremiumTrust Bank", "PremiumTrust", BankCategory.COMMERCIAL),
        NigerianBank("102", "Titan Trust Bank", "Titan", BankCategory.COMMERCIAL),
        NigerianBank("101", "Providus Bank", "Providus", BankCategory.COMMERCIAL),
        NigerianBank("068", "Standard Chartered Bank", "Standard Chartered", BankCategory.COMMERCIAL),
        NigerianBank("023", "Citibank Nigeria", "Citibank", BankCategory.COMMERCIAL),

        // Digital & Microfinance Banks (OPay, PalmPay, Moniepoint, Kuda)
        NigerianBank("100004", "OPay (PayCom)", "OPay", BankCategory.FINTECH_MFB),
        NigerianBank("100033", "PalmPay", "PalmPay", BankCategory.FINTECH_MFB),
        NigerianBank("50515", "Moniepoint Microfinance Bank", "Moniepoint", BankCategory.FINTECH_MFB),
        NigerianBank("50211", "Kuda Microfinance Bank", "Kuda", BankCategory.FINTECH_MFB),
        NigerianBank("566", "VFD Microfinance Bank", "VFD", BankCategory.FINTECH_MFB),
        NigerianBank("565", "Carbon", "Carbon", BankCategory.FINTECH_MFB),
        NigerianBank("51318", "FairMoney Microfinance Bank", "FairMoney", BankCategory.FINTECH_MFB),

        // Payment Service Banks (PSB) - SmartCash, MoMo, etc.
        NigerianBank("120001", "SmartCash PSB (Airtel)", "SmartCash", BankCategory.PAYMENT_SERVICE_BANK),
        NigerianBank("120002", "MoMo PSB (MTN)", "MoMo", BankCategory.PAYMENT_SERVICE_BANK),

        // Non-Interest Banks
        NigerianBank("301", "Jaiz Bank", "Jaiz", BankCategory.NON_INTEREST),
        NigerianBank("302", "TAJBank", "TAJBank", BankCategory.NON_INTEREST),
        NigerianBank("303", "Lotus Bank", "Lotus", BankCategory.NON_INTEREST)
    )

    fun findByCode(code: String): NigerianBank? {
        return ALL_BANKS.find { it.code == code }
    }

    fun findByName(name: String): NigerianBank? {
        return ALL_BANKS.find { it.name.equals(name, ignoreCase = true) || it.shortName.equals(name, ignoreCase = true) }
    }
}
