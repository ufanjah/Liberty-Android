package com.example.config

data class AdminConfig(
    val isLivePaymentEnabled: Boolean = false, // Strictly disabled for demo
    val isBankTransferDepositEnabled: Boolean = true,
    val isPaystackDepositEnabled: Boolean = true,
    val isFlutterwaveDepositEnabled: Boolean = true,
    val isBankWithdrawalEnabled: Boolean = true,
    val isPaystackPayoutEnabled: Boolean = true,
    val isFlutterwavePayoutEnabled: Boolean = true,
    val minDepositUsd: Double = 10.0,
    val minWithdrawalUsd: Double = 10.0,
    val maxWithdrawalUsd: Double = 5000.0,
    val transactionFeePercent: Double = 0.0,
    val disabledBankCodes: Set<String> = emptySet()
)
