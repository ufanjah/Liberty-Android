package com.example.config

import android.content.Context
import android.content.Intent
import android.net.Uri

/**
 * Centralized Broker Configuration for Liberty.
 *
 * Keeps all broker registration, partner referral, and login portal URLs in one clean location.
 *
 * Requirements:
 * - PEPPERSTONE partner referral URL must match exact tracking link with all parameters intact:
 *   https://trk.pepperstonepartners.com/aff_c?aff_id=50511&offer_id=367&referral_provider=tune_link&url_id=945
 * - POCKET OPTION partner/registration and sign-in URLs are configurable in one place.
 * - Liberty never stores or requests broker credentials or passwords.
 */
object BrokerConfig {

    // --- Official Partner & Registration URLs ---
    const val PEPPERSTONE_SIGNUP_URL: String =
        "https://trk.pepperstonepartners.com/aff_c?aff_id=50511&offer_id=367&referral_provider=tune_link&url_id=945"

    const val POCKET_OPTION_SIGNUP_URL: String =
        "https://u3.shortink.io/register?utm_campaign=867682&utm_source=affiliate&utm_medium=sr&a=Vgf34QaJ3Wo9mD&al=1799399&ac=liberty&cid=982587"

    // --- Official Broker Login Portals ---
    const val PEPPERSTONE_LOGIN_URL: String =
        "https://secure.pepperstone.com/login"

    const val POCKET_OPTION_LOGIN_URL: String =
        "https://pocketoption.com/en/login/"

    fun openUrl(context: Context, url: String, fallbackMsg: String = "Link not configured."): Boolean {
        if (url.isBlank()) {
            android.widget.Toast.makeText(context, fallbackMsg, android.widget.Toast.LENGTH_SHORT).show()
            return false
        }
        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            android.widget.Toast.makeText(context, "Unable to open link", android.widget.Toast.LENGTH_SHORT).show()
            false
        }
    }

    fun openPepperstoneSignUp(context: Context): Boolean {
        return openUrl(context, PEPPERSTONE_SIGNUP_URL, "Official registration link not configured.")
    }

    fun openPepperstoneSignIn(context: Context): Boolean {
        return openUrl(context, PEPPERSTONE_LOGIN_URL, "Official login link not configured.")
    }

    fun openPocketOptionSignUp(context: Context): Boolean {
        return openUrl(context, POCKET_OPTION_SIGNUP_URL, "Official registration link not configured.")
    }

    fun openPocketOptionSignIn(context: Context): Boolean {
        return openUrl(context, POCKET_OPTION_LOGIN_URL, "Official login link not configured.")
    }
}
