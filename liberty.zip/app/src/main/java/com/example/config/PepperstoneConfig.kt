package com.example.config

import android.content.Context
import android.content.Intent
import android.net.Uri

object PepperstoneConfig {
    /**
     * Official Pepperstone partner referral tracking link.
     * DO NOT MODIFY THIS URL.
     */
    const val PEPPERSTONE_PARTNER_URL: String =
        "https://trk.pepperstonepartners.com/aff_c?aff_id=50511&offer_id=367&referral_provider=tune_link&url_id=945"

    fun openPepperstone(context: Context) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(PEPPERSTONE_PARTNER_URL)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {}
    }
}
