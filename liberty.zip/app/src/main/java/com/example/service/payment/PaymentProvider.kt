package com.example.service.payment

import com.example.config.NigerianBank
import com.example.config.NigerianBankDirectory
import java.util.UUID
import kotlin.random.Random

/**
 * Clean Service Abstraction for Payment Providers (Paystack, Flutterwave, Direct Transfer).
 *
 * Designed to connect to a Secure Backend Proxy in production so that:
 * 1. Secret keys remain strictly on the backend.
 * 2. New providers can be added without modifying the Liberty UI.
 * 3. In DEMO mode, MockPaymentProvider simulates account resolution, deposits, and payouts.
 */

data class AccountResolutionResult(
    val bankCode: String,
    val bankName: String,
    val accountNumber: String,
    val accountName: String,
    val isDemoVerification: Boolean = true,
    val message: String = "Demo Account Verification"
)

data class DepositRequest(
    val amount: Double,
    val currency: String = "USD",
    val paymentMethod: String,
    val customerEmail: String,
    val customerName: String,
    val idempotencyKey: String = UUID.randomUUID().toString()
)

data class DepositResponse(
    val transactionId: String,
    val reference: String,
    val amount: Double,
    val currency: String,
    val method: String,
    val status: String, // "DEMO / COMPLETED", "DEMO / PENDING"
    val isDemo: Boolean = true,
    val message: String
)

data class WithdrawalRequest(
    val amount: Double,
    val currency: String = "USD",
    val bankCode: String,
    val bankName: String,
    val accountNumber: String,
    val accountName: String,
    val paymentMethod: String,
    val customerEmail: String,
    val idempotencyKey: String = UUID.randomUUID().toString()
)

data class WithdrawalResponse(
    val withdrawalId: String,
    val reference: String,
    val amount: Double,
    val currency: String,
    val bankName: String,
    val maskedAccountNumber: String,
    val status: String, // "DEMO / PENDING"
    val isDemo: Boolean = true,
    val message: String
)

data class PaymentVerificationResult(
    val reference: String,
    val status: String,
    val amount: Double,
    val isSuccess: Boolean
)

interface PaymentProvider {
    val providerId: String
    val providerName: String
    val isLiveSupported: Boolean

    suspend fun getBanks(): List<NigerianBank>
    suspend fun resolveAccount(bankCode: String, accountNumber: String): Result<AccountResolutionResult>
    suspend fun initializeDeposit(request: DepositRequest): Result<DepositResponse>
    suspend fun verifyDeposit(reference: String): Result<PaymentVerificationResult>
    suspend fun initializeWithdrawal(request: WithdrawalRequest): Result<WithdrawalResponse>
    suspend fun verifyWithdrawal(reference: String): Result<PaymentVerificationResult>
}

/**
 * Mock Implementation for DEMO Mode.
 * Simulates real Nigerian payment workflows safely without real funds or secrets.
 */
class MockPaymentProvider : PaymentProvider {
    override val providerId: String = "MOCK_DEMO"
    override val providerName: String = "Liberty Demo Gateway"
    override val isLiveSupported: Boolean = false

    override suspend fun getBanks(): List<NigerianBank> {
        return NigerianBankDirectory.ALL_BANKS
    }

    override suspend fun resolveAccount(bankCode: String, accountNumber: String): Result<AccountResolutionResult> {
        kotlinx.coroutines.delay(600) // realistic network simulation
        if (accountNumber.length != 10 || !accountNumber.all { it.isDigit() }) {
            return Result.failure(IllegalArgumentException("Account number must be exactly 10 digits"))
        }

        val bank = NigerianBankDirectory.findByCode(bankCode)
            ?: return Result.failure(IllegalArgumentException("Unknown bank code: $bankCode"))

        // Realistic simulated Nigerian account names based on digits for testing
        val simulatedNames = listOf(
            "Alexander Morgan Adeyemi",
            "Chinedu Emmanuel Okonkwo",
            "Fatima Ibrahim Danjuma",
            "Babatunde David Adeleke",
            "Ngozi Stephanie Eze",
            "Oluwaseun Peter Balogun"
        )
        val nameIndex = (accountNumber.takeLast(2).toIntOrNull() ?: 0) % simulatedNames.size
        val resolvedName = simulatedNames[nameIndex]

        return Result.success(
            AccountResolutionResult(
                bankCode = bank.code,
                bankName = bank.name,
                accountNumber = accountNumber,
                accountName = resolvedName,
                isDemoVerification = true,
                message = "Demo Account Verification: Name matched simulated NIBSS/NUBAN record."
            )
        )
    }

    override suspend fun initializeDeposit(request: DepositRequest): Result<DepositResponse> {
        kotlinx.coroutines.delay(400)
        val ref = "LIB-DEP-${Random.nextInt(100000, 999999)}"
        return Result.success(
            DepositResponse(
                transactionId = "TXN-${UUID.randomUUID().toString().take(8)}",
                reference = ref,
                amount = request.amount,
                currency = request.currency,
                method = request.paymentMethod,
                status = "DEMO / COMPLETED",
                isDemo = true,
                message = "Simulated ${request.paymentMethod} deposit credited to demo wallet."
            )
        )
    }

    override suspend fun verifyDeposit(reference: String): Result<PaymentVerificationResult> {
        return Result.success(
            PaymentVerificationResult(reference = reference, status = "DEMO / COMPLETED", amount = 0.0, isSuccess = true)
        )
    }

    override suspend fun initializeWithdrawal(request: WithdrawalRequest): Result<WithdrawalResponse> {
        kotlinx.coroutines.delay(400)
        val ref = "LIB-WTH-${Random.nextInt(100000, 999999)}"
        val masked = if (request.accountNumber.length >= 4) {
            "******" + request.accountNumber.takeLast(4)
        } else {
            "******"
        }
        return Result.success(
            WithdrawalResponse(
                withdrawalId = "WTH-${UUID.randomUUID().toString().take(8)}",
                reference = ref,
                amount = request.amount,
                currency = request.currency,
                bankName = request.bankName,
                maskedAccountNumber = masked,
                status = "DEMO / PENDING",
                isDemo = true,
                message = "Simulated withdrawal queued for demo payout."
            )
        )
    }

    override suspend fun verifyWithdrawal(reference: String): Result<PaymentVerificationResult> {
        return Result.success(
            PaymentVerificationResult(reference = reference, status = "DEMO / PENDING", amount = 0.0, isSuccess = true)
        )
    }
}

/**
 * Paystack Provider Skeleton:
 * In live mode, requests will be routed to your backend (e.g. https://api.libertytrading.com/payments/paystack/...)
 * which holds the PAYSTACK_SECRET_KEY server-side.
 */
class PaystackPaymentProvider(private val backendBaseUrl: String = "https://api.libertyhub.example/api/v1") : PaymentProvider {
    override val providerId: String = "PAYSTACK"
    override val providerName: String = "Paystack Gateway"
    override val isLiveSupported: Boolean = true

    override suspend fun getBanks(): List<NigerianBank> = NigerianBankDirectory.ALL_BANKS

    override suspend fun resolveAccount(bankCode: String, accountNumber: String): Result<AccountResolutionResult> {
        // Backend proxy call placeholder (No frontend secret key!)
        return MockPaymentProvider().resolveAccount(bankCode, accountNumber)
    }

    override suspend fun initializeDeposit(request: DepositRequest): Result<DepositResponse> {
        return MockPaymentProvider().initializeDeposit(request)
    }

    override suspend fun verifyDeposit(reference: String): Result<PaymentVerificationResult> {
        return MockPaymentProvider().verifyDeposit(reference)
    }

    override suspend fun initializeWithdrawal(request: WithdrawalRequest): Result<WithdrawalResponse> {
        return MockPaymentProvider().initializeWithdrawal(request)
    }

    override suspend fun verifyWithdrawal(reference: String): Result<PaymentVerificationResult> {
        return MockPaymentProvider().verifyWithdrawal(reference)
    }
}

/**
 * Flutterwave Provider Skeleton:
 * In live mode, requests are routed to backend proxy with FLUTTERWAVE_SECRET_KEY server-side.
 */
class FlutterwavePaymentProvider(private val backendBaseUrl: String = "https://api.libertyhub.example/api/v1") : PaymentProvider {
    override val providerId: String = "FLUTTERWAVE"
    override val providerName: String = "Flutterwave Gateway"
    override val isLiveSupported: Boolean = true

    override suspend fun getBanks(): List<NigerianBank> = NigerianBankDirectory.ALL_BANKS

    override suspend fun resolveAccount(bankCode: String, accountNumber: String): Result<AccountResolutionResult> {
        return MockPaymentProvider().resolveAccount(bankCode, accountNumber)
    }

    override suspend fun initializeDeposit(request: DepositRequest): Result<DepositResponse> {
        return MockPaymentProvider().initializeDeposit(request)
    }

    override suspend fun verifyDeposit(reference: String): Result<PaymentVerificationResult> {
        return MockPaymentProvider().verifyDeposit(reference)
    }

    override suspend fun initializeWithdrawal(request: WithdrawalRequest): Result<WithdrawalResponse> {
        return MockPaymentProvider().initializeWithdrawal(request)
    }

    override suspend fun verifyWithdrawal(reference: String): Result<PaymentVerificationResult> {
        return MockPaymentProvider().verifyWithdrawal(reference)
    }
}
