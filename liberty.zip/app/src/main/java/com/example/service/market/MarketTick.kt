package com.example.service.market

/**
 * Standard real-time market tick received from market data feeds.
 */
data class MarketTick(
    val symbol: String,
    val bid: Double,
    val ask: Double,
    val mid: Double,
    val timestamp: Long,
    val tickVolume: Long = 1L
) {
    val spread: Double
        get() = ask - bid
}

/**
 * Connection states for live and demo streams (Google Play Transparent Disclosures).
 *
 * Rules:
 * - LIVE: ONLY shown when a genuine external live WebSocket/REST stream is verified connected.
 * - DEMO_DATA: Shown whenever simulated/generated ticks are in use.
 * - CONNECTING / RECONNECTING / LIVE_DATA_UNAVAILABLE / DATA_CONNECTION_LOST for network statuses.
 */
enum class DataConnectionState(val label: String, val isGenuineLive: Boolean) {
    LIVE("LIVE", true),
    CONNECTING("CONNECTING", false),
    RECONNECTING("RECONNECTING", false),
    LIVE_DATA_UNAVAILABLE("LIVE DATA UNAVAILABLE", false),
    DATA_CONNECTION_LOST("DATA CONNECTION LOST", false),
    DEMO_DATA("DEMO DATA", false)
}
