package com.example.service.market

import com.example.data.TradingAsset
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.concurrent.ConcurrentHashMap
import kotlin.random.Random

/**
 * Provider abstraction for Liberty Market Data.
 * Cleanly separates Simulated DEMO DATA from authenticated LIVE streams.
 */
interface MarketDataProvider {
    val providerName: String
    val isLiveConnection: Boolean
    val connectionStatus: StateFlow<DataConnectionState>
    val lastUpdateTimestamp: StateFlow<Long>
    val activeSymbols: StateFlow<List<DerivActiveSymbol>>

    fun start()
    fun stop()
    fun reconnect()
    fun selectSymbol(symbol: String)
    fun getLatestTick(symbol: String): MarketTick?
    fun observeTicks(): SharedFlow<MarketTick>
}

/**
 * Development & Practice Provider.
 * Generates realistic micro-volatility ticks for all supported assets.
 * Clearly marks state as DEMO_DATA (never claiming to be LIVE).
 */
class MockMarketDataProvider(
    private val scope: CoroutineScope,
    private val candleBuilder: CandleBuilder
) : MarketDataProvider {

    override val providerName: String = "Liberty Simulation Engine"
    override val isLiveConnection: Boolean = false

    private val _connectionStatus = MutableStateFlow(DataConnectionState.DEMO_DATA)
    override val connectionStatus: StateFlow<DataConnectionState> = _connectionStatus.asStateFlow()

    private val _lastUpdateTimestamp = MutableStateFlow(System.currentTimeMillis())
    override val lastUpdateTimestamp: StateFlow<Long> = _lastUpdateTimestamp.asStateFlow()

    private val _activeSymbols = MutableStateFlow<List<DerivActiveSymbol>>(emptyList())
    override val activeSymbols: StateFlow<List<DerivActiveSymbol>> = _activeSymbols.asStateFlow()

    private val _tickFlow = MutableSharedFlow<MarketTick>(extraBufferCapacity = 64)
    private val latestTicks = ConcurrentHashMap<String, MarketTick>()

    private var streamingJob: Job? = null
    private var selectedSymbol: String = "EUR/USD"

    override fun start() {
        if (streamingJob?.isActive == true) return
        _connectionStatus.value = DataConnectionState.DEMO_DATA
        streamingJob = scope.launch(Dispatchers.Default) {
            while (isActive) {
                val now = System.currentTimeMillis()
                for (asset in MarketDataDefaults.SUPPORTED_ASSETS) {
                    val currentMid = latestTicks[asset.symbol]?.mid ?: asset.basePrice
                    val pip = Math.pow(10.0, -asset.decimals.toDouble())
                    val delta = (Random.nextDouble(-1.8, 1.8) * asset.volatility)
                    val newMid = (currentMid + delta).coerceAtLeast(pip)
                    val spreadPips = when (asset.decimals) {
                        5 -> 0.00015
                        4 -> 0.0002
                        3 -> 0.015
                        2 -> 0.25
                        else -> pip * 2
                    }
                    val halfSpread = spreadPips / 2.0
                    val bid = newMid - halfSpread
                    val ask = newMid + halfSpread
                    val tick = MarketTick(
                        symbol = asset.symbol,
                        bid = bid,
                        ask = ask,
                        mid = newMid,
                        timestamp = now,
                        tickVolume = Random.nextLong(1, 4)
                    )
                    latestTicks[asset.symbol] = tick
                    _tickFlow.tryEmit(tick)
                    candleBuilder.processTick(tick)
                }
                _lastUpdateTimestamp.value = now
                delay(400) // Lively 2.5 ticks/sec
            }
        }
    }

    override fun selectSymbol(symbol: String) {
        selectedSymbol = symbol
    }

    override fun stop() {
        streamingJob?.cancel()
        streamingJob = null
    }

    override fun reconnect() {
        _connectionStatus.value = DataConnectionState.CONNECTING
        scope.launch {
            delay(500)
            _connectionStatus.value = DataConnectionState.DEMO_DATA
            start()
        }
    }

    override fun getLatestTick(symbol: String): MarketTick? = latestTicks[symbol]
    override fun observeTicks(): SharedFlow<MarketTick> = _tickFlow
}
