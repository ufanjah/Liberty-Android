package com.example.service.market

import com.example.data.Candle
import com.example.data.Timeframe
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.max
import kotlin.math.min

/**
 * Builds real OHLC candles from the continuous stream of market ticks.
 *
 * Supports timeframes:
 * 5s, 15s, 30s, 1m, 3m, 5m, 15m, 30m, 1h, 4h, 1d.
 *
 * Maintains continuous price history by setting the new candle's open to the previous candle's close,
 * updating high/low/close per tick, and accumulating tick volume.
 */
class CandleBuilder(
    val maxCandlesToRetain: Int = 200
) {
    // Mapping: symbol -> (timeframe -> list of candles)
    private val candleSeries = ConcurrentHashMap<String, ConcurrentHashMap<Timeframe, MutableList<Candle>>>()

    /**
     * Ingests a new market tick and updates or rolls over candles for all timeframes for that symbol.
     * Returns true if a candle was rolled or updated.
     */
    @Synchronized
    fun processTick(tick: MarketTick, timeframes: List<Timeframe> = Timeframe.entries): Map<Timeframe, List<Candle>> {
        val symbolTfMap = candleSeries.getOrPut(tick.symbol) { ConcurrentHashMap() }
        val updated = mutableMapOf<Timeframe, List<Candle>>()

        for (tf in timeframes) {
            val intervalMs = tf.seconds * 1000L
            val bucketTimestamp = (tick.timestamp / intervalMs) * intervalMs
            val list = symbolTfMap.getOrPut(tf) { mutableListOf() }

            if (list.isEmpty()) {
                // Initialize first candle
                list.add(
                    Candle(
                        timestamp = bucketTimestamp,
                        open = tick.mid,
                        high = tick.mid,
                        low = tick.mid,
                        close = tick.mid,
                        tickVolume = tick.tickVolume
                    )
                )
            } else {
                val lastCandle = list.last()
                if (bucketTimestamp == lastCandle.timestamp) {
                    // Update current in-progress candle
                    list[list.lastIndex] = lastCandle.copy(
                        high = max(lastCandle.high, tick.mid),
                        low = min(lastCandle.low, tick.mid),
                        close = tick.mid,
                        tickVolume = lastCandle.tickVolume + tick.tickVolume
                    )
                } else if (bucketTimestamp > lastCandle.timestamp) {
                    // Rollover to new candle
                    val newCandle = Candle(
                        timestamp = bucketTimestamp,
                        open = lastCandle.close, // continuous price action
                        high = max(lastCandle.close, tick.mid),
                        low = min(lastCandle.close, tick.mid),
                        close = tick.mid,
                        tickVolume = tick.tickVolume
                    )
                    list.add(newCandle)
                    // Trim old candles
                    while (list.size > maxCandlesToRetain) {
                        list.removeAt(0)
                    }
                }
            }
            updated[tf] = ArrayList(list)
        }
        return updated
    }

    @Synchronized
    fun getCandles(symbol: String, timeframe: Timeframe): List<Candle> {
        val list = candleSeries[symbol]?.get(timeframe) ?: emptyList()
        return ArrayList(list)
    }

    @Synchronized
    fun setSeedCandles(symbol: String, timeframe: Timeframe, candles: List<Candle>) {
        val symbolTfMap = candleSeries.getOrPut(symbol) { ConcurrentHashMap() }
        symbolTfMap[timeframe] = ArrayList(candles)
    }
}
