package com.example.service

import com.example.data.*
import kotlinx.coroutines.flow.Flow

/**
 * Service Layer Interfaces for LIBERTY Trading Hub
 *
 * Designed for clean abstraction so future integrations (such as approved cTrader /
 * Pepperstone Open API) can be plugged in without modifying the UI layer.
 *
 * NOTE: All authentication secrets, client IDs, and tokens remain strictly server-side
 * and are never exposed to client-side code.
 */

interface MarketDataService {
    fun getSupportedAssets(): List<TradingAsset>
    fun getCurrentPrice(symbol: String): Flow<Double>
    fun getCandles(symbol: String, timeframe: Timeframe): Flow<List<Candle>>
    fun selectAsset(asset: TradingAsset)
    fun selectTimeframe(timeframe: Timeframe)
}

interface OrderService {
    val activeTrades: Flow<List<ActiveTrade>>
    val tradeEvents: Flow<TradeResultEvent>
    suspend fun placeTrade(direction: String, amount: Double, durationSeconds: Int): Boolean
}

interface AccountService {
    val account: Flow<UserAccountEntity>
    val transactions: Flow<List<TransactionEntity>>
    suspend fun depositDemo(amount: Double, paymentMethod: String): TransactionEntity
    suspend fun withdrawDemo(amount: Double, bankName: String, accountName: String, accountNumber: String): TransactionEntity
    suspend fun resetDemoBalance()
    suspend fun topUpDemoBalance(amount: Double)
}

interface TradeHistoryService {
    val allTrades: Flow<List<TradeEntity>>
    suspend fun clearHistory()
}
