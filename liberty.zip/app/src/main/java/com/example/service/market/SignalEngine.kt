package com.example.service.market

import com.example.data.Candle

enum class SignalState(val label: String) {
    BUY("BUY / CALL"),
    SELL("SELL / PUT"),
    WAIT("WAIT / NEUTRAL")
}

data class SignalSettings(
    val useTrendEma: Boolean = true,
    val useRsi: Boolean = true,
    val useMacd: Boolean = true,
    val useSupertrend: Boolean = true,
    val minConfirmationsRequired: Int = 3
)

data class SignalEvaluation(
    val state: SignalState,
    val confirmations: Int,
    val totalConditionsChecked: Int,
    val trendStatus: String,
    val momentumStatus: String,
    val details: List<String>,
    val disclaimer: String = "Simulated technical analysis indicators. Not financial advice or guaranteed trading outcomes."
)

object SignalEngine {

    fun evaluate(
        candles: List<Candle>,
        indicators: CalculatedIndicators,
        settings: SignalSettings = SignalSettings()
    ): SignalEvaluation {
        if (candles.size < 20) {
            return SignalEvaluation(
                state = SignalState.WAIT,
                confirmations = 0,
                totalConditionsChecked = 4,
                trendStatus = "Accumulating Data",
                momentumStatus = "Neutral",
                details = listOf("Minimum 20 candles needed to evaluate technical confirmations.")
            )
        }

        var buyVotes = 0
        var sellVotes = 0
        var totalActiveChecks = 0
        val details = mutableListOf<String>()

        val lastClose = candles.last().close

        // 1. Trend EMA confirmation (e.g. Price vs SMA/EMA)
        var trendSummary = "Neutral"
        if (settings.useTrendEma) {
            totalActiveChecks++
            val ema = indicators.emaValues.lastOrNull() ?: indicators.smaValues.lastOrNull()
            if (ema != null) {
                if (lastClose > ema) {
                    buyVotes++
                    trendSummary = "Bullish"
                    details.add("Trend: Price ($lastClose) above EMA ($ema) -> BUY")
                } else if (lastClose < ema) {
                    sellVotes++
                    trendSummary = "Bearish"
                    details.add("Trend: Price ($lastClose) below EMA ($ema) -> SELL")
                } else {
                    details.add("Trend: Price exactly at EMA -> NEUTRAL")
                }
            }
        }

        // 2. RSI momentum confirmation (RSI > 50 Bullish, RSI < 50 Bearish)
        var momentumSummary = "Neutral"
        if (settings.useRsi) {
            totalActiveChecks++
            val rsi = indicators.rsiLatest
            if (rsi != null) {
                if (rsi in 52.0..68.0) {
                    buyVotes++
                    momentumSummary = "Positive"
                    details.add("RSI (${String.format("%.1f", rsi)}): Positive momentum -> BUY")
                } else if (rsi in 32.0..48.0) {
                    sellVotes++
                    momentumSummary = "Negative"
                    details.add("RSI (${String.format("%.1f", rsi)}): Negative momentum -> SELL")
                } else if (rsi > 70.0) {
                    sellVotes++ // Overbought potential reversal
                    momentumSummary = "Overbought"
                    details.add("RSI (${String.format("%.1f", rsi)}): Overbought zone -> Potential pullback SELL")
                } else if (rsi < 30.0) {
                    buyVotes++ // Oversold potential reversal
                    momentumSummary = "Oversold"
                    details.add("RSI (${String.format("%.1f", rsi)}): Oversold zone -> Potential bounce BUY")
                } else {
                    details.add("RSI (${String.format("%.1f", rsi)}): Midpoint neutral")
                }
            }
        }

        // 3. MACD confirmation (Histogram > 0 Bullish, < 0 Bearish)
        if (settings.useMacd) {
            totalActiveChecks++
            val macd = indicators.macdLatest
            if (macd != null) {
                if (macd.histogram > 0) {
                    buyVotes++
                    details.add("MACD: Positive histogram (${String.format("%.5f", macd.histogram)}) -> BUY")
                } else if (macd.histogram < 0) {
                    sellVotes++
                    details.add("MACD: Negative histogram (${String.format("%.5f", macd.histogram)}) -> SELL")
                } else {
                    details.add("MACD: Zero line cross neutral")
                }
            }
        }

        // 4. Supertrend confirmation
        if (settings.useSupertrend) {
            totalActiveChecks++
            val isBullish = indicators.supertrendIsBullish.lastOrNull()
            if (isBullish == true) {
                buyVotes++
                details.add("Supertrend: Green Bullish support -> BUY")
            } else if (isBullish == false) {
                sellVotes++
                details.add("Supertrend: Red Bearish resistance -> SELL")
            }
        }

        val minNeeded = settings.minConfirmationsRequired.coerceAtMost(totalActiveChecks)

        val finalState = when {
            buyVotes >= minNeeded && buyVotes > sellVotes -> SignalState.BUY
            sellVotes >= minNeeded && sellVotes > buyVotes -> SignalState.SELL
            else -> SignalState.WAIT
        }

        val confirmations = if (finalState == SignalState.BUY) buyVotes else if (finalState == SignalState.SELL) sellVotes else maxOf(buyVotes, sellVotes)

        return SignalEvaluation(
            state = finalState,
            confirmations = confirmations,
            totalConditionsChecked = totalActiveChecks,
            trendStatus = trendSummary,
            momentumStatus = momentumSummary,
            details = details
        )
    }
}
