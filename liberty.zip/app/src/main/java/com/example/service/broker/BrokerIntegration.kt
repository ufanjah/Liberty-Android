package com.example.service.broker

import com.example.data.TradingAsset
import com.example.service.market.MarketDataDefaults
import com.example.service.market.MarketTick
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Clean Broker Integration Interface for Liberty Trading Terminal.
 *
 * Prepared for future real liquidity / broker API adapters (e.g. Pepperstone, Pocket Option, FIX protocol),
 * while keeping all client order executions 100% DEMO ONLY as required.
 */
interface BrokerIntegration {
    val brokerName: String
    val isDemoMode: Boolean

    suspend fun connect(): Result<Boolean>
    suspend fun disconnect(): Result<Boolean>
    suspend fun getAccount(): Result<TradingAccountInfo>
    suspend fun getBalance(): Result<Double>
    suspend fun getSymbols(): Result<List<TradingAsset>>
    fun getMarketData(symbol: String): Flow<MarketTick>

    /**
     * Executes order.
     * CRITICAL: Strictly demo simulation only. Never sends real financial orders.
     */
    suspend fun placeOrder(
        symbol: String,
        direction: String,
        amount: Double,
        durationSeconds: Int
    ): Result<String>

    fun getOrderStatus(orderId: String): Flow<String>
}

/**
 * Standard Liberty Demo Broker Adapter.
 */
class LibertyDemoBrokerAdapter(
    override val brokerName: String = "Liberty Simulated Execution Gateway"
) : BrokerIntegration {

    override val isDemoMode: Boolean = true
    private val connectionState = MutableStateFlow("CONNECTED_DEMO")

    override suspend fun connect(): Result<Boolean> {
        connectionState.value = "CONNECTED_DEMO"
        return Result.success(true)
    }

    override suspend fun disconnect(): Result<Boolean> {
        connectionState.value = "DISCONNECTED"
        return Result.success(true)
    }

    override suspend fun getAccount(): Result<TradingAccountInfo> {
        return Result.success(
            TradingAccountInfo(
                accountId = "LIB-SIM-09941",
                accountName = "LIBERTY DEMO ACCOUNT",
                accountStatus = "ACTIVE_SIMULATED",
                accountType = "DEMO",
                tradingStatus = "SIMULATED",
                currency = "USD",
                leverage = "1:100"
            )
        )
    }

    override suspend fun getBalance(): Result<Double> = Result.success(10000.00)

    override suspend fun getSymbols(): Result<List<TradingAsset>> {
        return Result.success(MarketDataDefaults.SUPPORTED_ASSETS)
    }

    override fun getMarketData(symbol: String): Flow<MarketTick> {
        val now = System.currentTimeMillis()
        val asset = MarketDataDefaults.SUPPORTED_ASSETS.firstOrNull { it.symbol == symbol }
            ?: MarketDataDefaults.SUPPORTED_ASSETS.first()
        return MutableStateFlow(
            MarketTick(symbol, asset.basePrice - 0.0001, asset.basePrice + 0.0001, asset.basePrice, now)
        )
    }

    override suspend fun placeOrder(
        symbol: String,
        direction: String,
        amount: Double,
        durationSeconds: Int
    ): Result<String> {
        // Explicitly simulated
        val demoOrderId = "DEMO-ORD-${System.currentTimeMillis()}"
        return Result.success(demoOrderId)
    }

    override fun getOrderStatus(orderId: String): Flow<String> {
        return MutableStateFlow("ACTIVE_SIMULATED")
    }
}
