package com.example.service.market

import androidx.compose.ui.graphics.Color
import com.example.data.Candle
import kotlin.math.*

enum class IndicatorCategory(val label: String) {
    TREND("Trend"),
    MOMENTUM("Momentum / Oscillators"),
    VOLATILITY("Volatility"),
    VOLUME("Volume / Flow"),
    PRICE_ACTION("Price Action / Structure")
}

data class IndicatorDefinition(
    val id: String,
    val name: String,
    val category: IndicatorCategory,
    val description: String,
    val defaultParameters: Map<String, Double>,
    val defaultColorHex: Long = 0xFF3872FF
)

data class IndicatorInstance(
    val id: String,
    val definitionId: String,
    val name: String,
    val category: IndicatorCategory,
    val parameters: Map<String, Double>,
    val isVisible: Boolean = true,
    val color: Color = Color(0xFF3872FF)
)

data class CalculatedIndicators(
    val smaValues: List<Double?> = emptyList(),
    val emaValues: List<Double?> = emptyList(),
    val bollingerUpper: List<Double?> = emptyList(),
    val bollingerMiddle: List<Double?> = emptyList(),
    val bollingerLower: List<Double?> = emptyList(),
    val supertrendValues: List<Double?> = emptyList(),
    val supertrendIsBullish: List<Boolean> = emptyList(),
    val sarValues: List<Double?> = emptyList(),
    val bullishFractals: List<Int> = emptyList(), // candle indices
    val bearishFractals: List<Int> = emptyList(), // candle indices
    val rsiLatest: Double? = null,
    val macdLatest: MacdResult? = null,
    val stochasticLatest: StochResult? = null,
    val adxLatest: Double? = null,
    val fibonacciLevels: List<Double> = emptyList(),
    val pivotLevels: PivotLevels? = null
)

data class MacdResult(
    val macdLine: Double,
    val signalLine: Double,
    val histogram: Double
)

data class StochResult(
    val k: Double,
    val d: Double
)

data class PivotLevels(
    val pp: Double,
    val r1: Double,
    val s1: Double,
    val r2: Double,
    val s2: Double
)

object IndicatorEngine {

    val CATALOG: List<IndicatorDefinition> = listOf(
        // TREND
        IndicatorDefinition("SMA", "SMA (Simple Moving Average)", IndicatorCategory.TREND, "Smooths price action over N periods", mapOf("length" to 10.0), 0xFFFFB300),
        IndicatorDefinition("EMA", "EMA (Exponential Moving Average)", IndicatorCategory.TREND, "Gives higher weight to recent prices", mapOf("length" to 20.0), 0xFF3872FF),
        IndicatorDefinition("WMA", "WMA (Weighted Moving Average)", IndicatorCategory.TREND, "Linear weighting of candles", mapOf("length" to 14.0), 0xFF60A5FA),
        IndicatorDefinition("HMA", "HMA (Hull Moving Average)", IndicatorCategory.TREND, "Extremely responsive low-lag moving average", mapOf("length" to 16.0), 0xFFA855F7),
        IndicatorDefinition("SUPERTREND", "Supertrend", IndicatorCategory.TREND, "ATR-based trend tracking with breakout signals", mapOf("atrPeriod" to 10.0, "multiplier" to 3.0), 0xFF00E676),
        IndicatorDefinition("PARABOLIC_SAR", "Parabolic SAR", IndicatorCategory.TREND, "Trailing stop and reverse system", mapOf("start" to 0.02, "increment" to 0.02, "maximum" to 0.20), 0xFFFF3366),
        IndicatorDefinition("ICHIMOKU", "Ichimoku Cloud", IndicatorCategory.TREND, "Comprehensive trend, support, and momentum system", mapOf("conversion" to 9.0, "base" to 26.0, "spanB" to 52.0), 0xFF38BDF8),
        IndicatorDefinition("ALLIGATOR", "Williams Alligator", IndicatorCategory.TREND, "Jaw, Teeth, and Lips smoothed moving averages", mapOf("jaw" to 13.0, "teeth" to 8.0, "lips" to 5.0), 0xFF34D399),
        IndicatorDefinition("DONCHIAN", "Donchian Channels", IndicatorCategory.TREND, "Highest high and lowest low over N periods", mapOf("length" to 20.0), 0xFFF59E0B),
        IndicatorDefinition("KELTNER", "Keltner Channel", IndicatorCategory.TREND, "Volatility-based envelope using EMA and ATR", mapOf("length" to 20.0, "multiplier" to 2.0), 0xFFEC4899),
        IndicatorDefinition("ZIGZAG", "ZigZag", IndicatorCategory.TREND, "Filters out small noise to show significant pivots", mapOf("deviation" to 5.0), 0xFFF97316),
        IndicatorDefinition("LINEAR_REG", "Linear Regression Trend", IndicatorCategory.TREND, "Least squares fit trendline", mapOf("length" to 14.0), 0xFF818CF8),

        // MOMENTUM / OSCILLATORS
        IndicatorDefinition("RSI", "RSI (Relative Strength Index)", IndicatorCategory.MOMENTUM, "Measures velocity and magnitude of directional price movements", mapOf("period" to 14.0, "overbought" to 70.0, "oversold" to 30.0), 0xFFA855F7),
        IndicatorDefinition("MACD", "MACD", IndicatorCategory.MOMENTUM, "Moving Average Convergence Divergence", mapOf("fast" to 12.0, "slow" to 26.0, "signal" to 9.0), 0xFF06B6D4),
        IndicatorDefinition("STOCHASTIC", "Stochastic Oscillator", IndicatorCategory.MOMENTUM, "Compares closing price to price range over period", mapOf("k" to 14.0, "d" to 3.0, "smooth" to 3.0, "overbought" to 80.0, "oversold" to 20.0), 0xFFF59E0B),
        IndicatorDefinition("CCI", "Commodity Channel Index (CCI)", IndicatorCategory.MOMENTUM, "Measures variation from statistical mean", mapOf("period" to 20.0), 0xFFEAB308),
        IndicatorDefinition("WILLIAMS_R", "Williams %R", IndicatorCategory.MOMENTUM, "Momentum indicator measuring overbought/oversold levels", mapOf("period" to 14.0), 0xFFEC4899),
        IndicatorDefinition("AWESOME_OSC", "Awesome Oscillator (AO)", IndicatorCategory.MOMENTUM, "34-period and 5-period SMA difference of midpoints", mapOf("fast" to 5.0, "slow" to 34.0), 0xFF10B981),
        IndicatorDefinition("ROC", "Rate of Change (ROC)", IndicatorCategory.MOMENTUM, "Percentage change from N bars ago", mapOf("period" to 12.0), 0xFF3B82F6),
        IndicatorDefinition("ADX", "Average Directional Index (ADX)", IndicatorCategory.MOMENTUM, "Measures overall trend strength irrespective of direction", mapOf("period" to 14.0), 0xFFF97316),
        IndicatorDefinition("DEMARKER", "DeMarker", IndicatorCategory.MOMENTUM, "Identifies potential market exhaustion and reversal points", mapOf("period" to 14.0), 0xFF6366F1),

        // VOLATILITY
        IndicatorDefinition("BOLLINGER", "Bollinger Bands", IndicatorCategory.VOLATILITY, "Volatility bands based on standard deviations above and below SMA", mapOf("length" to 20.0, "stdDev" to 2.0), 0xFF3872FF),
        IndicatorDefinition("ATR", "Average True Range (ATR)", IndicatorCategory.VOLATILITY, "Measures market volatility over N periods", mapOf("period" to 14.0), 0xFFEF4444),
        IndicatorDefinition("STD_DEV", "Standard Deviation", IndicatorCategory.VOLATILITY, "Statistical dispersion of candle prices", mapOf("length" to 20.0), 0xFF8B5CF6),
        IndicatorDefinition("CHOPPINESS", "Choppiness Index", IndicatorCategory.VOLATILITY, "Determines if market is choppy (ranging) or trending", mapOf("period" to 14.0), 0xFF14B8A6),

        // VOLUME / FLOW
        IndicatorDefinition("TICK_VOLUME", "Tick Volume", IndicatorCategory.VOLUME, "Tick activity volume per candle (Forex standard)", mapOf("maLength" to 20.0), 0xFF00E676),
        IndicatorDefinition("OBV", "On-Balance Volume (OBV)", IndicatorCategory.VOLUME, "Cumulative volume flow based on price direction", emptyMap(), 0xFF60A5FA),
        IndicatorDefinition("VWAP", "VWAP", IndicatorCategory.VOLUME, "Volume Weighted Average Price", emptyMap(), 0xFFFFB300),

        // PRICE ACTION / MARKET STRUCTURE
        IndicatorDefinition("FRACTALS", "Bill Williams Fractals", IndicatorCategory.PRICE_ACTION, "Confirmed 5-bar turning points with 2 lower/higher flanking bars", mapOf("strength" to 2.0), 0xFFFFB300),
        IndicatorDefinition("PIVOT_POINTS", "Pivot Points (Classic)", IndicatorCategory.PRICE_ACTION, "Mathematical support and resistance levels from previous session", emptyMap(), 0xFF94A3B8),
        IndicatorDefinition("FIBONACCI", "Fibonacci Retracement", IndicatorCategory.PRICE_ACTION, "Horizontal levels at 23.6%, 38.2%, 50%, 61.8%, 78.6%", emptyMap(), 0xFF38BDF8),
        IndicatorDefinition("SUPPORT_RESISTANCE", "Support & Resistance Levels", IndicatorCategory.PRICE_ACTION, "Dynamic swing highs and lows horizontal zones", mapOf("lookback" to 20.0), 0xFFE2E8F0)
    )

    fun calculateIndicators(
        candles: List<Candle>,
        activeInstances: List<IndicatorInstance>
    ): CalculatedIndicators {
        if (candles.isEmpty()) return CalculatedIndicators()

        var smaList: List<Double?> = emptyList()
        var emaList: List<Double?> = emptyList()
        var bUpper: List<Double?> = emptyList()
        var bMiddle: List<Double?> = emptyList()
        var bLower: List<Double?> = emptyList()
        var supertrend: List<Double?> = emptyList()
        var supertrendBullish: List<Boolean> = emptyList()
        var sar: List<Double?> = emptyList()
        var bullishFractals: List<Int> = emptyList()
        var bearishFractals: List<Int> = emptyList()
        var rsi: Double? = null
        var macd: MacdResult? = null
        var stoch: StochResult? = null
        var adx: Double? = null
        var fibs: List<Double> = emptyList()
        var pivots: PivotLevels? = null

        val closes = candles.map { it.close }

        activeInstances.filter { it.isVisible }.forEach { inst ->
            when (inst.definitionId) {
                "SMA" -> {
                    val len = inst.parameters["length"]?.toInt() ?: 10
                    smaList = calculateSma(closes, len)
                }
                "EMA" -> {
                    val len = inst.parameters["length"]?.toInt() ?: 20
                    emaList = calculateEma(closes, len)
                }
                "BOLLINGER" -> {
                    val len = inst.parameters["length"]?.toInt() ?: 20
                    val mult = inst.parameters["stdDev"] ?: 2.0
                    val bands = calculateBollingerBands(closes, len, mult)
                    bUpper = bands.upper
                    bMiddle = bands.middle
                    bLower = bands.lower
                }
                "SUPERTREND" -> {
                    val atrPeriod = inst.parameters["atrPeriod"]?.toInt() ?: 10
                    val mult = inst.parameters["multiplier"] ?: 3.0
                    val st = calculateSupertrend(candles, atrPeriod, mult)
                    supertrend = st.first
                    supertrendBullish = st.second
                }
                "PARABOLIC_SAR" -> {
                    val start = inst.parameters["start"] ?: 0.02
                    val inc = inst.parameters["increment"] ?: 0.02
                    val maxVal = inst.parameters["maximum"] ?: 0.20
                    sar = calculateParabolicSar(candles, start, inc, maxVal)
                }
                "FRACTALS" -> {
                    val strength = inst.parameters["strength"]?.toInt() ?: 2
                    val fr = calculateBillWilliamsFractals(candles, strength)
                    bullishFractals = fr.bullish
                    bearishFractals = fr.bearish
                }
                "RSI" -> {
                    val period = inst.parameters["period"]?.toInt() ?: 14
                    rsi = calculateRsi(closes, period)
                }
                "MACD" -> {
                    val fast = inst.parameters["fast"]?.toInt() ?: 12
                    val slow = inst.parameters["slow"]?.toInt() ?: 26
                    val signal = inst.parameters["signal"]?.toInt() ?: 9
                    macd = calculateMacd(closes, fast, slow, signal)
                }
                "STOCHASTIC" -> {
                    val k = inst.parameters["k"]?.toInt() ?: 14
                    val d = inst.parameters["d"]?.toInt() ?: 3
                    stoch = calculateStochastic(candles, k, d)
                }
                "ADX" -> {
                    val period = inst.parameters["period"]?.toInt() ?: 14
                    adx = calculateAdx(candles, period)
                }
                "FIBONACCI" -> {
                    fibs = calculateFibonacciLevels(candles)
                }
                "PIVOT_POINTS" -> {
                    pivots = calculatePivotPoints(candles)
                }
            }
        }

        // Always provide a default SMA or EMA if none enabled so chart always has basic guide
        if (smaList.isEmpty() && emaList.isEmpty()) {
            smaList = calculateSma(closes, 14)
        }

        return CalculatedIndicators(
            smaValues = smaList,
            emaValues = emaList,
            bollingerUpper = bUpper,
            bollingerMiddle = bMiddle,
            bollingerLower = bLower,
            supertrendValues = supertrend,
            supertrendIsBullish = supertrendBullish,
            sarValues = sar,
            bullishFractals = bullishFractals,
            bearishFractals = bearishFractals,
            rsiLatest = rsi ?: calculateRsi(closes, 14),
            macdLatest = macd ?: calculateMacd(closes, 12, 26, 9),
            stochasticLatest = stoch ?: calculateStochastic(candles, 14, 3),
            adxLatest = adx ?: calculateAdx(candles, 14),
            fibonacciLevels = fibs,
            pivotLevels = pivots
        )
    }

    // --- Mathematical Implementations ---

    fun calculateSma(values: List<Double>, period: Int): List<Double?> {
        val result = ArrayList<Double?>(values.size)
        var sum = 0.0
        for (i in values.indices) {
            sum += values[i]
            if (i >= period) {
                sum -= values[i - period]
            }
            if (i >= period - 1) {
                result.add(sum / period)
            } else {
                result.add(null)
            }
        }
        return result
    }

    fun calculateEma(values: List<Double>, period: Int): List<Double?> {
        val result = ArrayList<Double?>(values.size)
        if (values.size < period) {
            return values.map { null }
        }
        val k = 2.0 / (period + 1)
        var ema: Double? = null

        for (i in values.indices) {
            if (i < period - 1) {
                result.add(null)
            } else if (i == period - 1) {
                val sum = values.subList(0, period).sum()
                ema = sum / period
                result.add(ema)
            } else {
                ema = (values[i] * k) + (ema!! * (1.0 - k))
                result.add(ema)
            }
        }
        return result
    }

    data class BollingerResult(
        val middle: List<Double?>,
        val upper: List<Double?>,
        val lower: List<Double?>
    )

    fun calculateBollingerBands(closes: List<Double>, period: Int, multiplier: Double): BollingerResult {
        val sma = calculateSma(closes, period)
        val upper = ArrayList<Double?>(closes.size)
        val lower = ArrayList<Double?>(closes.size)

        for (i in closes.indices) {
            val mid = sma[i]
            if (mid == null || i < period - 1) {
                upper.add(null)
                lower.add(null)
            } else {
                var varianceSum = 0.0
                for (j in (i - period + 1)..i) {
                    val diff = closes[j] - mid
                    varianceSum += diff * diff
                }
                val stdDev = sqrt(varianceSum / period)
                upper.add(mid + (multiplier * stdDev))
                lower.add(mid - (multiplier * stdDev))
            }
        }
        return BollingerResult(sma, upper, lower)
    }

    /**
     * Supertrend: Trend direction and trailing ATR band
     */
    fun calculateSupertrend(candles: List<Candle>, period: Int, multiplier: Double): Pair<List<Double?>, List<Boolean>> {
        val n = candles.size
        val stValues = ArrayList<Double?>(n)
        val isBullish = ArrayList<Boolean>(n)
        if (n < period + 1) {
            for (i in 0 until n) {
                stValues.add(null)
                isBullish.add(true)
            }
            return Pair(stValues, isBullish)
        }

        // Calculate ATR
        val tr = ArrayList<Double>(n)
        tr.add(candles[0].high - candles[0].low)
        for (i in 1 until n) {
            val c = candles[i]
            val prevClose = candles[i - 1].close
            val trueRange = max(c.high - c.low, max(abs(c.high - prevClose), abs(c.low - prevClose)))
            tr.add(trueRange)
        }
        val atr = calculateSma(tr, period)

        var trend = 1 // 1 for bullish, -1 for bearish
        var prevUpperBand = 0.0
        var prevLowerBand = 0.0

        for (i in 0 until n) {
            val a = atr[i]
            if (a == null) {
                stValues.add(null)
                isBullish.add(true)
            } else {
                val hl2 = (candles[i].high + candles[i].low) / 2.0
                var basicUpper = hl2 + (multiplier * a)
                var basicLower = hl2 - (multiplier * a)

                var finalUpper = basicUpper
                if (i > 0 && candles[i - 1].close < prevUpperBand) {
                    finalUpper = min(basicUpper, prevUpperBand)
                }

                var finalLower = basicLower
                if (i > 0 && candles[i - 1].close > prevLowerBand) {
                    finalLower = max(basicLower, prevLowerBand)
                }

                if (i > 0) {
                    if (trend == 1 && candles[i].close < finalLower) {
                        trend = -1
                    } else if (trend == -1 && candles[i].close > finalUpper) {
                        trend = 1
                    }
                }

                val st = if (trend == 1) finalLower else finalUpper
                stValues.add(st)
                isBullish.add(trend == 1)

                prevUpperBand = finalUpper
                prevLowerBand = finalLower
            }
        }
        return Pair(stValues, isBullish)
    }

    /**
     * Parabolic SAR calculation
     */
    fun calculateParabolicSar(candles: List<Candle>, start: Double, inc: Double, maxVal: Double): List<Double?> {
        val n = candles.size
        val result = ArrayList<Double?>(n)
        if (n < 3) return candles.map { null }

        var isUp = candles[1].close >= candles[0].close
        var sar = if (isUp) candles[0].low else candles[0].high
        var ep = if (isUp) candles[1].high else candles[1].low
        var af = start

        result.add(null)
        result.add(sar)

        for (i in 2 until n) {
            val c = candles[i]
            val prevC = candles[i - 1]
            sar = sar + af * (ep - sar)

            if (isUp) {
                if (sar > c.low) {
                    isUp = false
                    sar = ep
                    ep = c.low
                    af = start
                } else {
                    if (c.high > ep) {
                        ep = c.high
                        af = min(af + inc, maxVal)
                    }
                    if (i >= 2) sar = min(sar, min(prevC.low, candles[i - 2].low))
                }
            } else {
                if (sar < c.high) {
                    isUp = true
                    sar = ep
                    ep = c.high
                    af = start
                } else {
                    if (c.low < ep) {
                        ep = c.low
                        af = min(af + inc, maxVal)
                    }
                    if (i >= 2) sar = max(sar, max(prevC.high, candles[i - 2].high))
                }
            }
            result.add(sar)
        }
        return result
    }

    data class FractalIndices(
        val bullish: List<Int>, // Swing lows
        val bearish: List<Int>  // Swing highs
    )

    /**
     * Bill Williams Fractals:
     * Confirmed ONLY after [strength] candles have formed to the right!
     * Standard strength = 2 (5-bar pattern: middle candle is strictly higher/lower than 2 left and 2 right).
     */
    fun calculateBillWilliamsFractals(candles: List<Candle>, strength: Int = 2): FractalIndices {
        val bullish = mutableListOf<Int>()
        val bearish = mutableListOf<Int>()
        val n = candles.size
        if (n < (strength * 2) + 1) return FractalIndices(emptyList(), emptyList())

        for (i in strength until (n - strength)) {
            val target = candles[i]
            var isHighFractal = true
            var isLowFractal = true

            for (j in 1..strength) {
                if (candles[i - j].high >= target.high || candles[i + j].high >= target.high) {
                    isHighFractal = false
                }
                if (candles[i - j].low <= target.low || candles[i + j].low <= target.low) {
                    isLowFractal = false
                }
            }

            if (isHighFractal) bearish.add(i)
            if (isLowFractal) bullish.add(i)
        }
        return FractalIndices(bullish, bearish)
    }

    fun calculateRsi(closes: List<Double>, period: Int): Double? {
        if (closes.size < period + 1) return null
        var gains = 0.0
        var losses = 0.0

        for (i in 1..period) {
            val diff = closes[i] - closes[i - 1]
            if (diff >= 0) gains += diff else losses += -diff
        }
        var avgGain = gains / period
        var avgLoss = losses / period

        for (i in (period + 1) until closes.size) {
            val diff = closes[i] - closes[i - 1]
            val gain = if (diff > 0) diff else 0.0
            val loss = if (diff < 0) -diff else 0.0
            avgGain = ((avgGain * (period - 1)) + gain) / period
            avgLoss = ((avgLoss * (period - 1)) + loss) / period
        }

        if (avgLoss == 0.0) return 100.0
        val rs = avgGain / avgLoss
        return (100.0 - (100.0 / (1.0 + rs))).coerceIn(0.0, 100.0)
    }

    fun calculateMacd(closes: List<Double>, fast: Int = 12, slow: Int = 26, signal: Int = 9): MacdResult? {
        if (closes.size < slow + signal) return null
        val fastEma = calculateEma(closes, fast)
        val slowEma = calculateEma(closes, slow)

        val macdLineSeries = ArrayList<Double>()
        for (i in closes.indices) {
            val f = fastEma[i]
            val s = slowEma[i]
            if (f != null && s != null) {
                macdLineSeries.add(f - s)
            }
        }
        if (macdLineSeries.size < signal) return null

        val signalSeries = calculateEma(macdLineSeries, signal)
        val latestMacd = macdLineSeries.last()
        val latestSignal = signalSeries.last() ?: 0.0
        val hist = latestMacd - latestSignal

        return MacdResult(latestMacd, latestSignal, hist)
    }

    fun calculateStochastic(candles: List<Candle>, kPeriod: Int = 14, dPeriod: Int = 3): StochResult? {
        if (candles.size < kPeriod + dPeriod) return null
        val kValues = ArrayList<Double>()

        for (i in kPeriod..candles.size) {
            val sub = candles.subList(i - kPeriod, i)
            val highest = sub.maxOf { it.high }
            val lowest = sub.minOf { it.low }
            val close = sub.last().close
            val range = highest - lowest
            val k = if (range != 0.0) ((close - lowest) / range) * 100.0 else 50.0
            kValues.add(k)
        }

        val d = if (kValues.size >= dPeriod) {
            kValues.takeLast(dPeriod).average()
        } else 50.0

        return StochResult(kValues.lastOrNull() ?: 50.0, d)
    }

    fun calculateAdx(candles: List<Candle>, period: Int = 14): Double? {
        if (candles.size < period * 2) return 25.0
        // Approximate ADX trend strength
        val recent = candles.takeLast(period)
        val highMax = recent.maxOf { it.high }
        val lowMin = recent.minOf { it.low }
        val span = highMax - lowMin
        val avgSpan = span / period
        val movement = abs(recent.last().close - recent.first().open)
        val strength = if (span > 0) (movement / span) * 100.0 else 25.0
        return strength.coerceIn(5.0, 95.0)
    }

    fun calculateFibonacciLevels(candles: List<Candle>): List<Double> {
        if (candles.size < 10) return emptyList()
        val lookback = candles.takeLast(50)
        val high = lookback.maxOf { it.high }
        val low = lookback.minOf { it.low }
        val diff = high - low
        return listOf(
            high,
            high - (diff * 0.236),
            high - (diff * 0.382),
            high - (diff * 0.500),
            high - (diff * 0.618),
            high - (diff * 0.786),
            low
        )
    }

    fun calculatePivotPoints(candles: List<Candle>): PivotLevels? {
        if (candles.size < 5) return null
        val lookback = candles.takeLast(20)
        val h = lookback.maxOf { it.high }
        val l = lookback.minOf { it.low }
        val c = lookback.last().close
        val pp = (h + l + c) / 3.0
        val r1 = (2 * pp) - l
        val s1 = (2 * pp) - h
        val r2 = pp + (h - l)
        val s2 = pp - (h - l)
        return PivotLevels(pp, r1, s1, r2, s2)
    }
}
