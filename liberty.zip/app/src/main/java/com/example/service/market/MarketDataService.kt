package com.example.service.market

import com.example.data.Candle
import com.example.data.Timeframe
import com.example.data.TradingAsset
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ConcurrentHashMap

/**
 * Real-time Market Data Service.
 *
 * Implements the required pipeline:
 * MarketDataService -> CandleBuilder -> IndicatorEngine -> SignalEngine -> Chart -> DemoTradingEngine
 *
 * Automatically manages MockMarketDataProvider and LiveMarketDataProvider based on configuration,
 * never displaying LIVE when using mock/generated data.
 */
class MarketDataService(
    private val scope: CoroutineScope,
    private val candleBuilder: CandleBuilder,
    initialConfig: MarketDataConfig = MarketDataConfig()
) {
    private val _config = MutableStateFlow(initialConfig)
    val config: StateFlow<MarketDataConfig> = _config.asStateFlow()

    private var activeProvider: MarketDataProvider = createProvider(initialConfig)

    private val _connectionStatus = MutableStateFlow(activeProvider.connectionStatus.value)
    val connectionStatus: StateFlow<DataConnectionState> = _connectionStatus.asStateFlow()

    private val _lastUpdateFormatted = MutableStateFlow("")
    val lastUpdateFormatted: StateFlow<String> = _lastUpdateFormatted.asStateFlow()

    private val _activeSymbols = MutableStateFlow<List<DerivActiveSymbol>>(emptyList())
    val activeSymbols: StateFlow<List<DerivActiveSymbol>> = _activeSymbols.asStateFlow()

    val providerName: String
        get() = activeProvider.providerName

    val isLiveConnection: Boolean
        get() = activeProvider.isLiveConnection

    private val timeFormatter = SimpleDateFormat("HH:mm:ss", Locale.US)
    private var observationJob: Job? = null

    init {
        startActiveProvider()
    }

    private fun createProvider(cfg: MarketDataConfig): MarketDataProvider {
        return if (cfg.hasValidLiveCredentials() && cfg.isLiveConfigured) {
            LiveMarketDataProvider(scope, candleBuilder, cfg)
        } else {
            MockMarketDataProvider(scope, candleBuilder)
        }
    }

    private fun startActiveProvider() {
        observationJob?.cancel()
        activeProvider.start()
        observationJob = scope.launch {
            launch {
                activeProvider.connectionStatus.collect {
                    _connectionStatus.value = it
                }
            }
            launch {
                activeProvider.lastUpdateTimestamp.collect { ts ->
                    if (ts > 0) {
                        _lastUpdateFormatted.value = timeFormatter.format(Date(ts))
                    }
                }
            }
            launch {
                activeProvider.activeSymbols.collect { symbols ->
                    _activeSymbols.value = symbols
                }
            }
        }
    }

    fun selectSymbol(symbol: String) {
        activeProvider.selectSymbol(symbol)
    }

    fun updateConfig(newConfig: MarketDataConfig) {
        _config.value = newConfig
        activeProvider.stop()
        activeProvider = createProvider(newConfig)
        startActiveProvider()
    }

    fun reconnect() {
        activeProvider.reconnect()
    }

    fun getLatestTick(symbol: String): MarketTick? = activeProvider.getLatestTick(symbol)

    fun observeTicks(): SharedFlow<MarketTick> = activeProvider.observeTicks()
}

object MarketDataDefaults {
    val SUPPORTED_ASSETS = listOf(
        TradingAsset("EUR/USD", "Euro / US Dollar", 1.08640, 5, 85, 0.00012, "🇪🇺"),
        TradingAsset("GBP/USD", "British Pound / US Dollar", 1.29420, 5, 82, 0.00015, "🇬🇧"),
        TradingAsset("USD/JPY", "US Dollar / Japanese Yen", 154.350, 3, 84, 0.025, "🇯🇵"),
        TradingAsset("AUD/USD", "Australian Dollar / US Dollar", 0.65420, 5, 83, 0.00012, "🇦🇺"),
        TradingAsset("USD/CAD", "US Dollar / Canadian Dollar", 1.36850, 5, 81, 0.00014, "🇨🇦"),
        TradingAsset("USD/CHF", "US Dollar / Swiss Franc", 0.88450, 5, 82, 0.00013, "🇨🇭"),
        TradingAsset("NZD/USD", "New Zealand / US Dollar", 0.59820, 5, 80, 0.00013, "🇳🇿"),
        TradingAsset("XAU/USD", "Gold / US Dollar", 2418.50, 2, 85, 0.65, "🪙"),
        TradingAsset("BTC/USD", "Bitcoin / US Dollar", 64250.00, 2, 90, 18.5, "₿"),
        TradingAsset("EUR/GBP", "Euro / British Pound", 0.85240, 5, 80, 0.00010, "🇪🇺"),
        TradingAsset("ETH/USD", "Ethereum / US Dollar", 3480.00, 2, 88, 1.85, "⟠"),
        // 24/7 Continuous Synthetic Derived Indices (Deriv Volatility Indices)
        TradingAsset("VOL_100", "Volatility 100 (24/7)", 2150.00, 2, 88, 1.20, "⚡"),
        TradingAsset("VOL_75", "Volatility 75 (24/7)", 345000.0, 2, 86, 150.0, "⚡"),
        TradingAsset("VOL_50", "Volatility 50 (24/7)", 285.5000, 4, 85, 0.15, "⚡")
    )
}
