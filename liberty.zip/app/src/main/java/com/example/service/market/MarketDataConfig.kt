package com.example.service.market

/**
 * Deriv Active Symbol definition returned by the active_symbols endpoint.
 */
data class DerivActiveSymbol(
    val canonicalSymbol: String,
    val derivSymbol: String,
    val displayName: String,
    val market: String,
    val isOpen: Boolean,
    val isSuspended: Boolean,
    val pip: Double
)

/**
 * Configuration layer for real-time market data streaming.
 *
 * Connects to the official Deriv public WebSocket:
 * Primary: wss://api.derivws.com/trading/v1/options/ws/public
 * Fallback: wss://ws.derivws.com/websockets/v3?app_id=1089
 *
 * Public market-data connection only. No account credentials or real-money execution.
 */
data class MarketDataConfig(
    val MARKET_DATA_PROVIDER: String = "Deriv",
    val MARKET_DATA_API_KEY: String = "",
    val MARKET_DATA_API_SECRET: String = "",
    val MARKET_DATA_WEBSOCKET_URL: String = "wss://api.derivws.com/trading/v1/options/ws/public",
    val FALLBACK_WEBSOCKET_URL: String = "wss://ws.derivws.com/websockets/v3?app_id=1089",
    val MARKET_DATA_REST_URL: String = "",
    val isLiveConfigured: Boolean = true,
    val symbolMapping: Map<String, String> = mapOf(
        "EUR/USD" to "frxEURUSD",
        "GBP/USD" to "frxGBPUSD",
        "USD/JPY" to "frxUSDJPY",
        "AUD/USD" to "frxAUDUSD",
        "USD/CAD" to "frxUSDCAD",
        "USD/CHF" to "frxUSDCHF",
        "NZD/USD" to "frxNZDUSD",
        "XAU/USD" to "frxXAUUSD",
        "BTC/USD" to "cryBTCUSD",
        "EUR/GBP" to "frxEURGBP",
        "ETH/USD" to "cryETHUSD",
        // Deriv 24/7 Continuous Synthetic Indices
        "VOL_100" to "R_100",
        "VOL_75" to "R_75",
        "VOL_50" to "R_50",
        "VOL_25" to "R_25",
        "VOL_10" to "R_10"
    )
) {
    fun hasValidLiveCredentials(): Boolean = MARKET_DATA_WEBSOCKET_URL.isNotBlank()

    fun toProviderSymbol(canonicalSymbol: String): String =
        symbolMapping[canonicalSymbol] ?: canonicalSymbol.replace("/", "")

    fun toCanonicalSymbol(providerSymbol: String): String {
        return symbolMapping.entries.firstOrNull { it.value.equals(providerSymbol, ignoreCase = true) }?.key
            ?: providerSymbol
    }
}
